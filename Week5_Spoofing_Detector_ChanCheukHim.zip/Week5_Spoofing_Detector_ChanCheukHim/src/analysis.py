"""
The descriptive half of the project: does a ghost level tell you anything about
where price goes next, and does spoofing behaviour cluster.

On standard errors
------------------
Events overlap in time and arrive in bursts, so treating them as independent
draws would understate the error bars badly. Every mean in here comes with a
block bootstrap confidence interval: the timeline is cut into one hour blocks,
blocks are resampled with replacement, and the statistic is recomputed. That
keeps whatever within hour dependence exists intact.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from . import config

BLOCK_S = 3600


# ----------------------------------------------------------------------------
# Bootstrap
# ----------------------------------------------------------------------------

def block_bootstrap_mean(df: pd.DataFrame, value_col: str, group_col: str,
                         n_boot: int = 2000, block_s: int = BLOCK_S,
                         seed: int = 7) -> pd.DataFrame:
    """Group means with a one hour block bootstrap 95 percent interval."""
    rng = np.random.default_rng(seed)
    d = df[[value_col, group_col, "t0"]].dropna().copy()
    if d.empty:
        return pd.DataFrame()

    d["block"] = (d["t0"] // block_s).astype(int)
    blocks = np.array(sorted(d["block"].unique()))
    by_block = {b: g for b, g in d.groupby("block", sort=False)}

    groups = sorted(d[group_col].unique())
    draws = {g: np.full(n_boot, np.nan) for g in groups}

    for i in range(n_boot):
        pick = rng.choice(blocks, size=len(blocks), replace=True)
        sample = pd.concat([by_block[b] for b in pick], copy=False)
        means = sample.groupby(group_col)[value_col].mean()
        for g in groups:
            if g in means.index:
                draws[g][i] = means[g]

    rows = []
    for g in groups:
        sub = d[d[group_col] == g][value_col]
        arr = draws[g][~np.isnan(draws[g])]
        rows.append({
            group_col: g,
            "n": int(len(sub)),
            "mean": float(sub.mean()),
            "ci_lo": float(np.percentile(arr, 2.5)) if len(arr) else np.nan,
            "ci_hi": float(np.percentile(arr, 97.5)) if len(arr) else np.nan,
        })
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# Forward return event study
# ----------------------------------------------------------------------------

def forward_return_table(ev: pd.DataFrame, horizons=config.HORIZONS_S,
                         n_boot: int = 1000) -> pd.DataFrame:
    """Signed forward return by horizon and event category."""
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    out = []
    for h in horizons:
        col = f"fwd_{h}s_bps"
        tab = block_bootstrap_mean(d, col, "event_category", n_boot=n_boot)
        tab.insert(0, "horizon_s", h)
        out.append(tab)
    return pd.concat(out, ignore_index=True)


def ghost_vs_filled_test(ev: pd.DataFrame, horizon: int = 10) -> dict:
    """Welch test on the difference in signed forward return, for reference."""
    col = f"fwd_{horizon}s_bps"
    g = ev.loc[ev["event_category"] == "ghost", col].dropna()
    f = ev.loc[ev["event_category"] == "filled", col].dropna()
    t, p = stats.ttest_ind(g, f, equal_var=False)
    return {"horizon_s": horizon, "n_ghost": int(len(g)), "n_filled": int(len(f)),
            "mean_ghost_bps": float(g.mean()), "mean_filled_bps": float(f.mean()),
            "diff_bps": float(g.mean() - f.mean()),
            "welch_t": float(t), "p_value": float(p)}


def reversal_table(ev: pd.DataFrame, n_boot: int = 1000) -> pd.DataFrame:
    """
    Push then revert check. A positive 10 second move followed by a negative
    10 to 60 second change is the signature of pressure that was never real.
    """
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    return block_bootstrap_mean(d, "reversal_10s_60s_bps", "event_category",
                                n_boot=n_boot)


def fill_outcome_table(ev: pd.DataFrame) -> pd.DataFrame:
    """Do ghost levels attract fills, or not. Counts and shares by category."""
    d = ev[~ev["event_category"].isin(["censored"])]
    g = d.groupby("event_category").agg(
        n=("fill_share", "size"),
        mean_fill_share=("fill_share", "mean"),
        median_life_s=("life_s", "median"),
        median_est_size_btc=("est_order_btc", "median"),
        median_dist0_buckets=("dist0_buckets", "median"),
        median_min_dist_buckets=("min_dist_buckets", "median"),
    ).reset_index()
    g["share_of_events"] = g["n"] / g["n"].sum()
    return g


# ----------------------------------------------------------------------------
# Clustering
# ----------------------------------------------------------------------------

def hour_clustering(ev: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    Ghost rate by UTC hour, plus a chi square test against the null that ghosts
    are a constant fraction of large levels in every hour. Testing the rate and
    not the raw count matters: busy hours produce more of everything.
    """
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    tab = d.groupby("hour_utc").agg(
        n_large=("is_ghost", "size"), n_ghost=("is_ghost", "sum")).reset_index()
    tab["ghost_rate"] = tab["n_ghost"] / tab["n_large"]

    overall = tab["n_ghost"].sum() / tab["n_large"].sum()
    exp_g = tab["n_large"] * overall
    exp_n = tab["n_large"] * (1 - overall)
    obs = np.concatenate([tab["n_ghost"], tab["n_large"] - tab["n_ghost"]])
    exp = np.concatenate([exp_g, exp_n])
    chi2 = float(((obs - exp) ** 2 / np.maximum(exp, 1e-9)).sum())
    dof = len(tab) - 1
    return tab, {"chi2": chi2, "dof": dof,
                 "p_value": float(stats.chi2.sf(chi2, dof)),
                 "overall_ghost_rate": float(overall)}


def size_signature_table(ev: pd.DataFrame, tol: float = 0.015,
                         min_repeats: int = 3) -> pd.DataFrame:
    """
    Cluster large levels by estimated size and report which clusters are
    dominated by ghosts. A size that keeps reappearing and keeps vanishing is
    the closest thing to a participant fingerprint public data allows.
    """
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    rows = []
    for venue, grp in d.groupby("venue"):
        sizes = np.sort(grp["excess0_btc"].to_numpy())
        # simple single pass clustering on a relative tolerance
        clusters, cur = [], [sizes[0]]
        for x in sizes[1:]:
            if x <= cur[0] * (1 + 2 * tol):
                cur.append(x)
            else:
                clusters.append(cur)
                cur = [x]
        clusters.append(cur)

        for c in clusters:
            if len(c) < min_repeats:
                continue
            lo, hi = min(c), max(c)
            sel = grp[(grp["excess0_btc"] >= lo) & (grp["excess0_btc"] <= hi)]
            rows.append({
                "venue": venue,
                "size_lo_btc": lo, "size_hi_btc": hi,
                "n_events": int(len(sel)),
                "n_ghost": int(sel["is_ghost"].sum()),
                "ghost_rate": float(sel["is_ghost"].mean()),
            })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.sort_values(["venue", "n_events"], ascending=[True, False]).reset_index(drop=True)


def participant_check(ev: pd.DataFrame) -> pd.DataFrame:
    """Ghost rate by the simulator's hidden participant tag. Evaluation only."""
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    return (d.groupby(["true_type", "true_participant"])
            .agg(n=("is_ghost", "size"), n_ghost=("is_ghost", "sum"))
            .assign(ghost_rate=lambda x: x["n_ghost"] / x["n"])
            .reset_index()
            .sort_values("n", ascending=False))


def venue_comparison(ev: pd.DataFrame) -> pd.DataFrame:
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    return (d.groupby("venue").agg(
        n_large_levels=("is_ghost", "size"),
        n_ghost=("is_ghost", "sum"),
        ghost_rate=("is_ghost", "mean"),
        median_est_size_btc=("est_order_btc", "median"),
        median_life_s=("life_s", "median"),
        mean_fill_share=("fill_share", "mean"),
    ).reset_index())


# ----------------------------------------------------------------------------
# Why raw top ten levels are not enough
# ----------------------------------------------------------------------------

def depth_window_check(sims: dict) -> pd.DataFrame:
    """
    Quantify the geometry problem behind the bucket aggregation choice.

    The brief asks for the top 10 raw levels. At the native tick size those ten
    levels cover a price range that BTC crosses in well under a second, so an
    order can never be observed sitting there while price walks toward it. This
    table is the argument, in numbers, for aggregating into wider buckets first.
    """
    rows = []
    for venue, out in sims.items():
        mid = out.mid
        r1 = np.abs(np.diff(mid))
        r30 = np.abs(mid[30:] - mid[:-30])
        tick = config.RAW_TICK[venue]
        raw_span = 10 * tick
        bucket_span = config.N_LEVELS * config.BUCKET_USDT
        rows.append({
            "venue": venue,
            "tick_usdt": tick,
            "raw_top10_span_usdt": raw_span,
            "raw_top10_span_bps": raw_span / mid.mean() * 1e4,
            "bucketed_top10_span_usdt": bucket_span,
            "bucketed_top10_span_bps": bucket_span / mid.mean() * 1e4,
            "median_abs_1s_move_usdt": float(np.median(r1)),
            "median_abs_30s_move_usdt": float(np.median(r30)),
            "pct_1s_moves_exceeding_raw_span": float((r1 > raw_span).mean() * 100),
            "pct_30s_moves_exceeding_bucket_span": float((r30 > bucket_span).mean() * 100),
        })
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------------

def _style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "figure.dpi": 130, "savefig.dpi": 130, "font.size": 9,
        "axes.grid": True, "grid.alpha": 0.25, "axes.spines.top": False,
        "axes.spines.right": False, "figure.facecolor": "white",
    })
    return plt


def fig_forward_returns(fr: pd.DataFrame, path):
    plt = _style()
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    colors = {"ghost": "#c0392b", "filled": "#2c7fb8",
              "pulled_away_from_price": "#7f8c8d"}
    for cat, g in fr.groupby("event_category"):
        g = g.sort_values("horizon_s")
        ax.errorbar(g["horizon_s"], g["mean"],
                    yerr=[g["mean"] - g["ci_lo"], g["ci_hi"] - g["mean"]],
                    marker="o", capsize=3, lw=1.4, label=cat.replace("_", " "),
                    color=colors.get(cat))
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xlabel("seconds after the level first appears")
    ax.set_ylabel("signed mid return (bps)")
    ax.set_title("Signed forward return after a large level appears")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def fig_hour_clustering(tab: pd.DataFrame, path):
    plt = _style()
    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    ax.bar(tab["hour_utc"], tab["ghost_rate"], color="#c0392b", alpha=0.85)
    ax.axhline(tab["n_ghost"].sum() / tab["n_large"].sum(),
               color="black", ls="--", lw=1, label="overall rate")
    ax.set_xlabel("UTC hour"); ax.set_ylabel("ghost share of large levels")
    ax.set_title("Ghost level rate by hour of day")
    ax.set_xticks(range(0, 24, 2))
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def fig_size_distribution(ev: pd.DataFrame, path):
    plt = _style()
    d = ev[ev["event_category"].isin(["ghost", "filled", "pulled_away_from_price"])]
    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    for cat, color in (("ghost", "#c0392b"), ("filled", "#2c7fb8")):
        s = np.log10(d.loc[d["event_category"] == cat, "size_ratio0"].clip(lower=1e-3))
        ax.hist(s, bins=50, alpha=0.55, label=cat, color=color, density=True)
    ax.set_xlabel("log10 of bucket size divided by trailing median depth at t0")
    ax.set_ylabel("density")
    ax.set_title("How large is a ghost level compared with normal depth")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def fig_precision_recall(models: dict, test: pd.DataFrame, path):
    plt = _style()
    from sklearn.metrics import precision_recall_curve
    from .features import FEATURE_COLUMNS

    X = test[FEATURE_COLUMNS].to_numpy(float)
    y = test["is_ghost"].to_numpy(int)
    fig, ax = plt.subplots(figsize=(5.6, 3.8))
    for name, mdl in models.items():
        p = mdl.predict_proba(X)[:, 1]
        pr, rc, _ = precision_recall_curve(y, p)
        ax.plot(rc, pr, lw=1.5, label=name.replace("_", " "))
    ax.axhline(y.mean(), color="black", ls="--", lw=1,
               label=f"flag everything ({y.mean():.2f})")
    ax.set_xlabel("recall"); ax.set_ylabel("precision")
    ax.set_title("Test set precision and recall, ghost label")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def fig_example_event(w: pd.DataFrame, path):
    """
    One flagged level from placement to disappearance.

    The plot shows size in the bucket over and above the normal depth carried at
    that distance, not the raw bucket size, because raw size is dominated by the
    background depth profile and the order itself is invisible inside it.
    """
    plt = _style()
    if w.empty:
        return
    w = w.sort_values("rel_t")
    fig, ax1 = plt.subplots(figsize=(6.6, 3.6))
    ax1.fill_between(w["rel_t"], 0, w["excess_btc"], color="#c0392b", alpha=0.25)
    ax1.plot(w["rel_t"], w["excess_btc"], color="#c0392b", lw=1.6,
             label="size above normal depth")
    ax1.set_xlabel("seconds since the level appeared")
    ax1.set_ylabel("excess resting size (BTC)", color="#c0392b")
    ax1.tick_params(axis="y", labelcolor="#c0392b")
    ax1.set_ylim(bottom=0)

    ax2 = ax1.twinx()
    ax2.plot(w["rel_t"], w["dist_buckets"], color="#2c7fb8", lw=1.4, ls="--",
             label="distance of mid from the level")
    ax2.set_ylabel("distance from mid (buckets)", color="#2c7fb8")
    ax2.tick_params(axis="y", labelcolor="#2c7fb8")
    ax2.invert_yaxis()
    ax2.grid(False)

    end = w["rel_t"].max()
    ax1.axvline(end, color="black", ls=":", lw=1)
    ax1.annotate("order gone", xy=(end, ax1.get_ylim()[1] * 0.92),
                 ha="right", va="top", fontsize=8)

    venue = w["venue"].iloc[0]
    ax1.set_title(f"One large {w['side'].iloc[0]} level on {venue}, "
                  f"placement to disappearance")
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, frameon=False, fontsize=8, loc="lower left")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)
