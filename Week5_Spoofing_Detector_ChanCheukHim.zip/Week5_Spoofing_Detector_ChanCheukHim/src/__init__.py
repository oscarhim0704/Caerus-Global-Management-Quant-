"""Week 5 latent liquidity and spoofing detector."""
