"""
Features for the spoof classifier, and forward returns for the event study.

The rule that matters here
--------------------------
Every model input has to be computable at t0, the second the level first
qualifies as large. Anything measured over the level's life is an outcome, not
a feature. It is very easy to slip fill share or lifetime into the feature
matrix and end up with a model that scores brilliantly and predicts nothing,
so the banned columns are listed explicitly and `build_feature_matrix` raises
if one of them ever appears.

Signed returns
--------------
Forward returns are signed so that positive means price moved in the direction
a genuine large order on that side would push it: up after a large bid, down
after a large ask. Under the spoofing story a fake bid should produce a small
positive signed return over the first few seconds followed by a reversal, since
the pressure disappears the moment the order is pulled.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import config


# Columns that describe what happened after t0. None of these may be a feature.
OUTCOME_COLUMNS = {
    "life_s", "min_dist_buckets", "max_dist_buckets", "fill_share",
    "traded_in_bucket_btc", "est_order_btc", "end_reason", "event_category",
    "is_ghost", "t_end", "true_type", "true_participant", "true_size_btc",
    "true_end_reason", "true_is_spoof",
}

# Three candidates were dropped after looking at the correlation matrix in
# outputs/tables/feature_correlations.csv:
#   spread_bps    correlates 1.000 with is_hyperliquid, because the simulator
#                 holds the spread at one tick on each venue. It is a venue
#                 label wearing a disguise. On live data it would carry real
#                 information and should go back in.
#   dist0_bps     correlates 0.999 with dist0_buckets, same quantity twice.
#   rv_300s_bps   correlates 0.913 with rv_60s_bps.
# Leaving them in did not change the AUC but it scrambled the coefficients:
# log_excess0 and spread_bps split the same effect between them and came out
# with an odds ratio of 31 and a sign flip on log_size_ratio0.
FEATURE_COLUMNS = [
    "log_excess0", "log_size_ratio0", "dist0_buckets",
    "same_side_depth_share",
    "rv_60s_bps", "ofi_60s", "signed_trend_60s_bps",
    "n_other_large0", "sig_repeat_6h", "sig_repeat_share_6h",
    "hour_sin", "hour_cos", "is_bid", "is_hyperliquid",
]


# ----------------------------------------------------------------------------
# Market state at t0
# ----------------------------------------------------------------------------

def _rolling_state(mid: np.ndarray, buy: np.ndarray, sell: np.ndarray):
    """Pre-compute the cumulative sums the per event lookups need."""
    lr = np.zeros_like(mid)
    lr[1:] = np.diff(np.log(mid))
    c_lr2 = np.concatenate([[0.0], np.cumsum(lr ** 2)])
    c_buy = np.concatenate([[0.0], np.cumsum(buy, dtype=np.float64)])
    c_sell = np.concatenate([[0.0], np.cumsum(sell, dtype=np.float64)])
    return lr, c_lr2, c_buy, c_sell


def add_market_state(events: pd.DataFrame, sims: dict) -> pd.DataFrame:
    """
    Attach trailing market state at t0 for every event.

    `sims` maps venue name to the SimOutput for that venue.
    """
    ev = events.copy()
    cols = {c: np.full(len(ev), np.nan) for c in
            ("mid0", "spread_bps", "rv_60s_bps", "rv_300s_bps",
             "ofi_60s", "signed_trend_60s_bps")}

    for venue, out in sims.items():
        mask = (ev["venue"] == venue).to_numpy()
        if not mask.any():
            continue
        _, c_lr2, c_buy, c_sell = _rolling_state(out.mid, out.buy_vol, out.sell_vol)
        t0 = ev.loc[mask, "t0"].to_numpy().astype(int)
        sign = np.where(ev.loc[mask, "side"].to_numpy() == "bid", 1.0, -1.0)

        a60 = np.maximum(t0 - 60, 0)
        a300 = np.maximum(t0 - 300, 0)

        mid0 = out.mid[t0]
        cols["mid0"][mask] = mid0
        cols["spread_bps"][mask] = (out.best_ask[t0] - out.best_bid[t0]) / mid0 * 1e4
        cols["rv_60s_bps"][mask] = np.sqrt(
            np.maximum(c_lr2[t0 + 1] - c_lr2[a60], 0.0) / np.maximum(t0 - a60, 1)) * 1e4
        cols["rv_300s_bps"][mask] = np.sqrt(
            np.maximum(c_lr2[t0 + 1] - c_lr2[a300], 0.0) / np.maximum(t0 - a300, 1)) * 1e4

        b = c_buy[t0 + 1] - c_buy[a60]
        s = c_sell[t0 + 1] - c_sell[a60]
        cols["ofi_60s"][mask] = (b - s) / np.maximum(b + s, 1e-9)
        cols["signed_trend_60s_bps"][mask] = \
            sign * (mid0 / out.mid[a60] - 1.0) * 1e4

    for k, v in cols.items():
        ev[k] = v
    return ev


# ----------------------------------------------------------------------------
# Repeat size signatures, strictly backward looking
# ----------------------------------------------------------------------------

def add_size_signature(events: pd.DataFrame, window_h: float = 6.0,
                       tol: float = 0.015) -> pd.DataFrame:
    """
    For each event, count earlier large levels on the same venue whose estimated
    size at first sighting was within `tol` of this one, inside the trailing
    window. Repeated sizes are the crudest possible participant fingerprint, but
    they are the only one public data supports.

    Only events with a strictly earlier t0 are counted, so there is no lookahead.
    """
    ev = events.sort_values(["venue", "t0"]).copy()
    ev["sig_repeat_6h"] = 0
    ev["sig_repeat_share_6h"] = 0.0
    win = int(window_h * 3600)

    for venue, grp in ev.groupby("venue", sort=False):
        idx = grp.index.to_numpy()
        t0 = grp["t0"].to_numpy().astype(np.int64)
        sz = grp["excess0_btc"].to_numpy()

        lo = np.searchsorted(t0, t0 - win, side="left")
        counts = np.zeros(len(idx), dtype=int)
        totals = np.zeros(len(idx), dtype=int)
        for j in range(len(idx)):
            a = lo[j]
            if j <= a:
                continue
            prior = sz[a:j]
            totals[j] = len(prior)
            counts[j] = int(np.sum(np.abs(prior - sz[j]) <= tol * sz[j]))

        ev.loc[idx, "sig_repeat_6h"] = counts
        ev.loc[idx, "sig_repeat_share_6h"] = counts / np.maximum(totals, 1)

    return ev.sort_index()


# ----------------------------------------------------------------------------
# Forward returns (outcomes, not features)
# ----------------------------------------------------------------------------

def add_forward_returns(events: pd.DataFrame, sims: dict,
                        horizons=config.HORIZONS_S) -> pd.DataFrame:
    """Signed forward mid returns in basis points at each horizon after t0."""
    ev = events.copy()
    for h in horizons:
        ev[f"fwd_{h}s_bps"] = np.nan

    for venue, out in sims.items():
        mask = (ev["venue"] == venue).to_numpy()
        if not mask.any():
            continue
        n = out.n_seconds
        t0 = ev.loc[mask, "t0"].to_numpy().astype(int)
        sign = np.where(ev.loc[mask, "side"].to_numpy() == "bid", 1.0, -1.0)
        m0 = out.mid[t0]
        for h in horizons:
            th = np.minimum(t0 + h, n - 1)
            r = sign * (out.mid[th] / m0 - 1.0) * 1e4
            r = np.where(t0 + h < n, r, np.nan)
            ev.loc[mask, f"fwd_{h}s_bps"] = r

    hs = list(horizons)
    if 10 in hs and 60 in hs:
        ev["reversal_10s_60s_bps"] = ev["fwd_60s_bps"] - ev["fwd_10s_bps"]
    return ev


# ----------------------------------------------------------------------------
# Feature matrix
# ----------------------------------------------------------------------------

def build_feature_matrix(events: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Assemble X and y, and refuse to hand back anything that leaks."""
    leaked = OUTCOME_COLUMNS.intersection(FEATURE_COLUMNS)
    if leaked:
        raise ValueError(f"outcome columns present in the feature list: {sorted(leaked)}")

    ev = events.copy()

    ev["log_excess0"] = np.log(np.maximum(ev["excess0_btc"], 1e-6))
    ev["log_size_ratio0"] = np.log(np.maximum(ev["size_ratio0"], 1e-6))
    ev["dist0_bps"] = ev["dist0_buckets"] * config.BUCKET_USDT / ev["mid0"] * 1e4

    same = np.where(ev["side"] == "bid", ev["bid_depth0_btc"], ev["ask_depth0_btc"])
    tot = ev["bid_depth0_btc"] + ev["ask_depth0_btc"]
    ev["same_side_depth_share"] = same / np.maximum(tot, 1e-9)

    ang = 2.0 * np.pi * ev["hour_utc"] / 24.0
    ev["hour_sin"], ev["hour_cos"] = np.sin(ang), np.cos(ang)
    ev["is_bid"] = (ev["side"] == "bid").astype(int)
    ev["is_hyperliquid"] = (ev["venue"] == "hyperliquid").astype(int)

    X = ev[FEATURE_COLUMNS].astype(float)
    y = ev["is_ghost"].astype(int)
    return X, y
