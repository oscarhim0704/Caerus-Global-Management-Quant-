"""
Simulated order book and trade tape for BTC/USDT perpetuals.

This module exists because live collection was impossible in the build
environment. It is a stand in for src/fetch_live.py and it emits records with
the same schema, so the rest of the pipeline does not know or care which one
produced them.

What the simulator models
-------------------------
1. A mid price made of a diffusive component with intraday volatility
   seasonality and occasional jumps, plus a transient component that resting
   spoof orders push around and that decays with a 30 second half life. The
   transient is what produces the push then revert pattern the forward return
   study looks for.
2. Background resting depth per price bucket, as an AR(1) around a profile that
   grows with distance from mid. This is the ordinary liquidity that the
   detector has to see through.
3. Large resting orders of two hidden types:
      genuine  placed to be filled, long lived, pulled only occasionally
      spoof    placed away from the touch, cancelled when price approaches
   The type is recorded as ground truth but is NEVER passed to the detector or
   the classifier. It is used only in the evaluation step, to measure how often
   the observable heuristic is wrong. In live trading that column does not
   exist, which is the single most important caveat in the whole project.
4. A trade tape. Without trades there is no way to separate a cancellation from
   a fill, so aggressive volume is tracked per price bucket per second.

Deliberate overlap
------------------
Genuine orders are also pulled as price approaches (config genuine_pull_prob)
and spoofs sometimes get filled when price gaps through them before the cancel
fires. Without that overlap the two populations separate perfectly and every
classifier scores an AUC of 1.0, which would be a meaningless result. The
overlap is a modelling choice, not an empirical finding.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.signal import lfilter

from . import config


# ----------------------------------------------------------------------------
# Records
# ----------------------------------------------------------------------------

@dataclass
class LargeOrder:
    """A single large resting order. `true_type` is hidden ground truth."""
    oid: int
    venue: str
    side: str                # "bid" or "ask"
    abs_id: int              # absolute price bucket
    price: float
    size: float              # original size in BTC
    remaining: float
    placed_t: int
    true_type: str           # "genuine" or "spoof"
    participant: str         # signature label, or "adhoc"
    life_budget: int         # seconds before an unconditional cancel
    filled: float = 0.0
    end_t: int | None = None
    end_reason: str | None = None
    min_dist: float = 99.0      # closest the mid ever came, in buckets
    cur_dist: float = 99.0      # distance right now, in buckets
    pinned_s: int = 0           # seconds spent holding price at its level
    sample_window: bool = False


@dataclass
class SimOutput:
    """Everything a simulated venue run produces."""
    venue: str
    n_seconds: int
    start_ts: pd.Timestamp
    mid: np.ndarray = field(default=None)
    best_bid: np.ndarray = field(default=None)
    best_ask: np.ndarray = field(default=None)
    buy_vol: np.ndarray = field(default=None)
    sell_vol: np.ndarray = field(default=None)
    truth: list = field(default_factory=list)
    raw_sample: list = field(default_factory=list)
    windows: list = field(default_factory=list)


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _depth_target(venue: str, dist: int) -> float:
    """Expected background size, in BTC, in the bucket `dist` away from mid."""
    s = config.SIM
    return s["depth_base"][venue] + s["depth_slope"][venue] * dist


def _background_paths(venue: str, n: int, rng: np.random.Generator,
                      vol_mult: np.ndarray) -> np.ndarray:
    """
    AR(1) background depth for the 10 distance indices on one side.

    Returns an array of shape (10, n), float32. Uses lfilter rather than a
    Python loop because the recursion is linear and n is around 700k.
    """
    s = config.SIM
    k = s["depth_mean_reversion"]
    sig = s["depth_lognorm_sigma"]

    out = np.empty((config.N_LEVELS, n), dtype=np.float32)
    for i in range(config.N_LEVELS):
        target = _depth_target(venue, i)
        noise = rng.lognormal(mean=-0.5 * sig ** 2, sigma=sig, size=n)
        # depth thins slightly when the market is fast, which is realistic and
        # also stops the "large" threshold from being trivially constant
        drive = target * noise / np.sqrt(vol_mult)
        series = lfilter([k], [1.0, -(1.0 - k)], drive, zi=[target * (1 - k)])[0]
        out[i] = np.maximum(series, 0.05 * target).astype(np.float32)
    return out


def _spoof_rate_by_hour(venue: str) -> np.ndarray:
    """
    Per second spoof arrival rate by UTC hour, built so that `cluster_share` of
    all spoofs land in the `cluster_hours` window while the overall hourly mean
    still equals `spoof_per_hour`.
    """
    s = config.SIM
    hours = np.arange(24)
    in_cluster = np.isin(hours, s["cluster_hours"])
    n_c, n_o = in_cluster.sum(), 24 - in_cluster.sum()

    share_c, share_o = s["cluster_share"], 1.0 - s["cluster_share"]
    ratio = (share_c / n_c) / (share_o / n_o)

    weights = np.where(in_cluster, ratio, 1.0)
    weights = weights / weights.mean()
    return s["spoof_per_hour"][venue] * weights / 3600.0


# ----------------------------------------------------------------------------
# Main simulation
# ----------------------------------------------------------------------------

def simulate_venue(venue: str, seed_offset: int = 0):
    """
    Generator. Yields one record per second and stores the run level output on
    the `.out` attribute of the generator function object once exhausted.

    Each yielded record is a tuple:
        (t, mid_bucket, mid, best_bid, best_ask,
         bid_sizes[10], ask_sizes[10], traded)
    where `traded` maps (side, abs_id) to BTC traded in that bucket that second.
    """
    s = config.SIM
    n = config.N_SECONDS
    w = config.BUCKET_USDT
    rng = np.random.default_rng(s["seed"] + seed_offset)

    start_ts = pd.Timestamp(config.START_UTC, tz="UTC")
    start_hour = start_ts.hour

    # --- exogenous series ---------------------------------------------------
    hour_of = ((np.arange(n) // 3600) + start_hour) % 24
    vol_mult = np.asarray(s["vol_by_hour"], dtype=float)[hour_of]

    sigma_1s = s["daily_vol"] / math.sqrt(86400.0)
    z = rng.standard_normal(n) * sigma_1s * vol_mult

    n_jumps = rng.poisson(s["jumps_per_day"] * config.N_DAYS)
    jump_at = rng.integers(0, n, size=n_jumps)
    jump_sz = (rng.standard_normal(n_jumps) * s["jump_bp_mean"] / 1e4)
    jumps = np.zeros(n)
    np.add.at(jumps, jump_at, jump_sz)

    log_fund = np.cumsum(z + jumps)

    vol_noise = rng.lognormal(-0.5 * s["trade_vol_lognorm_sigma"] ** 2,
                              s["trade_vol_lognorm_sigma"], size=n)
    base_vol = s["trade_vol_per_s"][venue] * vol_mult * vol_noise

    bg_bid = _background_paths(venue, n, rng, vol_mult)
    bg_ask = _background_paths(venue, n, rng, vol_mult)

    # --- large order arrival schedule ---------------------------------------
    lam_gen = s["genuine_per_hour"][venue] / 3600.0
    lam_spf_hour = _spoof_rate_by_hour(venue)
    lam_spf = lam_spf_hour[hour_of]

    arrivals = {}   # t -> list of (side, true_type)
    for side in ("bid", "ask"):
        gen_hits = np.flatnonzero(rng.random(n) < lam_gen)
        spf_hits = np.flatnonzero(rng.random(n) < lam_spf)
        for t in gen_hits:
            arrivals.setdefault(int(t), []).append((side, "genuine"))
        for t in spf_hits:
            arrivals.setdefault(int(t), []).append((side, "spoof"))

    # --- state --------------------------------------------------------------
    out = SimOutput(venue=venue, n_seconds=n, start_ts=start_ts)
    mid_arr = np.empty(n)
    bb_arr = np.empty(n)
    ba_arr = np.empty(n)
    buy_arr = np.empty(n, dtype=np.float32)
    sell_arr = np.empty(n, dtype=np.float32)

    active: list[LargeOrder] = []
    transient_bp = 0.0
    pin_adjust = 0.0          # cumulative log price shift caused by resting walls
    decay = math.exp(-math.log(2.0) / s["transient_halflife_s"])
    oid = 0
    prev_mid = config.REF_PRICE
    half_spread = config.RAW_TICK[venue] / 2.0

    raw_sample_until = int(s["raw_sample_hours"] * 3600)
    sig_sizes = s["signature_sizes"][venue]

    for t in range(n):
        # 1. price pressure exerted by spoofs resting at the START of this second
        push = 0.0
        for o in active:
            if o.true_type == "spoof":
                d = max(o.cur_dist, 1.0)
                rel = o.remaining / max(_depth_target(venue, int(round(d))), 1e-6)
                push += (1.0 if o.side == "bid" else -1.0) * \
                        s["spoof_push_bp_per_s"] * rel / d
        transient_bp = float(np.clip(transient_bp * decay + push,
                                     -s["max_transient_bp"], s["max_transient_bp"]))

        # A large resting order is a wall. Price cannot walk through size that
        # has not traded, so the mid is held at the order until it is filled or
        # pulled. The offset is folded into pin_adjust rather than released as a
        # gap, which is what real support and resistance does to a price path.
        mid_raw = config.REF_PRICE * math.exp(log_fund[t] + transient_bp / 1e4 + pin_adjust)

        bid_wall, ask_wall, wall_o = -np.inf, np.inf, None
        for o in active:
            if o.remaining <= 1e-9 or o.pinned_s > s["max_pin_s"]:
                continue
            if o.side == "bid" and mid_raw < o.price and o.price > bid_wall:
                bid_wall, wall_o = o.price, o
            elif o.side == "ask" and mid_raw > o.price and o.price < ask_wall:
                ask_wall, wall_o = o.price, o

        mid = mid_raw
        if bid_wall > -np.inf and (ask_wall == np.inf or bid_wall < ask_wall):
            pin_adjust += math.log(bid_wall / mid_raw)
            mid = bid_wall
        elif ask_wall < np.inf:
            pin_adjust += math.log(ask_wall / mid_raw)
            mid = ask_wall
        if wall_o is not None and mid != mid_raw:
            wall_o.pinned_s += 1

        m = int(mid // w)

        # 2. aggressive volume, tilted in the direction price actually moved
        dP = (mid - prev_mid) / max(prev_mid, 1.0)
        tilt = 0.35 * math.tanh(dP / max(sigma_1s * vol_mult[t], 1e-9) / 2.0)
        total_v = float(base_vol[t])
        buy_v = total_v * (0.5 + tilt)
        sell_v = total_v * (0.5 - tilt)

        traded: dict[tuple[str, int], float] = {}

        # 3. fills against large orders that price has reached
        #    a bid is exposed once the mid has fallen into or below its bucket
        rem_sell = sell_v * s["large_order_fill_share"]
        rem_buy = buy_v * s["large_order_fill_share"]
        for o in sorted(active, key=lambda x: -x.abs_id if x.side == "bid" else x.abs_id):
            dist = (m - o.abs_id) if o.side == "bid" else (o.abs_id - m)
            o.cur_dist = float(dist)
            o.min_dist = min(o.min_dist, float(dist))
            if dist > 0:
                continue
            if o.side == "bid" and rem_sell > 0:
                f = min(o.remaining, rem_sell)
                o.remaining -= f
                o.filled += f
                rem_sell -= f
                traded[("bid", o.abs_id)] = traded.get(("bid", o.abs_id), 0.0) + f
            elif o.side == "ask" and rem_buy > 0:
                f = min(o.remaining, rem_buy)
                o.remaining -= f
                o.filled += f
                rem_buy -= f
                traded[("ask", o.abs_id)] = traded.get(("ask", o.abs_id), 0.0) + f

        # background trading, spread across the buckets price swept this second
        lo_b, hi_b = sorted((int(prev_mid // w), m))
        span = list(range(lo_b, hi_b + 1)) or [m]
        bg_sell = (sell_v - (sell_v * s["large_order_fill_share"] - rem_sell)) / len(span)
        bg_buy = (buy_v - (buy_v * s["large_order_fill_share"] - rem_buy)) / len(span)
        for b in span:
            traded[("bid", b)] = traded.get(("bid", b), 0.0) + bg_sell
            traded[("ask", b)] = traded.get(("ask", b), 0.0) + bg_buy

        # 4. cancellations
        still: list[LargeOrder] = []
        for o in active:
            dist = (m - o.abs_id) if o.side == "bid" else (o.abs_id - m)
            age = t - o.placed_t
            gone = False

            if o.remaining <= 1e-9:
                o.end_t, o.end_reason, gone = t, "filled", True
            elif o.true_type == "spoof":
                if dist <= s["spoof_cancel_dist"] and rng.random() < s["spoof_cancel_prob"]:
                    o.end_t, o.end_reason, gone = t, "cancelled", True
                elif age >= o.life_budget:
                    o.end_t, o.end_reason, gone = t, "cancelled", True
            else:
                if dist <= s["genuine_pull_dist"] and rng.random() < s["genuine_pull_prob"]:
                    o.end_t, o.end_reason, gone = t, "cancelled", True
                elif age >= o.life_budget:
                    o.end_t, o.end_reason, gone = t, "cancelled", True

            if gone:
                out.truth.append(o)
            else:
                still.append(o)
        active = still

        # 5. new arrivals, visible from this snapshot onward
        for side, ttype in arrivals.get(t, ()):
            lo, hi = s["spoof_dist_range"] if ttype == "spoof" else s["genuine_dist_range"]
            d = int(rng.integers(lo, hi + 1))
            abs_id = (m - d) if side == "bid" else (m + d)

            if ttype == "spoof" and rng.random() < s["signature_share"]:
                k_sig = int(rng.integers(0, len(sig_sizes)))
                size = sig_sizes[k_sig] * (1.0 + rng.normal(0.0, 0.015))
                participant = f"P{k_sig + 1}"
            else:
                mult = s["spoof_size_mult"] if ttype == "spoof" else s["genuine_size_mult"]
                size = mult * _depth_target(venue, d) * rng.lognormal(
                    -0.5 * s["size_lognorm_sigma"] ** 2, s["size_lognorm_sigma"])
                participant = "adhoc"

            life_mean = s["spoof_life_mean_s"] if ttype == "spoof" else s["genuine_life_mean_s"]
            oid += 1
            active.append(LargeOrder(
                oid=oid, venue=venue, side=side, abs_id=abs_id,
                price=(abs_id + 0.5) * w, size=float(size), remaining=float(size),
                placed_t=t, true_type=ttype, participant=participant,
                life_budget=int(rng.exponential(life_mean)) + 2,
                min_dist=float(d), cur_dist=float(d),
                sample_window=bool(rng.random() < 0.03),
            ))

        # 6. assemble the visible top 10 buckets per side
        bid_sizes = bg_bid[:, t].astype(np.float64).copy()
        ask_sizes = bg_ask[:, t].astype(np.float64).copy()
        for o in active:
            d = (m - o.abs_id) if o.side == "bid" else (o.abs_id - m)
            if 0 <= d < config.N_LEVELS:
                if o.side == "bid":
                    bid_sizes[d] += o.remaining
                else:
                    ask_sizes[d] += o.remaining

        best_bid, best_ask = mid - half_spread, mid + half_spread
        mid_arr[t], bb_arr[t], ba_arr[t] = mid, best_bid, best_ask
        buy_arr[t], sell_arr[t] = buy_v, sell_v

        if t < raw_sample_until:
            out.raw_sample.append((t, mid, best_bid, best_ask,
                                   bid_sizes.copy(), ask_sizes.copy()))

        for o in active:
            if o.sample_window and 0 <= (t - o.placed_t) <= 240:
                out.windows.append((o.oid, t - o.placed_t, t, mid,
                                    bid_sizes.copy(), ask_sizes.copy()))

        yield (t, m, mid, best_bid, best_ask, bid_sizes, ask_sizes, traded)
        prev_mid = mid

    # orders still resting at the end of the sample are right censored
    for o in active:
        o.end_t, o.end_reason = n - 1, "censored"
        out.truth.append(o)

    out.mid, out.best_bid, out.best_ask = mid_arr, bb_arr, ba_arr
    out.buy_vol, out.sell_vol = buy_arr, sell_arr
    simulate_venue.last_output = out


def truth_frame(out: SimOutput) -> pd.DataFrame:
    """Ground truth table. Used only for evaluation, never as a model input."""
    rows = []
    for o in out.truth:
        rows.append({
            "oid": o.oid, "venue": o.venue, "side": o.side, "abs_id": o.abs_id,
            "price": o.price, "size_btc": o.size, "placed_t": o.placed_t,
            "end_t": o.end_t, "end_reason": o.end_reason,
            "filled_btc": o.filled, "min_dist_buckets": o.min_dist,
            "true_type": o.true_type, "participant": o.participant,
            "life_s": (o.end_t - o.placed_t) if o.end_t is not None else None,
        })
    return pd.DataFrame(rows).sort_values("placed_t").reset_index(drop=True)
