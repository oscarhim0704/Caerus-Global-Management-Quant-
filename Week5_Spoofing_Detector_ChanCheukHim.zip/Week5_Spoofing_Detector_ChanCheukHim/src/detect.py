"""
Turn reconstructed level lifecycles into a labelled event table.

Event definitions used throughout the project
---------------------------------------------
large level
    A price bucket whose resting size exceeds both `large_mult` times the
    trailing median depth at the same distance from mid, and an absolute floor
    in BTC. The floor stops thin far side buckets from generating events every
    time a normal sized order lands somewhere quiet.

estimated order size (peak excess)
    Peak bucket size minus the trailing median at that distance. This is an
    estimate of the large order alone, stripped of the background depth that
    would have been there anyway.

fill share
    Volume traded in that bucket during the level's life, capped at the peak
    excess, divided by the peak excess. Anything the tape did not account for
    is treated as cancelled.

ghost level
    A large level that (a) disappeared while still visible or was crossed by
    price, (b) had a fill share below `max_fill_frac`, and (c) had the mid come
    within `approach_buckets` of it at some point. In words: it was big, price
    came for it, and it left without trading.

What a ghost level is not
-------------------------
It is not proof of spoofing. A market maker pulling quotes ahead of a move,
an iceberg refreshing, an order cancelled because the trader's own signal
flipped, and a genuine spoof all look the same in public data. The heuristic
is a screen, not a verdict. The evaluation in classify.py measures how far
apart those two things are, using the simulator's hidden intent flag, which is
a luxury that does not exist on live data.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import config
from .book_tracker import LevelTrack


CATEGORIES = ("ghost", "filled", "pulled_away_from_price", "left_window", "censored")


def classify_track(tr: LevelTrack, cfg: dict | None = None) -> tuple[str, float, int]:
    """Return (category, fill_share, life_seconds) for one closed track."""
    cfg = cfg or config.DETECT
    life = int((tr.end_t or tr.last_t) - tr.t0)
    peak = max(tr.peak_excess, 1e-9)
    fill_share = float(min(tr.traded_btc, peak) / peak)

    if tr.end_reason == "censored":
        return "censored", fill_share, life
    if life < cfg["min_life_s"]:
        return "censored", fill_share, life
    if tr.end_reason == "left_window":
        return "left_window", fill_share, life
    if fill_share >= cfg["max_fill_frac"]:
        return "filled", fill_share, life
    if tr.min_dist > cfg["approach_buckets"]:
        return "pulled_away_from_price", fill_share, life
    return "ghost", fill_share, life


def tracks_to_frame(tracks: list[LevelTrack], start_ts: pd.Timestamp,
                    cfg: dict | None = None) -> pd.DataFrame:
    """Flatten closed tracks into the labelled event table."""
    cfg = cfg or config.DETECT
    rows = []
    for tr in tracks:
        cat, fill_share, life = classify_track(tr, cfg)
        rows.append({
            "venue": tr.venue,
            "side": tr.side,
            "abs_id": tr.abs_id,
            "price": tr.price,
            "t0": tr.t0,
            "t_end": tr.end_t,
            "ts0": start_ts + pd.Timedelta(seconds=int(tr.t0)),
            "hour_utc": (start_ts + pd.Timedelta(seconds=int(tr.t0))).hour,
            "life_s": life,
            "dist0_buckets": tr.dist0,
            "min_dist_buckets": tr.min_dist,
            "max_dist_buckets": tr.max_dist,
            "base_depth0_btc": tr.base0,
            "size0_btc": tr.size0,
            "excess0_btc": max(tr.excess0, 1e-6),   # order size estimate at t0, a valid feature
            "est_order_btc": tr.peak_excess,
            "size_ratio0": tr.size0 / max(tr.base0, 1e-9),
            "traded_in_bucket_btc": tr.traded_btc,
            "fill_share": fill_share,
            "bid_depth0_btc": tr.bid_total0,
            "ask_depth0_btc": tr.ask_total0,
            "n_other_large0": tr.n_other_large0,
            "end_reason": tr.end_reason,
            "event_category": cat,
            "is_ghost": int(cat == "ghost"),
        })
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    return df.sort_values(["venue", "t0"]).reset_index(drop=True)


# ----------------------------------------------------------------------------
# Ground truth matching (evaluation only)
# ----------------------------------------------------------------------------

def attach_ground_truth(events: pd.DataFrame, truth: pd.DataFrame) -> pd.DataFrame:
    """
    Join each detected event to the simulated order that produced it.

    Matching is on venue, side and absolute price bucket, with the event's
    detection time inside the order's resting interval. Where more than one
    order qualifies the largest is kept, because that is the one driving the
    bucket size. Events with no match are background depth fluctuations that
    happened to clear the threshold, so they are genuine false alarms of the
    size screen itself and are labelled `none`.

    This column is only available because the data is simulated. Nothing
    upstream of the evaluation is allowed to read it.
    """
    if events.empty:
        return events

    ev = events.copy()
    ev["true_type"] = "none"
    ev["true_participant"] = "none"
    ev["true_size_btc"] = np.nan
    ev["true_end_reason"] = "none"

    for (venue, side), grp in truth.groupby(["venue", "side"], sort=False):
        idx = ev.index[(ev["venue"] == venue) & (ev["side"] == side)]
        if len(idx) == 0:
            continue
        by_bucket: dict[int, list] = {}
        for r in grp.itertuples(index=False):
            by_bucket.setdefault(int(r.abs_id), []).append(r)

        for i in idx:
            cands = by_bucket.get(int(ev.at[i, "abs_id"]))
            if not cands:
                continue
            t0 = ev.at[i, "t0"]
            hits = [c for c in cands if c.placed_t <= t0 <= (c.end_t or t0)]
            if not hits:
                continue
            best = max(hits, key=lambda c: c.size_btc)
            ev.at[i, "true_type"] = best.true_type
            ev.at[i, "true_participant"] = best.participant
            ev.at[i, "true_size_btc"] = best.size_btc
            ev.at[i, "true_end_reason"] = best.end_reason

    ev["true_is_spoof"] = (ev["true_type"] == "spoof").astype(int)
    return ev


def heuristic_confusion(ev: pd.DataFrame) -> pd.DataFrame:
    """
    How well does the observable ghost rule agree with hidden intent?

    Censored and left_window events are dropped because the rule never gets to
    make a call on them.
    """
    d = ev[~ev["event_category"].isin(["censored", "left_window"])]
    tab = pd.crosstab(d["is_ghost"], d["true_type"])
    tab.index = ["not flagged", "flagged as ghost"]
    tab.index.name = "ghost_rule"
    return tab


def heuristic_scores(ev: pd.DataFrame) -> dict:
    """Precision, recall and false positive rate of the ghost rule vs intent."""
    d = ev[~ev["event_category"].isin(["censored", "left_window"])]
    y = (d["true_type"] == "spoof").astype(int).to_numpy()
    p = d["is_ghost"].to_numpy()

    tp = int(((p == 1) & (y == 1)).sum())
    fp = int(((p == 1) & (y == 0)).sum())
    fn = int(((p == 0) & (y == 1)).sum())
    tn = int(((p == 0) & (y == 0)).sum())

    return {
        "n_events": int(len(d)),
        "true_spoof_rate": float(y.mean()) if len(y) else float("nan"),
        "flag_rate": float(p.mean()) if len(p) else float("nan"),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "precision": tp / (tp + fp) if (tp + fp) else float("nan"),
        "recall": tp / (tp + fn) if (tp + fn) else float("nan"),
        "false_positive_rate": fp / (fp + tn) if (fp + tn) else float("nan"),
    }
