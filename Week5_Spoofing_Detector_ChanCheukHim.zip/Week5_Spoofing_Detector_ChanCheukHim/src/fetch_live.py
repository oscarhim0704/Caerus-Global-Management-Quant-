"""
Live order book collector for BTC/USDT perpetuals on Binance and Hyperliquid.

THIS MODULE DID NOT RUN. The environment I built the project in blocks
outbound connections to both exchanges (the proxy returns 403 with
x-deny-reason: host_not_allowed). Every number in the analysis therefore comes
from src/simulate.py, not from here. I have kept this module in the package
because it is the piece that would be swapped in first on a machine with
network access, and because the downstream code reads the schema it writes.

Design notes
------------
* Binance publishes a partial book depth stream. The venue tick size for
  BTCUSDT perpetuals is 0.10 USDT, so 10 raw levels span about 1 USDT. That is
  far too narrow to see an order before price reaches it, so I pull the deeper
  REST snapshot (limit=1000, about 100 USDT of depth) once per second and
  aggregate it into the fixed width buckets the rest of the pipeline uses. The
  top 10 raw levels are stored alongside, unaggregated, because the brief asked
  for them.
* Hyperliquid pushes the full L2 book over websocket on change. I resample it
  to the same one second grid.
* The trade tape is collected in parallel on both venues. Without it there is
  no way to tell a cancellation from a fill, which is the whole detection
  problem, so it is not optional.

Rate limits: the Binance futures depth endpoint at limit=1000 costs 20 request
weight, and the limit is 2400 weight per minute per IP, so one call per second
is 1200 weight per minute. That fits, but it leaves little headroom, which is
why the websocket diff stream is the better long run option.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import config

BINANCE_REST = "https://fapi.binance.com"
BINANCE_WS = "wss://fstream.binance.com/ws"
HYPERLIQUID_REST = "https://api.hyperliquid.xyz/info"
HYPERLIQUID_WS = "wss://api.hyperliquid.xyz/ws"


# ----------------------------------------------------------------------------
# Venue metadata
# ----------------------------------------------------------------------------

def binance_tick_size(symbol: str = "BTCUSDT") -> float:
    """Read the live tick size instead of hard coding it."""
    import requests

    r = requests.get(f"{BINANCE_REST}/fapi/v1/exchangeInfo", timeout=10)
    r.raise_for_status()
    for s in r.json()["symbols"]:
        if s["symbol"] == symbol:
            for f in s["filters"]:
                if f["filterType"] == "PRICE_FILTER":
                    return float(f["tickSize"])
    raise KeyError(f"symbol {symbol} not found in exchangeInfo")


def hyperliquid_meta(coin: str = "BTC") -> dict:
    """Universe metadata, used for size decimals and the price grid."""
    import requests

    r = requests.post(HYPERLIQUID_REST, json={"type": "meta"}, timeout=10)
    r.raise_for_status()
    for asset in r.json()["universe"]:
        if asset["name"] == coin:
            return asset
    raise KeyError(f"coin {coin} not found in Hyperliquid meta")


# ----------------------------------------------------------------------------
# Snapshot polling
# ----------------------------------------------------------------------------

def binance_depth(symbol: str = "BTCUSDT", limit: int = 1000) -> dict:
    """One REST depth snapshot. Returns the raw payload plus a receive stamp."""
    import requests

    t0 = time.time()
    r = requests.get(
        f"{BINANCE_REST}/fapi/v1/depth",
        params={"symbol": symbol, "limit": limit},
        timeout=5,
    )
    r.raise_for_status()
    payload = r.json()
    payload["_recv_ts"] = time.time()
    payload["_latency_s"] = payload["_recv_ts"] - t0
    return payload


def hyperliquid_l2(coin: str = "BTC") -> dict:
    """One REST L2 book snapshot from Hyperliquid."""
    import requests

    t0 = time.time()
    r = requests.post(HYPERLIQUID_REST, json={"type": "l2Book", "coin": coin}, timeout=5)
    r.raise_for_status()
    payload = r.json()
    payload["_recv_ts"] = time.time()
    payload["_latency_s"] = payload["_recv_ts"] - t0
    return payload


# ----------------------------------------------------------------------------
# Bucket aggregation, shared with the simulator
# ----------------------------------------------------------------------------

def bucket_id(price: float, width: float = config.BUCKET_USDT) -> int:
    """Absolute price bucket index. Stable as mid moves, which is the point."""
    return int(price // width)


def aggregate_side(levels, side: str, mid: float, n_levels: int = config.N_LEVELS,
                   width: float = config.BUCKET_USDT):
    """
    Collapse raw (price, size) levels into fixed width buckets and return the
    n_levels buckets nearest the mid on the given side.

    Returns a list of dicts with abs_id, price (bucket centre), size.
    """
    agg: dict[int, float] = {}
    for price, size in levels:
        price, size = float(price), float(size)
        if size <= 0:
            continue
        agg[bucket_id(price, width)] = agg.get(bucket_id(price, width), 0.0) + size

    if side == "bid":
        keys = sorted((k for k in agg if k * width < mid), reverse=True)
    else:
        keys = sorted(k for k in agg if (k + 1) * width > mid)

    out = []
    for k in keys[:n_levels]:
        out.append({"abs_id": k, "price": (k + 0.5) * width, "size": agg[k]})
    return out


def normalise_binance(payload: dict) -> dict:
    bids = [(float(p), float(q)) for p, q in payload["bids"]]
    asks = [(float(p), float(q)) for p, q in payload["asks"]]
    mid = (bids[0][0] + asks[0][0]) / 2.0
    return {
        "ts": payload["_recv_ts"],
        "venue": "binance",
        "mid": mid,
        "best_bid": bids[0][0],
        "best_ask": asks[0][0],
        "raw_top10_bids": bids[:10],
        "raw_top10_asks": asks[:10],
        "bid_buckets": aggregate_side(bids, "bid", mid),
        "ask_buckets": aggregate_side(asks, "ask", mid),
    }


def normalise_hyperliquid(payload: dict) -> dict:
    book = payload["levels"]
    bids = [(float(lv["px"]), float(lv["sz"])) for lv in book[0]]
    asks = [(float(lv["px"]), float(lv["sz"])) for lv in book[1]]
    mid = (bids[0][0] + asks[0][0]) / 2.0
    return {
        "ts": payload["_recv_ts"],
        "venue": "hyperliquid",
        "mid": mid,
        "best_bid": bids[0][0],
        "best_ask": asks[0][0],
        "raw_top10_bids": bids[:10],
        "raw_top10_asks": asks[:10],
        "bid_buckets": aggregate_side(bids, "bid", mid),
        "ask_buckets": aggregate_side(asks, "ask", mid),
    }


# ----------------------------------------------------------------------------
# Trade tape
# ----------------------------------------------------------------------------

BINANCE_TRADE_SUB = {"method": "SUBSCRIBE", "params": ["btcusdt@aggTrade"], "id": 1}
HYPERLIQUID_TRADE_SUB = {"method": "subscribe",
                         "subscription": {"type": "trades", "coin": "BTC"}}
HYPERLIQUID_BOOK_SUB = {"method": "subscribe",
                        "subscription": {"type": "l2Book", "coin": "BTC"}}


@dataclass
class TradeBuffer:
    """
    Accumulates trades into one second buckets keyed by price bucket, which is
    exactly the aggregation the detector needs to split fills from cancels.
    """
    width: float = config.BUCKET_USDT
    rows: list = field(default_factory=list)

    def add(self, ts: float, price: float, size: float, aggressor: str) -> None:
        self.rows.append({
            "second": int(ts),
            "abs_id": bucket_id(price, self.width),
            "aggressor": aggressor,          # "buy" or "sell"
            "size": size,
        })

    def drain_to_parquet(self, path: Path) -> None:
        import pandas as pd

        if not self.rows:
            return
        df = pd.DataFrame(self.rows)
        df = df.groupby(["second", "abs_id", "aggressor"], as_index=False)["size"].sum()
        df.to_parquet(path, index=False)
        self.rows.clear()


def run_collector(venue: str, minutes: int, out_dir: Path = config.DATA_RAW) -> None:
    """
    Skeleton of the collection loop. Kept deliberately simple: poll depth on a
    one second grid, stream trades, flush both to parquet every 15 minutes.

    Not executed for this submission. On a networked machine the entry point is
    `python -m src.fetch_live binance 600`.
    """
    raise NotImplementedError(
        "Live collection was not run for this submission. The build environment "
        "blocks fapi.binance.com and api.hyperliquid.xyz. Use src/simulate.py, "
        "and see README.md section 'Data provenance'."
    )


if __name__ == "__main__":  # pragma: no cover
    import sys

    print(__doc__)
    if len(sys.argv) > 1:
        run_collector(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 60)
