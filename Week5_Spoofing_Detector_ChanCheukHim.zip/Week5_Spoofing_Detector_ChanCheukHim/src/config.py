"""
Central configuration for the Week 5 latent liquidity and spoofing pipeline.

Everything that I might want to change lives here so that the notebook can
re-run the pipeline under different thresholds without editing the modules.

IMPORTANT: the machine this was built on has no outbound network access to
exchange hosts, so the numbers in SIM below drive a simulator that stands in
for real Binance and Hyperliquid data. See README.md for the full disclosure.
"""

from pathlib import Path

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROC = ROOT / "data" / "processed"
OUT_FIG = ROOT / "outputs" / "figures"
OUT_TAB = ROOT / "outputs" / "tables"

for _p in (DATA_RAW, DATA_PROC, OUT_FIG, OUT_TAB):
    _p.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------------
# Collection window and instrument
# ----------------------------------------------------------------------------

SYMBOL = "BTC/USDT perpetual"
VENUES = ("binance", "hyperliquid")

START_UTC = "2026-08-24 00:00:00"
N_DAYS = 8                 # brief asks for 7 to 10 trading days
SNAPSHOT_HZ = 1.0          # one book snapshot per second
N_SECONDS = int(N_DAYS * 24 * 3600 * SNAPSHOT_HZ)

REF_PRICE = 108_000.0      # assumed BTC level, see README assumption list


# ----------------------------------------------------------------------------
# Book representation
# ----------------------------------------------------------------------------
# The brief asks for the top 10 levels. Raw exchange levels are not comparable
# across the two venues because the tick sizes differ by an order of magnitude,
# and on Binance the top 10 raw ticks span under one basis point, which is less
# than a typical one second price move. I therefore aggregate raw levels into
# fixed width price buckets and keep the top 10 buckets per side. Section 3 of
# the memo shows the arithmetic behind this choice.

BUCKET_USDT = 10.0         # price bucket width used for aggregation
N_LEVELS = 10              # top 10 buckets per side, as per the brief

RAW_TICK = {               # native tick size, used only for the span argument
    "binance": 0.10,
    "hyperliquid": 1.00,
}


# ----------------------------------------------------------------------------
# Simulator parameters (stand in for live collection)
# ----------------------------------------------------------------------------

SIM = {
    "seed": 20260903,

    # price process
    "daily_vol": 0.018,            # 1.8 percent daily, roughly 34 percent annualised
    "jumps_per_day": 3.0,
    "jump_bp_mean": 7.0,
    "transient_halflife_s": 30.0,  # decay of spoof induced price pressure
    "max_transient_bp": 5.0,

    # intraday volatility multiplier by UTC hour (Asia quiet, US active)
    "vol_by_hour": [
        0.72, 0.70, 0.72, 0.78, 0.85, 0.90, 0.95, 1.00,
        1.05, 1.08, 1.10, 1.12, 1.18, 1.35, 1.40, 1.32,
        1.25, 1.18, 1.10, 1.02, 0.95, 0.88, 0.82, 0.76,
    ],

    # resting background depth, in BTC, per bucket at distance i = 1..10
    "depth_base": {"binance": 6.0, "hyperliquid": 0.80},
    "depth_slope": {"binance": 2.2, "hyperliquid": 0.32},
    "depth_lognorm_sigma": 0.42,
    "depth_mean_reversion": 0.06,

    # traded volume, BTC per second
    "trade_vol_per_s": {"binance": 4.0, "hyperliquid": 0.40},
    "trade_vol_lognorm_sigma": 0.85,
    "large_order_fill_share": 1.00,   # share of crossing volume that hits an exposed large order
    "max_pin_s": 240,                  # after this a wall stops holding price back

    # large order arrivals, expected count per hour per side
    "genuine_per_hour": {"binance": 5.0, "hyperliquid": 4.0},
    "spoof_per_hour": {"binance": 3.2, "hyperliquid": 2.4},

    # large order size in BTC, lognormal around a multiple of local depth
    "genuine_size_mult": 4.5,
    "spoof_size_mult": 7.5,
    "size_lognorm_sigma": 0.50,

    # placement distance in buckets from mid
    "genuine_dist_range": (1, 6),
    "spoof_dist_range": (2, 6),

    # lifetimes and cancellation behaviour
    "genuine_life_mean_s": 900.0,
    "spoof_life_mean_s": 150.0,
    "spoof_cancel_dist": 1.5,        # spoof pulls when mid is this close, in buckets
    "spoof_cancel_prob": 0.80,       # per second once the trigger distance is met
    "genuine_pull_dist": 1.5,        # genuine orders also get pulled sometimes
    "genuine_pull_prob": 0.0015,      # per second, this is the deliberate overlap

    # price pressure exerted by a resting spoof, bp per second
    "spoof_push_bp_per_s": 0.075,

    # participant signatures and time of day clustering
    "signature_share": 0.60,         # share of spoofs from repeat participants
    "signature_sizes": {
        "binance": [88.0, 125.0, 150.0, 210.0, 64.0],
        "hyperliquid": [9.0, 14.0, 20.0, 27.5, 6.5],
    },
    "cluster_hours": (13, 14, 15),   # UTC hours that carry extra spoof activity
    "cluster_share": 0.45,           # share of spoofs forced into those hours

    # sample of raw snapshots written to disk for inspection
    "raw_sample_hours": 6.0,
}


# ----------------------------------------------------------------------------
# Detection thresholds
# ----------------------------------------------------------------------------

DETECT = {
    # a bucket counts as carrying a large resting order when its size exceeds
    # both a multiple of the trailing median at the same distance, and a floor
    "large_mult": 3.0,
    "abs_floor_btc": {"binance": 35.0, "hyperliquid": 4.5},
    "median_window_s": 600,          # trailing window for the depth baseline

    # the level is treated as gone once the excess falls below this share of peak
    "disappear_frac": 0.30,

    # a disappearance counts as a cancellation, not a fill, below this fill share
    "max_fill_frac": 0.20,

    # price has to come this close, in buckets, for the pull to count as a ghost
    "approach_buckets": 2.0,

    # events shorter than this are ignored, one second blips are usually noise
    "min_life_s": 3,
}


# ----------------------------------------------------------------------------
# Forward return study and classifier
# ----------------------------------------------------------------------------

HORIZONS_S = (1, 5, 10, 30, 60)

CLASSIFIER = {
    "split_fracs": (0.60, 0.15),     # train, validation; the rest is test
                                     # chronological throughout, never shuffled
    "block_bootstrap_len_s": 300,
    "n_bootstrap": 2000,
    "target_precision": 0.70,        # used to pick an operating threshold
}
