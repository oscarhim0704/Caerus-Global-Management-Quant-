"""
Spoof event classifier and, more importantly, its error accounting.

Three things are being measured and they are easy to confuse, so they are kept
apart deliberately:

  1. heuristic vs intent    Does the ghost rule find the orders that were
                            placed with no intention of trading? Only possible
                            here because the data is simulated.
  2. model vs heuristic     Can a model predict the ghost label from what was
                            observable at the moment the order appeared? This
                            is the only one of the three that is reproducible
                            on live data.
  3. model vs intent        Does the model, trained on a noisy proxy label,
                            still find real spoofs? This is the number that
                            would actually matter to a desk, and it is worse
                            than (2) by construction.

Split is chronological. The events are heavily clustered in time (a busy hour
generates a burst of them) so a random split would put near duplicate events on
both sides of the fence and flatter the model.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import config
from .features import FEATURE_COLUMNS


MODELLABLE = ("ghost", "filled", "pulled_away_from_price")


def modelling_set(events: pd.DataFrame) -> pd.DataFrame:
    """
    Keep only events where the ghost label is actually defined.

    Censored events (still resting at the end of the sample, or shorter than
    the minimum life) and events that drifted out of the ten level window never
    got resolved, so including them would mean training on labels that mean
    "we did not see" rather than "it did not happen".
    """
    return events[events["event_category"].isin(MODELLABLE)].copy()


def chronological_split(df: pd.DataFrame, fracs=None):
    """
    Three way chronological split into train, validation and test.

    The validation slice exists so that the operating threshold is chosen on
    data the model has not seen. Picking it on the training fit gives a
    threshold that looks calibrated in sample and falls apart out of sample,
    which is exactly what happened on the first version of this.
    """
    fracs = fracs or config.CLASSIFIER["split_fracs"]
    a = df["t0"].quantile(fracs[0])
    b = df["t0"].quantile(fracs[0] + fracs[1])
    return (df[df["t0"] <= a].copy(),
            df[(df["t0"] > a) & (df["t0"] <= b)].copy(),
            df[df["t0"] > b].copy())


# ----------------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------------

def confusion_scores(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    tp = int(((y_pred == 1) & (y_true == 1)).sum())
    fp = int(((y_pred == 1) & (y_true == 0)).sum())
    fn = int(((y_pred == 0) & (y_true == 1)).sum())
    tn = int(((y_pred == 0) & (y_true == 0)).sum())
    prec = tp / (tp + fp) if (tp + fp) else float("nan")
    rec = tp / (tp + fn) if (tp + fn) else float("nan")
    return {
        "n": int(len(y_true)),
        "base_rate": float(y_true.mean()) if len(y_true) else float("nan"),
        "flag_rate": float(y_pred.mean()) if len(y_pred) else float("nan"),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "precision": prec,
        "recall": rec,
        "false_positive_rate": fp / (fp + tn) if (fp + tn) else float("nan"),
        "false_discovery_rate": fp / (tp + fp) if (tp + fp) else float("nan"),
        "f1": 2 * prec * rec / (prec + rec) if prec and rec and (prec + rec) else float("nan"),
    }


def threshold_for_precision(y_true: np.ndarray, scores: np.ndarray,
                            target: float) -> float:
    """
    Lowest threshold on the training set that still reaches `target` precision.
    Falls back to the score that maximises precision if the target is never met.
    """
    order = np.argsort(-scores)
    y = y_true[order]
    s = scores[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    ok = np.flatnonzero(prec >= target)
    if len(ok) == 0:
        return float(s[int(np.argmax(prec))])
    return float(s[ok[-1]])


# ----------------------------------------------------------------------------
# Training
# ----------------------------------------------------------------------------

def fit_models(train: pd.DataFrame, seed: int = 0) -> dict:
    X = train[FEATURE_COLUMNS].to_numpy(float)
    y = train["is_ghost"].to_numpy(int)

    logit = Pipeline([
        ("scale", StandardScaler()),
        ("clf", LogisticRegression(max_iter=2000, C=1.0, solver="lbfgs")),
    ]).fit(X, y)

    gbm = GradientBoostingClassifier(
        n_estimators=200, max_depth=3, learning_rate=0.05,
        subsample=0.8, random_state=seed,
    ).fit(X, y)

    return {"logistic": logit, "gradient_boosting": gbm}


def evaluate(models: dict, train: pd.DataFrame, val: pd.DataFrame,
             test: pd.DataFrame) -> pd.DataFrame:
    """Test set scorecard for each model plus two naive baselines."""
    Xva = val[FEATURE_COLUMNS].to_numpy(float)
    yva = val["is_ghost"].to_numpy(int)
    Xte = test[FEATURE_COLUMNS].to_numpy(float)
    yte = test["is_ghost"].to_numpy(int)

    rows = []

    # baseline 1: flag every large level
    r = confusion_scores(yte, np.ones_like(yte))
    r.update({"model": "flag everything", "threshold": 0.0,
              "roc_auc": 0.5, "pr_auc": float(yte.mean())})
    rows.append(r)

    # baseline 2: flag the largest quarter by size ratio at t0
    cut = np.quantile(train["log_size_ratio0"], 0.75)
    pred = (test["log_size_ratio0"].to_numpy() >= cut).astype(int)
    r = confusion_scores(yte, pred)
    r.update({"model": "size ratio top quartile", "threshold": float(cut),
              "roc_auc": roc_auc_score(yte, test["log_size_ratio0"]),
              "pr_auc": average_precision_score(yte, test["log_size_ratio0"])})
    rows.append(r)

    for name, mdl in models.items():
        pva = mdl.predict_proba(Xva)[:, 1]
        pte = mdl.predict_proba(Xte)[:, 1]

        r = confusion_scores(yte, (pte >= 0.5).astype(int))
        r.update({"model": f"{name} @ 0.50", "threshold": 0.5,
                  "roc_auc": roc_auc_score(yte, pte),
                  "pr_auc": average_precision_score(yte, pte)})
        rows.append(r)

        thr = threshold_for_precision(yva, pva, config.CLASSIFIER["target_precision"])
        r = confusion_scores(yte, (pte >= thr).astype(int))
        r.update({"model": f"{name} @ precision target", "threshold": thr,
                  "roc_auc": roc_auc_score(yte, pte),
                  "pr_auc": average_precision_score(yte, pte)})
        rows.append(r)

    cols = ["model", "threshold", "n", "base_rate", "flag_rate", "precision",
            "recall", "false_positive_rate", "false_discovery_rate", "f1",
            "roc_auc", "pr_auc", "tp", "fp", "fn", "tn"]
    return pd.DataFrame(rows)[cols]


def against_true_intent(models: dict, val: pd.DataFrame,
                        test: pd.DataFrame) -> pd.DataFrame:
    """
    Re-score the same predictions against the simulator's hidden intent flag.

    A model trained on a proxy label inherits every error the proxy makes, so
    these numbers are the honest ceiling on what the pipeline would deliver if
    it were pointed at real orders whose intent we somehow knew.
    """
    Xva = val[FEATURE_COLUMNS].to_numpy(float)
    yva_ghost = val["is_ghost"].to_numpy(int)
    Xte = test[FEATURE_COLUMNS].to_numpy(float)
    yte_true = test["true_is_spoof"].to_numpy(int)

    rows = []
    r = confusion_scores(yte_true, test["is_ghost"].to_numpy(int))
    r.update({"model": "ghost heuristic", "threshold": np.nan})
    rows.append(r)

    for name, mdl in models.items():
        pva = mdl.predict_proba(Xva)[:, 1]
        pte = mdl.predict_proba(Xte)[:, 1]
        thr = threshold_for_precision(yva_ghost, pva, config.CLASSIFIER["target_precision"])
        r = confusion_scores(yte_true, (pte >= thr).astype(int))
        r.update({"model": f"{name} @ precision target", "threshold": thr})
        rows.append(r)

    cols = ["model", "threshold", "n", "base_rate", "flag_rate", "precision",
            "recall", "false_positive_rate", "false_discovery_rate", "f1",
            "tp", "fp", "fn", "tn"]
    return pd.DataFrame(rows)[cols]


def logistic_coefficients(models: dict, train: pd.DataFrame) -> pd.DataFrame:
    """Standardised coefficients, so the magnitudes are comparable."""
    logit = models["logistic"]
    coefs = logit.named_steps["clf"].coef_[0]
    return (pd.DataFrame({"feature": FEATURE_COLUMNS, "coefficient": coefs,
                          "odds_ratio_per_sd": np.exp(coefs)})
            .sort_values("coefficient", key=np.abs, ascending=False)
            .reset_index(drop=True))


# ----------------------------------------------------------------------------
# False positive accounting
# ----------------------------------------------------------------------------

def threshold_sweep(models: dict, test: pd.DataFrame,
                    grid=np.arange(0.10, 0.95, 0.05)) -> pd.DataFrame:
    """
    Precision, recall and false positive rate across the whole threshold range.

    The brief asks for the false positive rate, and a single number at one
    arbitrary cut point hides the trade off completely. This is the table to
    argue from.
    """
    X = test[FEATURE_COLUMNS].to_numpy(float)
    y = test["is_ghost"].to_numpy(int)
    rows = []
    for name, mdl in models.items():
        p = mdl.predict_proba(X)[:, 1]
        for thr in grid:
            r = confusion_scores(y, (p >= thr).astype(int))
            r.update({"model": name, "threshold": round(float(thr), 2)})
            rows.append(r)
    cols = ["model", "threshold", "flag_rate", "precision", "recall",
            "false_positive_rate", "false_discovery_rate", "f1", "tp", "fp", "fn", "tn"]
    return pd.DataFrame(rows)[cols]


def prevalence_sensitivity(recall: float, fpr: float,
                           prevalences=(0.50, 0.25, 0.10, 0.05, 0.02, 0.01)) -> pd.DataFrame:
    """
    What the same detector would deliver if spoofing were rarer than it is here.

    Recall and false positive rate are properties of the detector. Precision is
    not: it depends on how common the thing being detected actually is. The
    simulator was built with spoofs making up a large share of large orders,
    which is almost certainly far above reality, so the precision numbers
    elsewhere in this project are optimistic by construction. This table
    re-derives precision from Bayes' rule at lower base rates and is the single
    most important caveat on the whole deliverable.

        precision = recall * p / (recall * p + fpr * (1 - p))
    """
    rows = []
    for p in prevalences:
        tp = recall * p
        fp = fpr * (1 - p)
        rows.append({
            "assumed_spoof_prevalence": p,
            "recall_held_fixed": recall,
            "false_positive_rate_held_fixed": fpr,
            "implied_precision": tp / (tp + fp) if (tp + fp) else float("nan"),
            "false_alarms_per_true_hit": fp / tp if tp else float("inf"),
        })
    return pd.DataFrame(rows)
