"""
Reconstruct the life of a large resting order from top of book snapshots plus
the trade tape.

The problem
-----------
Public order book data has no order IDs. All you see is the total size sitting
in a price bucket, once per second. When that size falls you cannot tell from
the book alone whether the order was filled or cancelled, and that distinction
is the entire question. The trade tape solves it: if size at a bucket drops by
X and only Y was traded at that bucket over the same interval, then at least
X minus Y was cancelled.

What this module does
---------------------
* Keeps a trailing median of resting size at each distance index, per side.
  That is the "normal" depth this venue carries that far from mid, and it is
  what a large order has to stand out against. A median rather than a mean
  because a large order sitting in the window would drag a mean upward and
  hide itself.
* Opens a track when a bucket's size crosses both a relative threshold (a
  multiple of that trailing median) and an absolute floor in BTC.
* Follows the track by absolute price bucket, not by distance from mid, so the
  order stays the same object as the market moves toward or away from it.
* Accumulates traded volume in that bucket for the whole life of the track,
  including while the bucket is outside the visible ten level window, since the
  trade tape covers all prices.
* Closes the track when the excess size collapses, when price crosses the
  level, or when the level drifts out of the window and does not come back.

Known bias
----------
Traded volume at a bucket includes ordinary background flow, not just fills
against the large order. That inflates the estimated fill share, which pushes
events out of the ghost bucket rather than into it. The heuristic is therefore
conservative: it will miss some real cancellations rather than invent them.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import config


@dataclass
class LevelTrack:
    venue: str
    side: str
    abs_id: int
    price: float

    t0: int                    # second the level first qualified as large
    dist0: float               # distance from mid at t0, in buckets
    base0: float               # trailing median depth at that distance at t0
    size0: float               # total bucket size at t0
    excess0: float             # size0 minus base0, the estimated order size

    bid_total0: float = 0.0    # summed top 10 bid depth at t0
    ask_total0: float = 0.0
    n_other_large0: int = 0    # other large levels resting on the same side at t0

    peak_excess: float = 0.0
    peak_t: int = 0
    min_dist: float = 99.0
    max_dist: float = 0.0
    traded_btc: float = 0.0    # volume traded in this bucket since t0

    last_t: int = 0
    last_excess: float = 0.0
    away_since: int | None = None

    end_t: int | None = None
    end_reason: str | None = None


class LevelTracker:
    """Consumes the per second stream and emits closed LevelTrack objects."""

    GRACE_S = 120   # how long a level may sit outside the window and still resume

    def __init__(self, venue: str, cfg: dict | None = None):
        self.venue = venue
        self.cfg = cfg or config.DETECT
        self.n_levels = config.N_LEVELS
        self.floor = self.cfg["abs_floor_btc"][venue]

        win = self.cfg["median_window_s"]
        self._buf = {"bid": np.zeros((win, self.n_levels), dtype=np.float32),
                     "ask": np.zeros((win, self.n_levels), dtype=np.float32)}
        self._buf_i = 0
        self._buf_full = False
        self._win = win
        self._base = {"bid": None, "ask": None}
        self._refresh_every = 30

        self.active: dict[tuple[str, int], LevelTrack] = {}
        self.closed: list[LevelTrack] = []

    # ------------------------------------------------------------------
    def _update_baseline(self, t: int, bid_sizes: np.ndarray, ask_sizes: np.ndarray) -> bool:
        """Write into the ring buffer and refresh the median every 30 seconds."""
        self._buf["bid"][self._buf_i] = bid_sizes
        self._buf["ask"][self._buf_i] = ask_sizes
        self._buf_i = (self._buf_i + 1) % self._win
        if self._buf_i == 0:
            self._buf_full = True

        n = self._win if self._buf_full else max(self._buf_i, 1)
        if self._base["bid"] is None or t % self._refresh_every == 0:
            for sd in ("bid", "ask"):
                self._base[sd] = np.median(self._buf[sd][:n], axis=0).astype(np.float64)
        # a baseline built from fewer than 60 seconds of history is not usable
        return n >= 60

    # ------------------------------------------------------------------
    def step(self, t, m, mid, best_bid, best_ask, bid_sizes, ask_sizes, traded):
        warm = self._update_baseline(t, bid_sizes, ask_sizes)

        bid_total = float(bid_sizes.sum())
        ask_total = float(ask_sizes.sum())

        # 1. accumulate traded volume for every open track, visible or not
        if traded:
            for (sd, aid), vol in traded.items():
                tr = self.active.get((sd, aid))
                if tr is not None:
                    tr.traded_btc += vol

        # 2. update every open track
        for key in list(self.active.keys()):
            sd, aid = key
            tr = self.active[key]
            dist = (m - aid) if sd == "bid" else (aid - m)
            tr.min_dist = min(tr.min_dist, float(dist))
            tr.max_dist = max(tr.max_dist, float(dist))

            if dist < 0:
                self._close(tr, t, "crossed")
                continue
            if dist >= self.n_levels:
                if tr.away_since is None:
                    tr.away_since = t
                elif t - tr.away_since > self.GRACE_S:
                    self._close(tr, t, "left_window")
                continue

            tr.away_since = None
            sizes = bid_sizes if sd == "bid" else ask_sizes
            base = self._base[sd][dist]
            excess = float(sizes[dist] - base)
            tr.last_t, tr.last_excess = t, excess
            if excess > tr.peak_excess:
                tr.peak_excess, tr.peak_t = excess, t

            if excess < self.cfg["disappear_frac"] * tr.peak_excess:
                self._close(tr, t, "disappeared")

        # 3. open new tracks where a bucket has just become large
        if warm:
            for sd, sizes in (("bid", bid_sizes), ("ask", ask_sizes)):
                base = self._base[sd]
                thr = np.maximum(self.cfg["large_mult"] * base, self.floor)
                for d in np.flatnonzero(sizes >= thr):
                    d = int(d)
                    aid = (m - d) if sd == "bid" else (m + d)
                    if (sd, aid) in self.active:
                        continue
                    excess = float(sizes[d] - base[d])
                    if excess < self.floor * 0.5:
                        continue
                    n_other = sum(1 for (s2, _), tr2 in self.active.items() if s2 == sd)
                    tr = LevelTrack(
                        venue=self.venue, side=sd, abs_id=aid,
                        price=(aid + 0.5) * config.BUCKET_USDT,
                        t0=t, dist0=float(d), base0=float(base[d]),
                        size0=float(sizes[d]), excess0=excess,
                        bid_total0=bid_total, ask_total0=ask_total,
                        n_other_large0=n_other,
                        peak_excess=excess, peak_t=t,
                        min_dist=float(d), max_dist=float(d),
                        last_t=t, last_excess=excess,
                    )
                    self.active[(sd, aid)] = tr

    # ------------------------------------------------------------------
    def _close(self, tr: LevelTrack, t: int, reason: str) -> None:
        tr.end_t, tr.end_reason = t, reason
        self.closed.append(tr)
        self.active.pop((tr.side, tr.abs_id), None)

    def finalise(self, t_end: int) -> None:
        for tr in list(self.active.values()):
            self._close(tr, t_end, "censored")
