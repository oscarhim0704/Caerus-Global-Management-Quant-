"""
End to end run: generate (or load) order book data, detect ghost levels, build
features, fit the classifier, and write every table and figure the memo uses.

    python run_pipeline.py

Everything is deterministic given config.SIM["seed"].
"""

from __future__ import annotations

import time

import numpy as np
import pandas as pd

from src import analysis, classify, config, detect, features, simulate
from src.book_tracker import LevelTracker

# Figures are diagnostics I looked at while building. Off by default so a fresh
# run only writes the tables the memo quotes.
MAKE_FIGURES = False


def run_venue(venue: str, offset: int):
    """Stream one venue through the tracker and return (SimOutput, tracks)."""
    tracker = LevelTracker(venue)
    gen = simulate.simulate_venue(venue, seed_offset=offset)
    n = 0
    for rec in gen:
        tracker.step(*rec)
        n += 1
    tracker.finalise(n - 1)
    return simulate.simulate_venue.last_output, tracker.closed


def raw_sample_frame(out) -> pd.DataFrame:
    rows = []
    for t, mid, bb, ba, bs, asz in out.raw_sample:
        r = {"venue": out.venue, "second": t,
             "ts": out.start_ts + pd.Timedelta(seconds=int(t)),
             "mid": mid, "best_bid": bb, "best_ask": ba}
        for i in range(config.N_LEVELS):
            r[f"bid_sz_{i}"] = float(bs[i])
            r[f"ask_sz_{i}"] = float(asz[i])
        rows.append(r)
    return pd.DataFrame(rows)


def window_frame(out, truth: pd.DataFrame) -> pd.DataFrame:
    """Book depth at the tracked level for a sample of large orders."""
    if not out.windows:
        return pd.DataFrame()
    meta = truth.set_index("oid")[["side", "abs_id", "true_type"]].to_dict("index")
    w = config.BUCKET_USDT
    rows = []
    for oid, rel_t, t, mid, bs, asz in out.windows:
        info = meta.get(oid)
        if info is None:
            continue
        m = int(mid // w)
        dist = (m - info["abs_id"]) if info["side"] == "bid" else (info["abs_id"] - m)
        sizes = bs if info["side"] == "bid" else asz
        lvl = float(sizes[dist]) if 0 <= dist < config.N_LEVELS else np.nan
        bg = simulate._depth_target(out.venue, max(dist, 0)) if dist >= 0 else np.nan
        rows.append({"venue": out.venue, "oid": oid, "rel_t": rel_t, "second": t,
                     "mid": mid, "dist_buckets": dist, "level_size_btc": lvl,
                     "normal_depth_btc": bg, "excess_btc": lvl - bg,
                     "true_type": info["true_type"], "side": info["side"]})
    return pd.DataFrame(rows)


def main() -> None:
    t_start = time.time()
    print(f"Week 5 pipeline, {config.N_DAYS} days at {config.SNAPSHOT_HZ:.0f} Hz "
          f"({config.N_SECONDS:,} snapshots per venue)")
    print("DATA IS SIMULATED. See README.md, section 'Data provenance'.\n")

    sims, all_tracks, all_truth, all_windows = {}, [], [], []

    for k, venue in enumerate(config.VENUES):
        t0 = time.time()
        out, tracks = run_venue(venue, offset=k * 101)
        sims[venue] = out
        all_tracks.extend(tracks)

        truth = simulate.truth_frame(out)
        all_truth.append(truth)
        truth.to_csv(config.DATA_RAW / f"{venue}_simulated_orders_ground_truth.csv",
                     index=False)

        rs = raw_sample_frame(out)
        for c in rs.select_dtypes("float").columns:
            rs[c] = rs[c].astype("float32").round(3)
        rs.to_parquet(config.DATA_RAW / f"{venue}_book_top10_sample.parquet",
                      index=False, compression="zstd")

        # row order is the second index; best bid and ask are mid plus or minus
        # half the venue tick, so only the mid and the tape are stored
        pd.DataFrame({
            "mid": out.mid.astype(np.float32).round(2),
            "buy_vol_btc": out.buy_vol.astype(np.float32).round(3),
            "sell_vol_btc": out.sell_vol.astype(np.float32).round(3),
        }).to_parquet(config.DATA_RAW / f"{venue}_mid_and_volume_1s.parquet",
                      index=False, compression="zstd")

        all_windows.append(window_frame(out, truth))
        print(f"  {venue:<12} {len(tracks):>6,} level tracks, "
              f"{len(truth):>5,} simulated large orders, {time.time() - t0:5.1f}s")

    truth_all = pd.concat(all_truth, ignore_index=True)
    windows = pd.concat([w for w in all_windows if not w.empty], ignore_index=True)
    windows.to_parquet(config.DATA_RAW / "event_windows_sample.parquet", index=False)

    # ---- events -----------------------------------------------------------
    ev = detect.tracks_to_frame(all_tracks, pd.Timestamp(config.START_UTC, tz="UTC"))
    ev = detect.attach_ground_truth(ev, truth_all)
    ev = features.add_market_state(ev, sims)
    ev = features.add_size_signature(ev)
    ev = features.add_forward_returns(ev, sims)
    X, _ = features.build_feature_matrix(ev)
    for c in X.columns:
        ev[c] = X[c]

    ev_out = ev.copy()
    for c in ev_out.select_dtypes("float").columns:
        ev_out[c] = ev_out[c].round(6)
    ev_out.to_csv(config.DATA_PROC / "labeled_events.csv", index=False)
    print(f"\n  {len(ev):,} large level events detected")
    print(ev["event_category"].value_counts().to_string())

    # ---- classifier -------------------------------------------------------
    md = classify.modelling_set(ev)
    train, val, test = classify.chronological_split(md)
    models = classify.fit_models(train)

    scorecard = classify.evaluate(models, train, val, test)
    intent = classify.against_true_intent(models, val, test)
    sweep = classify.threshold_sweep(models, test)
    hs = detect.heuristic_scores(ev)
    prevalence = classify.prevalence_sensitivity(hs["recall"], hs["false_positive_rate"])
    coefs = classify.logistic_coefficients(models, train)
    heur = pd.DataFrame([detect.heuristic_scores(ev)])
    conf = detect.heuristic_confusion(ev)

    # ---- analysis ---------------------------------------------------------
    fr = analysis.forward_return_table(ev)
    rev = analysis.reversal_table(ev)
    fills = analysis.fill_outcome_table(ev)
    hours, hour_test = analysis.hour_clustering(ev)
    sigs = analysis.size_signature_table(ev)
    parts = analysis.participant_check(ev)
    venues = analysis.venue_comparison(ev)
    depth_geo = analysis.depth_window_check(sims)
    welch = pd.DataFrame([analysis.ghost_vs_filled_test(ev, h) for h in (1, 5, 10, 30, 60)])

    from src.features import FEATURE_COLUMNS as _FC
    fcorr = md[_FC].corr().round(3).reset_index().rename(columns={"index": "feature"})

    tabs = {
        "classifier_scorecard": scorecard,
        "feature_correlations": fcorr,
        "classifier_threshold_sweep": sweep,
        "precision_at_lower_spoof_prevalence": prevalence,
        "classifier_vs_true_intent": intent,
        "logistic_coefficients": coefs,
        "heuristic_vs_intent": heur,
        "heuristic_confusion": conf.reset_index(),
        "forward_returns_by_category": fr,
        "forward_return_welch_tests": welch,
        "reversal_10s_to_60s": rev,
        "fill_outcomes_by_category": fills,
        "ghost_rate_by_hour": hours,
        "hour_chi_square": pd.DataFrame([hour_test]),
        "repeated_size_clusters": sigs,
        "ghost_rate_by_true_participant": parts,
        "venue_comparison": venues,
        "depth_window_geometry": depth_geo,
    }
    for name, df in tabs.items():
        df.to_csv(config.OUT_TAB / f"{name}.csv", index=False)

    if MAKE_FIGURES:
        analysis.fig_forward_returns(fr, config.OUT_FIG / "forward_returns.png")
        analysis.fig_hour_clustering(hours, config.OUT_FIG / "ghost_rate_by_hour.png")
        analysis.fig_size_distribution(ev, config.OUT_FIG / "size_distribution.png")
        analysis.fig_precision_recall(models, test, config.OUT_FIG / "precision_recall.png")

    # pick an illustrative case: a spoof on the deeper venue that lived long
    # enough to see, and that price actually walked up to before it vanished
    gw = windows[(windows["true_type"] == "spoof") & (windows["venue"] == "binance")]
    if MAKE_FIGURES and not gw.empty:
        stats = gw.groupby("oid").agg(life=("rel_t", "max"),
                                      closest=("dist_buckets", "min"),
                                      start=("dist_buckets", "first"))
        stats["approach"] = stats["start"] - stats["closest"]
        ok = stats[(stats["life"].between(40, 200)) & (stats["approach"] >= 2)]
        if not ok.empty:
            pick = ok.sort_values(["approach", "life"]).index[-1]
            analysis.fig_example_event(gw[gw["oid"] == pick],
                                       config.OUT_FIG / "example_ghost_event.png")

    # ---- console summary --------------------------------------------------
    print("\n--- ghost heuristic against hidden intent -----------------------")
    print(heur.T.to_string(header=False))
    print("\n--- classifier on the ghost label, test set ---------------------")
    print(scorecard.round(3).to_string(index=False))
    print("\n--- same predictions scored against hidden intent ---------------")
    print(intent.round(3).to_string(index=False))
    print("\n--- precision if spoofs were rarer than the simulator assumes ---")
    print(prevalence.round(3).to_string(index=False))
    print(f"\nDone in {time.time() - t_start:.1f}s. "
          f"Tables written to outputs/tables.")


if __name__ == "__main__":
    main()
