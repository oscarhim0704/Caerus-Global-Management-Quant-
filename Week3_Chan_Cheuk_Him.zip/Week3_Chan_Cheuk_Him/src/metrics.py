"""The three measurements the brief asks for, plus the bookkeeping around them.

  depth-to-mid   notional resting within X bps of the mid
  slippage       VWAP cost of a market clip of $Q, in bps versus the mid
  recovery time  how long the top 3 slices take to get back to 80% of baseline

All three run off the binned snapshot the collector writes (1bp buckets out to
50bps, plus the top 5 x 0.2bp slices). Slippage from buckets is approximate --
within a bucket I assume notional is spread evenly across the bucket -- which
puts the error at well under half a basis point for every clip size here. Doing
it exactly would need the raw levels, and the storage note in config.py explains
why I do not keep those.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg


# ------------------------------------------------------------ depth to mid ---
def depth_within(bins: np.ndarray, band_bps: float) -> np.ndarray:
    """Notional within band_bps of mid. bins is (n_snaps, N_BINS), one side."""
    k = int(round(band_bps / cfg.BIN_BPS))
    return bins[:, :k].sum(axis=1)


def depth_table(win_v: dict) -> pd.DataFrame:
    out = {"t_rel": win_v["t_rel"], "spread_bps": win_v["spread_bps"]}
    for b in cfg.DEPTH_BANDS_BPS:
        bid = depth_within(win_v["bid_bins"], b)
        ask = depth_within(win_v["ask_bins"], b)
        out[f"bid_{b}bps"] = bid
        out[f"ask_{b}bps"] = ask
        out[f"total_{b}bps"] = bid + ask
    out["top3_slices"] = (win_v["bid_raw"][:, :cfg.RECOVERY_LEVELS].sum(axis=1)
                          + win_v["ask_raw"][:, :cfg.RECOVERY_LEVELS].sum(axis=1))
    return pd.DataFrame(out)


# ---------------------------------------------------------------- slippage ---
def slippage_bps(bins_row: np.ndarray, clip_usd: float,
                 half_spread_bps: float = 0.0) -> float:
    """Walk one side of the book for `clip_usd` and return VWAP cost vs mid.

    Returns NaN if the clip cannot be filled inside 50bps -- that is a real
    outcome and should not be quietly floored at the 50bps edge, because doing
    so would make the thinnest venue look best exactly when it is worst.

    The half_spread argument fixes something I got wrong first time round. The
    first bucket runs from 0 to 1bp but there is no resting size inside the
    spread, so all of that bucket's notional actually sits between the touch and
    1bp. Pricing it at the bucket midpoint gave me a $10k clip on Binance costing
    0.05bps -- less than crossing the spread, which cannot happen. Clamping each
    bucket's lower edge to the half-spread puts it back at roughly the spread,
    which is what a small clip should cost.
    """
    cum = np.cumsum(bins_row)
    if clip_usd > cum[-1]:
        return np.nan
    j = int(np.searchsorted(cum, clip_usd))
    lo = np.maximum(np.arange(cfg.N_BINS) * cfg.BIN_BPS, half_spread_bps)
    hi = np.maximum((np.arange(cfg.N_BINS) + 1) * cfg.BIN_BPS, half_spread_bps)

    cost = float((bins_row[:j] * 0.5 * (lo[:j] + hi[:j])).sum())
    prev = cum[j - 1] if j > 0 else 0.0
    rem = clip_usd - prev
    frac = rem / bins_row[j] if bins_row[j] > 0 else 0.0
    cost += rem * (lo[j] + 0.5 * frac * (hi[j] - lo[j]))
    return cost / clip_usd


def slippage_series(bins: np.ndarray, clip_usd: float,
                    spread_bps: np.ndarray | None = None) -> np.ndarray:
    hs = (spread_bps / 2.0) if spread_bps is not None else np.zeros(len(bins))
    return np.array([slippage_bps(bins[i], clip_usd, float(hs[i]))
                     for i in range(len(bins))])


def slippage_table(win_v: dict, clips=None) -> pd.DataFrame:
    clips = clips or cfg.CLIP_SIZES_USD
    out = {"t_rel": win_v["t_rel"]}
    for q in clips:
        buy = slippage_series(win_v["ask_bins"], q, win_v["spread_bps"])
        sell = slippage_series(win_v["bid_bins"], q, win_v["spread_bps"])
        out[f"buy_{q}"] = buy
        out[f"sell_{q}"] = sell
        out[f"rt_{q}"] = buy + sell        # round trip, the number that matters
    return pd.DataFrame(out)


# ------------------------------------------------------------ recovery time ---
def recovery_time(t_rel: np.ndarray, depth: np.ndarray,
                  threshold=cfg.RECOVERY_THRESHOLD,
                  persist=cfg.RECOVERY_PERSIST,
                  censor_s=cfg.RECOVERY_CENSOR_S) -> dict:
    """Time from the depth trough back to `threshold` of the pre-event baseline.

    Requiring the level to hold for `persist` consecutive snapshots matters more
    than it looks. Depth is noisy at 250ms and a single snapshot crossing the
    line early cut my recovery times roughly in half on the first version of
    this -- it was reading noise, not replenishment.
    """
    base_mask = (t_rel >= -cfg.WINDOW_PRE_S) & (t_rel <= -60)
    baseline = float(np.median(depth[base_mask]))

    trough_mask = (t_rel >= -10) & (t_rel <= 60)
    ti = int(np.flatnonzero(trough_mask)[np.argmin(depth[trough_mask])])
    trough = float(depth[ti])

    res = {"baseline": baseline, "trough": trough, "trough_t": float(t_rel[ti]),
           "retention": trough / baseline if baseline else np.nan,
           "halflife_s": _replenish_halflife(t_rel, depth, ti, baseline)}

    target = threshold * baseline
    ok = depth >= target
    for i in range(ti, len(depth) - persist):
        if t_rel[i] - t_rel[ti] > censor_s:
            break
        if ok[i:i + persist].all():
            res.update(recovery_s=float(t_rel[i] - t_rel[ti]), censored=False)
            return res
    res.update(recovery_s=float(censor_s), censored=True)
    return res


def _replenish_halflife(t_rel, depth, ti, baseline) -> float:
    """Half-life of the replenishment leg, fitted separately from the collapse.

    Worth having because "time to 80% of baseline" is two things at once: how
    far the book fell, and how fast it came back. A venue that only loses 40% of
    its depth can cross 80% sooner than one that replenishes twice as fast but
    fell to 25%. Fitting log(1 - depth/baseline) against time on the recovery
    leg gives the rate on its own, so the two can be reported separately.
    """
    if baseline <= 0:
        return np.nan
    # Smooth first. Depth is 22% noisy at 250ms, so once the gap has closed to
    # a few percent the noise is larger than the signal and the log of it is
    # garbage. My first attempt fitted the whole 180s tail and returned
    # half-lives of 150s+ -- it was fitting the noise floor, not replenishment.
    sm = pd.Series(depth).rolling(20, center=True, min_periods=8).median().to_numpy()
    gap = 1.0 - sm / baseline

    after = np.flatnonzero((t_rel > t_rel[ti] + 1.0) & (t_rel <= t_rel[ti] + 180))
    if len(after) < 40:
        return np.nan
    # stop where the gap has closed to 12% -- past that it is noise
    below = np.flatnonzero(gap[after] < 0.12)
    end = after[below[0]] if len(below) else after[-1]
    idx = np.arange(after[0], max(end, after[0] + 40))
    idx = idx[(gap[idx] > 0.02) & np.isfinite(gap[idx])]
    if len(idx) < 20:
        return np.nan

    slope = np.polyfit(t_rel[idx] - t_rel[ti], np.log(gap[idx]), 1)[0]
    return float(np.log(2) / -slope) if slope < 0 else np.nan


def anchored_depth(win_v: dict, anchor: str = "top3") -> np.ndarray:
    """Depth series used for the recovery metric, on one of two anchors.

    "top3" is the brief's wording -- the top 3 price slices, measured from the
    touch. "5bps" is the same idea measured from the mid instead.

    They are not interchangeable and this turns out to matter. When the spread
    blows out, the top three slices sit further from the mid than they did in
    calm conditions, and because the book gets denser as you walk away from the
    touch those slices hold more size than the equivalent slices did before. So
    a touch-anchored measure partly rewards a venue for widening its spread.
    """
    if anchor == "top3":
        return (win_v["bid_raw"][:, :cfg.RECOVERY_LEVELS].sum(axis=1)
                + win_v["ask_raw"][:, :cfg.RECOVERY_LEVELS].sum(axis=1))
    k = int(anchor.replace("bps", ""))
    return depth_within(win_v["bid_bins"], k) + depth_within(win_v["ask_bins"], k)


def pooled_recovery_curve(windows: dict, venue: str, anchor: str = "top3"):
    """Mean normalised top-3 depth path across every event window.

    The per-event half-life above is not usable and the workbook shows why: the
    interquartile range of `rec_halflife_s` is wider than the differences I am
    trying to measure. Depth noise is persistent (autocorrelation time of about
    eight seconds) so one 300-second window does not contain many independent
    observations of the replenishment leg -- a five-second median filter barely
    dents it. Averaging the normalised path across 25 events does, and the
    pooled fit below is the number I would actually quote.
    """
    acc, t_rel = [], None
    for _, (kind, win) in windows.items():
        if kind != "event":
            continue
        w = win[venue]
        t_rel = w["t_rel"]
        d = anchored_depth(w, anchor)
        base = np.median(d[(t_rel >= -cfg.WINDOW_PRE_S) & (t_rel <= -60)])
        acc.append(d / base)
    return t_rel, np.mean(acc, axis=0)


def pooled_halflife(t_rel: np.ndarray, curve: np.ndarray) -> float:
    m = (t_rel >= -10) & (t_rel <= 60)
    ti = int(np.flatnonzero(m)[np.argmin(curve[m])])
    gap = 1.0 - curve
    after = np.flatnonzero((t_rel > t_rel[ti] + 1.0) & (t_rel <= t_rel[ti] + 200))
    below = np.flatnonzero(gap[after] < 0.10)
    end = after[below[0]] if len(below) else after[-1]
    idx = np.arange(after[0], max(end, after[0] + 40))
    idx = idx[(gap[idx] > 0.02) & np.isfinite(gap[idx])]
    if len(idx) < 20:
        return np.nan
    slope = np.polyfit(t_rel[idx] - t_rel[ti], np.log(gap[idx]), 1)[0]
    return float(np.log(2) / -slope) if slope < 0 else np.nan


# ------------------------------------------------------- per-window summary ---
BASE_WINDOW = (-cfg.WINDOW_PRE_S, -60)
ACUTE_WINDOW = (0, 30)


def _med(series, t_rel, lo, hi):
    m = (t_rel >= lo) & (t_rel <= hi)
    v = series[m]
    v = v[np.isfinite(v)]
    return float(np.median(v)) if len(v) else np.nan


def summarise_window(win_v: dict, venue: str, is_event: bool,
                     wid: int) -> dict:
    t = win_v["t_rel"]
    dep = depth_table(win_v)
    row = {"window_id": wid, "venue": venue,
           "kind": "event" if is_event else "calm"}

    for b in cfg.DEPTH_BANDS_BPS:
        col = dep[f"total_{b}bps"].to_numpy()
        row[f"depth_{b}bps_base"] = _med(col, t, *BASE_WINDOW)
        row[f"depth_{b}bps_acute"] = _med(col, t, *ACUTE_WINDOW)

    sp = win_v["spread_bps"]
    row["spread_base"] = _med(sp, t, *BASE_WINDOW)
    row["spread_acute"] = _med(sp, t, *ACUTE_WINDOW)

    for q in cfg.CLIP_SIZES_USD:
        buy = slippage_series(win_v["ask_bins"], q, win_v["spread_bps"])
        sell = slippage_series(win_v["bid_bins"], q, win_v["spread_bps"])
        rt = buy + sell
        row[f"slip_{q}_base"] = _med(rt, t, *BASE_WINDOW)
        row[f"slip_{q}_acute"] = _med(rt, t, *ACUTE_WINDOW)
        # unfillable share during the acute phase -- 0 in calm by construction
        m = (t >= ACUTE_WINDOW[0]) & (t <= ACUTE_WINDOW[1])
        row[f"unfillable_{q}"] = float(np.mean(~np.isfinite(rt[m]))) if m.any() else np.nan

    if is_event:
        rec = recovery_time(t, anchored_depth(win_v, "top3"))
        row.update({f"rec_{k}": v for k, v in rec.items()})
        rec5 = recovery_time(t, anchored_depth(win_v, "5bps"))
        row.update({f"rec5_{k}": v for k, v in rec5.items()})
    return row
