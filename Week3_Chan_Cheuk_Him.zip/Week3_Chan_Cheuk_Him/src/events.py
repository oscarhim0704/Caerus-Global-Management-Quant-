"""Finding the liquidity stress events, and matching calm controls to them.

Definition used: a stress event is a second t at which the cross-venue median mid
has travelled more than 1% peak-to-trough within the trailing 60 seconds.

Two choices in there worth defending.

Range, not endpoint return. The obvious reading of ">1% price move in <1 min" is
mid(t)/mid(t-60) - 1. That misses the move that runs 1.4% down in 25 seconds and
bounces half of it back before the minute is up, which is exactly the kind of
move that empties a book. Peak-to-trough range over the window catches both, and
the ones it adds are the interesting ones.

Median across venues, not one venue. If I detect on Binance alone then a Binance
feed glitch becomes an "event" on all three venues, and the venue I detect on gets
a slightly different event set from the others, which makes the comparison unfair.
Taking the median of the three mids each second costs nothing and removes both.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg


def reference_mid(coarse) -> np.ndarray:
    stack = np.vstack([coarse[v].astype(np.float64) for v in cfg.VENUE_ORDER])
    return np.median(stack, axis=0)


def rolling_range_pct(mid: np.ndarray, window_s: int) -> np.ndarray:
    s = pd.Series(mid)
    hi = s.rolling(window_s, min_periods=window_s).max()
    lo = s.rolling(window_s, min_periods=window_s).min()
    return ((hi - lo) / lo * 100.0).to_numpy()


def detect(coarse, move_pct=cfg.EVENT_MOVE_PCT,
           lookback_s=cfg.EVENT_LOOKBACK_S,
           cooldown_s=cfg.EVENT_COOLDOWN_S) -> pd.DataFrame:
    mid = reference_mid(coarse)
    rng_pct = rolling_range_pct(mid, lookback_s)
    flag = rng_pct > move_pct

    # A single selloff sets the flag for a minute or more. Take the first second
    # it fires, then blank everything for the cooldown, then carry on.
    idx = np.flatnonzero(flag)
    picked, last = [], -10 ** 9
    for i in idx:
        if i - last >= cooldown_s:
            picked.append(i)
            last = i

    rows = []
    for eid, i in enumerate(picked):
        # keep enough room either side to build a full window
        if i < cfg.WINDOW_PRE_S + lookback_s or \
           i > len(mid) - cfg.WINDOW_POST_S - 10:
            continue
        w = mid[i - lookback_s:i + 1]
        hi_at = int(np.argmax(w))
        lo_at = int(np.argmin(w))
        rows.append({
            "event_id": len(rows),
            "t_s": int(i),
            "range_pct": float(rng_pct[i]),
            "direction": "down" if lo_at > hi_at else "up",
            "mid_at_event": float(mid[i]),
            "mid_60s_before": float(mid[i - lookback_s]),
            "signed_move_pct": float((mid[i] / mid[i - lookback_s] - 1) * 100),
        })
    ev = pd.DataFrame(rows)
    if len(ev):
        ev["day"] = ev.t_s // 86_400
        ev["hour_utc"] = (ev.t_s % 86_400) // 3600
        ev = classify(ev, mid)
    return ev


# ------------------------------------------------------------ classification ---
SEVERITY_BINS = [1.0, 1.25, 1.75, np.inf]
SEVERITY_NAMES = ["moderate", "large", "extreme"]
FAST_SECONDS = 30


def classify(ev: pd.DataFrame, mid: np.ndarray,
             lookback_s=cfg.EVENT_LOOKBACK_S) -> pd.DataFrame:
    """Label each event on three axes: direction, severity, and speed.

    Detection tells you an event happened. Classification is what makes the
    comparison across venues mean anything, because these are not one
    population. A 1.05% drift over the full minute and a 2% air-pocket in eight
    seconds do completely different things to a book, and averaging their
    recovery times together produces a number that describes neither.

    Three labels:
      direction  up or down. Down moves are the ones that empty bid books.
      severity   moderate / large / extreme, cut on the 60s range.
      speed      fast if the extremes sat within 30 seconds of each other,
                 else gradual. Cut at 30s because that is roughly the median
                 and it splits the sample without leaving a group too small
                 to say anything about.
      retraced   whether the move gave back more than a third of itself in the
                 five minutes after detection. This has to look forward: the
                 detector fires on the first second the threshold is crossed,
                 which is usually at or near the extreme, so there is nothing
                 to retrace yet inside the detection window. That is fine here
                 because this is a descriptive label on a completed event, not
                 an input to anything traded -- but it does mean `retraced`
                 must never be used as a feature in a live rule.
    """
    ev = ev.copy()
    ev["severity"] = pd.cut(ev.range_pct, bins=SEVERITY_BINS,
                            labels=SEVERITY_NAMES, right=False).astype(str)

    speeds, retraced = [], []
    for _, r in ev.iterrows():
        w = mid[int(r.t_s) - lookback_s:int(r.t_s) + 1]
        hi_i, lo_i = int(np.argmax(w)), int(np.argmin(w))
        # time between the extremes is how long the move actually took
        speeds.append(abs(hi_i - lo_i))
        # how much was handed back over the five minutes after detection
        fwd = mid[int(r.t_s):int(r.t_s) + 300]
        extreme = w[max(hi_i, lo_i)]
        start = w[min(hi_i, lo_i)]
        travelled = extreme - start
        if travelled == 0 or len(fwd) < 2:
            retraced.append(False)
            continue
        if hi_i > lo_i:                      # move went up, retrace is a fall
            given_back = (extreme - fwd.min()) / travelled
        else:                                # move went down, retrace is a rise
            given_back = (fwd.max() - w[lo_i]) / travelled
        retraced.append(bool(given_back > 1 / 3))

    ev["move_seconds"] = speeds
    ev["speed"] = np.where(ev.move_seconds <= FAST_SECONDS, "fast", "gradual")
    ev["retraced"] = retraced
    # an endpoint-return rule (mid_t / mid_t-60 - 1) would have missed these
    ev["missed_by_endpoint_rule"] = ev.signed_move_pct.abs() < cfg.EVENT_MOVE_PCT
    ev["label"] = ev.direction + "/" + ev.severity + "/" + ev.speed
    return ev


def classification_summary(ev: pd.DataFrame) -> pd.DataFrame:
    out = []
    for axis in ("direction", "severity", "speed"):
        c = ev[axis].value_counts()
        for k, n in c.items():
            out.append({"axis": axis, "class": k, "n_events": int(n),
                        "share": n / len(ev),
                        "mean_range_pct": ev.loc[ev[axis] == k, "range_pct"].mean()})
    out.append({"axis": "retracement", "class": "retraced >1/3",
                "n_events": int(ev.retraced.sum()),
                "share": ev.retraced.mean(),
                "mean_range_pct": ev.loc[ev.retraced, "range_pct"].mean()})
    out.append({"axis": "detection", "class": "missed by endpoint rule",
                "n_events": int(ev.missed_by_endpoint_rule.sum()),
                "share": ev.missed_by_endpoint_rule.mean(),
                "mean_range_pct": ev.loc[ev.missed_by_endpoint_rule,
                                         "range_pct"].mean()})
    return pd.DataFrame(out)


def calm_windows(coarse, events: pd.DataFrame, rng,
                 n_per_event=cfg.CALM_SAMPLES_PER_EVENT,
                 min_dist=cfg.CALM_MIN_DISTANCE_S) -> pd.DataFrame:
    """Control windows, at least `min_dist` from every event.

    These are the denominator for every "how much worse was it" number in the
    study, so they have to be sampled the same way for all three venues -- which
    they are, because the windows are picked on the reference clock, not per
    venue.
    """
    n_total = len(coarse["ts_s"])
    ev_t = events.t_s.to_numpy() if len(events) else np.array([])
    want = max(1, n_per_event) * max(len(events), 1)

    picked = []
    tries = 0
    while len(picked) < want and tries < want * 200:
        tries += 1
        t = int(rng.integers(cfg.WINDOW_PRE_S + 120,
                             n_total - cfg.WINDOW_POST_S - 120))
        if len(ev_t) and np.min(np.abs(ev_t - t)) < min_dist:
            continue
        if picked and np.min(np.abs(np.array(picked) - t)) < 3600:
            continue
        picked.append(t)

    return pd.DataFrame({"calm_id": range(len(picked)),
                         "t_s": sorted(picked)})
