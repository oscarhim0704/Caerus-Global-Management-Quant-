"""Turning four measurements into one number, and then checking whether that
number means anything.

The score itself is the easy part. The part I spent longer on is the second half
of this file, because a single composite hides two different kinds of wobble:

  1. I picked the weights. Someone running a $50k clip cares about a completely
     different mix from someone running $1m, and there is no objective answer.
  2. There are only ~25 events. The component means are sample means over 25
     draws and they have standard errors.

So the score is reported with both: resampled weights, and bootstrapped events.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg

COMPONENTS = ["depth_retention", "slippage_stability",
              "recovery_speed", "spread_stability"]


def components(event_rows: pd.DataFrame) -> pd.DataFrame:
    """Per-venue, per-event raw components. Higher is better on all four."""
    d = event_rows.copy()
    d["depth_retention"] = d["depth_10bps_acute"] / d["depth_10bps_base"]
    d["slippage_stability"] = d["slip_1000000_base"] / d["slip_1000000_acute"]
    d["recovery_speed"] = 1.0 / d["rec_recovery_s"].clip(lower=1.0)
    d["spread_stability"] = d["spread_base"] / d["spread_acute"]
    return d[["window_id", "venue"] + COMPONENTS]


def scale(per_venue: pd.DataFrame) -> pd.DataFrame:
    """Each component to 0-100 as a percentage of the best venue.

    I first used min-max across the three venues, which forces the worst venue
    to exactly 0 on every component regardless of how close it actually was.
    With three venues that is not a scale, it is a ranking with extra steps.
    Percent-of-best keeps the gaps.
    """
    out = per_venue.copy()
    for c in COMPONENTS:
        out[c] = 100.0 * out[c] / out[c].max()
    return out


def score(event_rows: pd.DataFrame, weights=None) -> pd.DataFrame:
    weights = weights or cfg.SCORE_WEIGHTS
    raw = components(event_rows).groupby("venue")[COMPONENTS].mean()
    scaled = scale(raw)
    scaled["resilience_score"] = sum(scaled[c] * weights[c] for c in COMPONENTS)
    return (scaled.reindex(cfg.VENUE_ORDER)
                  .sort_values("resilience_score", ascending=False))


# ---------------------------------------------------------- weight wobble ----
def weight_sensitivity(event_rows: pd.DataFrame, n=5000, seed=cfg.SEED):
    """Redraw the weights uniformly on the simplex and see if the order holds."""
    rng = np.random.default_rng(seed)
    raw = components(event_rows).groupby("venue")[COMPONENTS].mean()
    scaled = scale(raw).reindex(cfg.VENUE_ORDER)
    M = scaled[COMPONENTS].to_numpy()

    W = rng.dirichlet(np.ones(len(COMPONENTS)), size=n)
    S = W @ M.T                                   # (n, n_venues)
    ranks = (-S).argsort(axis=1).argsort(axis=1) + 1

    top1 = pd.Series((ranks == 1).mean(axis=0), index=cfg.VENUE_ORDER,
                     name="p_rank1")
    spread = pd.DataFrame(S, columns=cfg.VENUE_ORDER)
    tbl = pd.DataFrame({
        "p_rank1": top1,
        "score_p05": spread.quantile(0.05),
        "score_p50": spread.quantile(0.50),
        "score_p95": spread.quantile(0.95),
    })
    order_counts = (pd.Series(["-".join(np.array(cfg.VENUE_ORDER)[np.argsort(-s)])
                               for s in S]).value_counts(normalize=True))
    return tbl, order_counts


# ----------------------------------------------------------- event wobble ----
def event_bootstrap(event_rows: pd.DataFrame, n=2000, seed=cfg.SEED + 1):
    """Resample events with replacement, keeping all three venues per event.

    Venues have to move together -- the same event hits all three, so treating
    75 venue-events as independent draws would understate the correlation and
    make the score look more precise than it is.
    """
    rng = np.random.default_rng(seed)
    comp = components(event_rows)
    ids = comp.window_id.unique()
    out = []
    for _ in range(n):
        pick = rng.choice(ids, size=len(ids), replace=True)
        boot = pd.concat([comp[comp.window_id == i] for i in pick])
        raw = boot.groupby("venue")[COMPONENTS].mean()
        sc = scale(raw)
        s = sum(sc[c] * cfg.SCORE_WEIGHTS[c] for c in COMPONENTS)
        out.append(s.reindex(cfg.VENUE_ORDER).to_numpy())
    B = np.array(out)
    ranks = (-B).argsort(axis=1).argsort(axis=1) + 1
    return pd.DataFrame({
        "score_p05": np.percentile(B, 5, axis=0),
        "score_p50": np.percentile(B, 50, axis=0),
        "score_p95": np.percentile(B, 95, axis=0),
        "p_rank1": (ranks == 1).mean(axis=0),
    }, index=cfg.VENUE_ORDER)
