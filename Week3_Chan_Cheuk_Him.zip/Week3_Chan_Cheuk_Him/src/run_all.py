"""Run the whole thing: python -m src.run_all

Writes figures to outputs/figures and one workbook to outputs/.
Takes about four minutes on this machine, most of it building the fine windows.
"""
from __future__ import annotations

import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import config as cfg
from . import events as EV
from . import leadlag as LL
from . import make_dataset as MD
from . import metrics as MT
from . import resilience as RS

plt.rcParams.update({"figure.dpi": 130, "axes.grid": True,
                     "grid.alpha": 0.25, "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False})
COLOURS = {"binance": "#d98a1f", "okx": "#2b6cb0", "bybit": "#c9432f"}


# ----------------------------------------------------------------- pipeline ---
def build_windows(coarse, ev, calm, rng):
    windows = {}
    for _, r in ev.iterrows():
        windows[int(r.event_id)] = ("event", MD.build_window(
            rng, coarse, int(r.t_s), True, cfg.WINDOW_PRE_S, cfg.WINDOW_POST_S))
    for _, r in calm.iterrows():
        wid = 1000 + int(r.calm_id)
        windows[wid] = ("calm", MD.build_window(
            rng, coarse, int(r.t_s), False, cfg.WINDOW_PRE_S, 120))
    return windows


def summarise_all(windows) -> pd.DataFrame:
    rows = []
    for wid, (kind, win) in windows.items():
        for v in cfg.VENUE_ORDER:
            rows.append(MT.summarise_window(win[v], v, kind == "event", wid))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ figures ---
def fig_price_and_events(coarse, ev):
    mid = EV.reference_mid(coarse)
    step = 60
    t = coarse["ts_s"][::step] / 86_400
    fig, ax = plt.subplots(2, 1, figsize=(10, 5.2), sharex=True,
                           gridspec_kw={"height_ratios": [2, 1]})
    ax[0].plot(t, mid[::step], lw=0.7, color="#333")
    for _, r in ev.iterrows():
        ax[0].axvline(r.t_s / 86_400, color="#c9432f", lw=0.7, alpha=0.55)
    ax[0].set_ylabel("BTC/USDT mid (USD)")
    ax[0].set_title(f"Reference mid over the 30-day sample, "
                    f"{len(ev)} stress events marked")

    rp = EV.rolling_range_pct(mid, cfg.EVENT_LOOKBACK_S)
    ax[1].plot(t, rp[::step], lw=0.6, color="#2b6cb0")
    ax[1].axhline(cfg.EVENT_MOVE_PCT, color="#c9432f", ls="--", lw=0.9,
                  label=f"{cfg.EVENT_MOVE_PCT}% threshold")
    ax[1].set_ylabel("60s range (%)")
    ax[1].set_xlabel("day of sample")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(cfg.FIGS / "01_events.png")
    plt.close(fig)


def fig_depth_profile(windows, ev, summary):
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.6))
    edges = (np.arange(cfg.N_BINS) + 0.5) * cfg.BIN_BPS
    for ax, (lo, hi, title) in zip(axes[:2], [
            (-300, -60, "Calm (pre-event baseline)"),
            (0, 30, "Acute phase (0 to +30s)")]):
        for v in cfg.VENUE_ORDER:
            acc = []
            for wid, (k, win) in windows.items():
                if k != "event":
                    continue
                t = win[v]["t_rel"]
                m = (t >= lo) & (t <= hi)
                prof = (win[v]["bid_bins"][m] + win[v]["ask_bins"][m]).mean(axis=0)
                acc.append(np.cumsum(prof))
            ax.plot(edges, np.mean(acc, axis=0) / 1e6, color=COLOURS[v],
                    lw=1.4, label=v)
        ax.set_xlabel("distance from mid (bps)")
        ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("cumulative depth, both sides ($m)")
    axes[0].legend(fontsize=8)

    d = summary[summary.kind == "event"]
    for v in cfg.VENUE_ORDER:
        g = d[d.venue == v]
        y = [g[f"depth_{b}bps_acute"].median() / g[f"depth_{b}bps_base"].median()
             for b in cfg.DEPTH_BANDS_BPS]
        axes[2].plot(cfg.DEPTH_BANDS_BPS, y, "o-", ms=4, color=COLOURS[v],
                     lw=1.4, label=v)
    axes[2].set_xscale("log")
    axes[2].set_xticks(cfg.DEPTH_BANDS_BPS)
    axes[2].set_xticklabels([str(b) for b in cfg.DEPTH_BANDS_BPS])
    axes[2].set_ylim(0, 1)
    axes[2].set_xlabel("band (bps from mid)")
    axes[2].set_ylabel("acute depth / calm depth")
    axes[2].set_title("The touch empties first", fontsize=9)

    fig.suptitle("Depth-to-mid, averaged over 25 events. The 1bp band goes to "
                 "zero in stress because the spread is wider than 2bps",
                 fontsize=10)
    fig.tight_layout()
    fig.savefig(cfg.FIGS / "02_depth_profile.png")
    plt.close(fig)


def fig_slippage(summary):
    ev = summary[summary.kind == "event"]
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.6))
    x = np.array(cfg.CLIP_SIZES_USD)
    for ax, col, title in [(axes[0], "base", "Calm baseline"),
                           (axes[1], "acute", "Acute phase (0 to +30s)")]:
        for v in cfg.VENUE_ORDER:
            d = ev[ev.venue == v]
            y = [d[f"slip_{q}_{col}"].median() for q in cfg.CLIP_SIZES_USD]
            ax.plot(x / 1000, y, "o-", ms=3.5, color=COLOURS[v], lw=1.4, label=v)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("clip size ($k)")
        ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("round-trip slippage vs mid (bps)")
    axes[0].legend(fontsize=8)

    for v in cfg.VENUE_ORDER:
        d = ev[ev.venue == v]
        y = [d[f"slip_{q}_acute"].median() / d[f"slip_{q}_base"].median()
             for q in cfg.CLIP_SIZES_USD]
        axes[2].plot(x / 1000, y, "o-", ms=3.5, color=COLOURS[v], lw=1.4, label=v)
    axes[2].set_xscale("log")
    axes[2].axhline(1.0, color="#666", ls="--", lw=0.8)
    axes[2].set_xlabel("clip size ($k)")
    axes[2].set_ylabel("acute / calm slippage")
    axes[2].set_title("Degradation falls with size, and converges", fontsize=9)

    fig.suptitle("Small clips are hit hardest by stress: the spread dominates at "
                 r"\$10k, the book's shape dominates at \$1m", fontsize=10)
    fig.tight_layout()
    fig.savefig(cfg.FIGS / "03_slippage.png")
    plt.close(fig)


def fig_recovery(windows, summary, validation):
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.6))
    # left: mean normalised top-3 depth path
    for v in cfg.VENUE_ORDER:
        acc = []
        for wid, (k, win) in windows.items():
            if k != "event":
                continue
            t = win[v]["t_rel"]
            d = MT.anchored_depth(win[v], "top3")
            base = np.median(d[(t >= -300) & (t <= -60)])
            acc.append(d / base)
        # smoothed for display only -- the fits run on the unsmoothed paths
        y = pd.Series(np.mean(acc, axis=0)).rolling(8, center=True,
                                                    min_periods=1).mean()
        axes[0].plot(t, y, color=COLOURS[v], lw=1.3, label=v)
    axes[0].axhline(cfg.RECOVERY_THRESHOLD, color="#666", ls="--", lw=0.9)
    axes[0].axvline(0, color="#666", lw=0.7)
    axes[0].set_xlim(-60, 220)
    axes[0].set_xlabel("seconds from event")
    axes[0].set_ylabel("top-3 slice depth / baseline")
    axes[0].set_title("Depth collapse and replenishment (2s smoothed)",
                      fontsize=9)
    axes[0].legend(fontsize=8)

    # right: distribution of recovery times
    ev = summary[summary.kind == "event"]
    data = [ev[ev.venue == v].rec_recovery_s.dropna() for v in cfg.VENUE_ORDER]
    bp = axes[1].boxplot(data, tick_labels=cfg.VENUE_ORDER, patch_artist=True,
                         widths=0.55)
    for patch, v in zip(bp["boxes"], cfg.VENUE_ORDER):
        patch.set_facecolor(COLOURS[v])
        patch.set_alpha(0.45)
    for med in bp["medians"]:
        med.set_color("#222")
    axes[1].set_ylabel("seconds to 80% of baseline")
    axes[1].set_title("Recovery time by venue", fontsize=9)

    x = np.arange(len(cfg.VENUE_ORDER))
    axes[2].bar(x - 0.26, validation.injected_halflife_s, 0.25,
                color="#444", label="injected (truth)")
    axes[2].bar(x, validation.fitted_top3_anchor_s, 0.25,
                color="#c9432f", label="fitted, top-3 anchor")
    axes[2].bar(x + 0.26, validation.fitted_5bps_anchor_s, 0.25,
                color="#2b6cb0", label="fitted, 5bps anchor")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(cfg.VENUE_ORDER, fontsize=8)
    axes[2].set_ylabel("replenishment half-life (s)")
    axes[2].set_ylim(0, 41)
    axes[2].set_title("The touch-anchored measure misranks", fontsize=9)
    axes[2].legend(fontsize=7, loc="upper left", frameon=False)

    fig.tight_layout()
    fig.savefig(cfg.FIGS / "04_recovery.png")
    plt.close(fig)


def fig_scores(sc, wsens, boot):
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.4))
    comp = sc[RS.COMPONENTS]
    xs = np.arange(len(RS.COMPONENTS))
    w = 0.26
    for i, v in enumerate(cfg.VENUE_ORDER):
        axes[0].bar(xs + (i - 1) * w, comp.loc[v], w, color=COLOURS[v], label=v)
    axes[0].set_xticks(xs)
    axes[0].set_xticklabels([c.replace("_", "\n") for c in RS.COMPONENTS],
                            fontsize=7)
    axes[0].set_ylabel("% of best venue")
    axes[0].set_ylim(0, 126)
    axes[0].set_title("Components", fontsize=9)
    axes[0].legend(fontsize=7, ncol=3, loc="upper center", frameon=False)

    order = sc.index.tolist()
    ys = np.arange(len(order))
    for i, v in enumerate(order):
        lo, hi = boot.loc[v, "score_p05"], boot.loc[v, "score_p95"]
        axes[1].plot([lo, hi], [i, i], color=COLOURS[v], lw=3, alpha=0.45,
                     solid_capstyle="round")
        axes[1].plot(sc.loc[v, "resilience_score"], i, "o", ms=8,
                     color=COLOURS[v])
    axes[1].set_yticks(ys)
    axes[1].set_yticklabels(order)
    axes[1].set_xlim(75, 103)
    axes[1].set_xlabel("resilience score (0-100)")
    axes[1].set_title("Composite, 90% event bootstrap", fontsize=9)
    axes[1].invert_yaxis()

    w = 0.36
    xs = np.arange(len(cfg.VENUE_ORDER))
    axes[2].bar(xs - w / 2, [wsens.loc[v, "p_rank1"] for v in cfg.VENUE_ORDER],
                w, color="#6b7280", label="random weights")
    axes[2].bar(xs + w / 2, [boot.loc[v, "p_rank1"] for v in cfg.VENUE_ORDER],
                w, color="#c9432f", label="event bootstrap")
    axes[2].set_xticks(xs)
    axes[2].set_xticklabels(cfg.VENUE_ORDER, fontsize=8)
    axes[2].set_ylim(0, 1)
    axes[2].set_ylabel("P(ranked first)")
    axes[2].set_title("How stable is first place?", fontsize=9)
    axes[2].legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(cfg.FIGS / "05_resilience.png")
    plt.close(fig)


def fig_leadlag(ll_pool, windows):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.5))
    pairs = ll_pool[["leader", "follower"]].drop_duplicates().values.tolist()
    labels, calm_v, stress_v, truth = [], [], [], []
    for a, b in pairs:
        s = ll_pool[(ll_pool.leader == a) & (ll_pool.follower == b)]
        labels.append(f"{a[:3]}\u2192{b[:3]}")
        calm_v.append(float(s[s.phase == "calm_pre"].pooled_lead_ms.iloc[0]))
        stress_v.append(float(s[s.phase == "stress"].pooled_lead_ms.iloc[0]))
        truth.append(float(s.true_lag_ms.iloc[0]))
    x = np.arange(len(labels))
    axes[0].bar(x - 0.2, calm_v, 0.38, color="#7f9fb8", label="calm (pooled)")
    axes[0].bar(x + 0.2, stress_v, 0.38, color="#c9432f", label="stress (pooled)")
    axes[0].plot(x - 0.2, truth, "kx", ms=9, mew=2,
                 label="injected calm lag (truth)")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(labels, fontsize=8)
    axes[0].set_ylabel("lead of first venue (ms)")
    axes[0].set_title("Estimator recovers the injected lag to within ~50ms", fontsize=9)
    axes[0].legend(fontsize=7)

    # pooled cross-correlation curves, stress phase
    for b in ("okx", "bybit"):
        acc, lags = None, None
        for _, (kind, win) in windows.items():
            if kind != "event":
                continue
            mids = LL.phase_slice(win, 0, 45)
            ra = np.diff(np.log(mids["binance"].astype(np.float64)))
            rb = np.diff(np.log(mids[b].astype(np.float64)))
            lags, cc = LL._xcorr(ra, rb)
            acc = cc if acc is None else acc + cc
        axes[1].plot(lags * cfg.SNAP_MS_FINE, acc / 25, color=COLOURS[b],
                     lw=1.4, label=f"binance vs {b}")
    axes[1].axvline(0, color="#333", lw=0.8)
    axes[1].set_xlabel("lag applied to binance (ms)")
    axes[1].set_ylabel("mean cross-correlation")
    axes[1].set_title("Pooled over 25 stress windows", fontsize=9)
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(cfg.FIGS / "06_leadlag.png")
    plt.close(fig)


# -------------------------------------------------------------------- excel ---
def stratify(summary: pd.DataFrame, ev: pd.DataFrame) -> pd.DataFrame:
    """Metrics split by event class.

    The classification is only worth having if the classes behave differently,
    so this is the table that decides whether it earned its place.
    """
    d = summary[summary.kind == "event"].merge(
        ev[["event_id", "direction", "severity", "speed", "retraced"]],
        left_on="window_id", right_on="event_id", how="left")
    d["depth_retention"] = d.depth_10bps_acute / d.depth_10bps_base
    d["slip_1m_ratio"] = d.slip_1000000_acute / d.slip_1000000_base

    out = []
    for axis in ("direction", "speed"):
        for cls, g in d.groupby(axis):
            for v in cfg.VENUE_ORDER:
                gv = g[g.venue == v]
                out.append({
                    "axis": axis, "class": cls, "venue": v, "n": len(gv),
                    "median_depth_retention": gv.depth_retention.median(),
                    "median_slip_1m_ratio": gv.slip_1m_ratio.median(),
                    "median_recovery_s": gv.rec_recovery_s.median(),
                })
    return pd.DataFrame(out)


NOTE = [
    "Caerus Global Management - 2026 Summer Analyst Programme, Week 3.",
    "Order book depth and resilience across Binance, OKX and Bybit during "
    "liquidity stress events. BTC/USDT.",
    "",
    "DATA PROVENANCE - READ FIRST.",
    "Every number in this workbook comes from src/make_dataset.py, a simulator. "
    "The machine this was built on has no outbound network access, so I could "
    "not open a WebSocket to any of the three venues. src/collect_live.py holds "
    "the real collectors and writes the identical schema, but it has never been "
    "run against a live endpoint.",
    "",
    "WHAT THIS MEANS FOR THE RANKINGS. The per-venue depth, spread, collapse and "
    "replenishment parameters in src/config.py are priors I chose. The resilience "
    "scores are those priors pushed through the metrics and read back out. They "
    "are NOT a finding and should not be quoted as a view on any exchange. What "
    "is real here is the measurement pipeline, the event definition, and the "
    "sensitivity work in the 'score_sensitivity' and 'weight_orders' sheets - "
    "that last one is the part I would actually stand behind, because it does "
    "not depend on which venue I made deepest.",
    "",
    "TO REPRODUCE ON LIVE DATA: run `python -m src.collect_live --hours 720`, "
    "then `python -m src.run_all`. Nothing else changes.",
]


def write_excel(ev, calm, summary, sc, wsens, worders, boot, ll_sum, ll_pool,
                pooled_hl, validation, path):
    with pd.ExcelWriter(path, engine="openpyxl") as xl:
        pd.DataFrame({"notes": NOTE}).to_excel(xl, sheet_name="read_me", index=False)
        pd.DataFrame([{
            "venue": v, "taker_fee_bps": cfg.VENUES[v].taker_fee_bps,
            "assumed_spread_bps": cfg.VENUES[v].spread_bps,
            "assumed_depth_10bps_usd": cfg.VENUES[v].depth_10bps_usd,
            "assumed_shape_beta": cfg.VENUES[v].shape_beta,
            "assumed_depth_collapse": cfg.VENUES[v].depth_collapse,
            "assumed_spread_blowout": cfg.VENUES[v].spread_blowout,
            "assumed_recovery_halflife_s": cfg.VENUES[v].recovery_halflife_s,
            "assumed_quote_lag_ms": cfg.VENUES[v].quote_lag_ms,
        } for v in cfg.VENUE_ORDER]).to_excel(xl, sheet_name="assumptions", index=False)

        ev.to_excel(xl, sheet_name="events", index=False)
        EV.classification_summary(ev).to_excel(xl, sheet_name="event_classes", index=False)
        stratify(summary, ev).to_excel(xl, sheet_name="metrics_by_class", index=False)
        calm.to_excel(xl, sheet_name="calm_controls", index=False)
        summary.to_excel(xl, sheet_name="window_metrics", index=False)

        d = summary[summary.kind == "event"]
        depth = d.groupby("venue")[[f"depth_{b}bps_{s}" for b in cfg.DEPTH_BANDS_BPS
                                    for s in ("base", "acute")]].median()
        depth.reindex(cfg.VENUE_ORDER).to_excel(xl, sheet_name="depth_to_mid")

        slip = d.groupby("venue")[[f"slip_{q}_{s}" for q in cfg.CLIP_SIZES_USD
                                   for s in ("base", "acute")]].median()
        slip.reindex(cfg.VENUE_ORDER).to_excel(xl, sheet_name="slippage")

        rec = (d.groupby("venue")
                .agg(median_recovery_s=("rec_recovery_s", "median"),
                     mean_recovery_s=("rec_recovery_s", "mean"),
                     p90_recovery_s=("rec_recovery_s", lambda x: x.quantile(0.9)),
                     censored_share=("rec_censored", "mean"),
                     median_retention=("rec_retention", "median"),
                     per_event_halflife_p25=("rec_halflife_s", lambda x: x.quantile(.25)),
                     per_event_halflife_p75=("rec_halflife_s", lambda x: x.quantile(.75)))
                .reindex(cfg.VENUE_ORDER))
        rec["pooled_halflife_top3_s"] = [pooled_hl[(v, "top3")] for v in cfg.VENUE_ORDER]
        rec["pooled_halflife_5bps_s"] = [pooled_hl[(v, "5bps")] for v in cfg.VENUE_ORDER]
        rec["median_recovery_5bps_s"] = [
            d[d.venue == v].rec5_recovery_s.median() for v in cfg.VENUE_ORDER]
        rec.to_excel(xl, sheet_name="recovery")
        validation.to_excel(xl, sheet_name="metric_validation", index=False)

        sc.to_excel(xl, sheet_name="resilience_scores")
        wsens.to_excel(xl, sheet_name="score_sensitivity")
        worders.rename("share").to_frame().to_excel(xl, sheet_name="weight_orders")
        boot.to_excel(xl, sheet_name="event_bootstrap")
        ll_pool.to_excel(xl, sheet_name="lead_lag_pooled", index=False)
        ll_sum.to_excel(xl, sheet_name="lead_lag_by_window", index=False)
    print(f"wrote {path.name}")


# --------------------------------------------------------------------- main ---
def main():
    t0 = time.time()
    rng = np.random.default_rng(cfg.SEED + 7)

    print("building 30 days of 1s mids ...")
    coarse = MD.build_coarse()
    ev = EV.detect(coarse)
    calm = EV.calm_windows(coarse, ev, rng)
    print(f"  {len(ev)} stress events, {len(calm)} calm controls")
    lo, hi = cfg.EVENT_TARGET_RANGE
    if not lo <= len(ev) <= hi:
        print(f"  WARNING: {len(ev)} events is outside the {lo}-{hi} target")

    print("building 250ms books for each window ...")
    windows = build_windows(coarse, ev, calm, rng)

    print("computing metrics ...")
    summary = summarise_all(windows)
    ev_rows = summary[summary.kind == "event"]

    pooled_hl = {}
    for v in cfg.VENUE_ORDER:
        for a in ("top3", "5bps"):
            t, curve = MT.pooled_recovery_curve(windows, v, a)
            pooled_hl[(v, a)] = MT.pooled_halflife(t, curve)
    validation = pd.DataFrame([{
        "venue": v,
        "injected_halflife_s": cfg.VENUES[v].recovery_halflife_s,
        "fitted_top3_anchor_s": pooled_hl[(v, "top3")],
        "fitted_5bps_anchor_s": pooled_hl[(v, "5bps")],
    } for v in cfg.VENUE_ORDER])
    print(validation.round(1).to_string(index=False))

    sc = RS.score(ev_rows)
    wsens, worders = RS.weight_sensitivity(ev_rows)
    boot = RS.event_bootstrap(ev_rows, n=800)

    print("lead-lag ...")
    ll = LL.run(windows)
    ll_sum = LL.summarise(ll)
    ll_pool = LL.run_pooled(windows)

    print("figures ...")
    fig_price_and_events(coarse, ev)
    fig_depth_profile(windows, ev, summary)
    fig_slippage(summary)
    fig_recovery(windows, summary, validation)
    fig_scores(sc, wsens, boot)
    fig_leadlag(ll_pool, windows)

    write_excel(ev, calm, summary, sc, wsens, worders, boot, ll_sum, ll_pool,
                pooled_hl, validation, cfg.OUT / "week3_liquidity_metrics.xlsx")

    summary.to_csv(cfg.DATA / "window_metrics.csv", index=False)
    ev.to_csv(cfg.DATA / "events.csv", index=False)

    print(f"\ndone in {time.time() - t0:.0f}s")
    print(sc[["resilience_score"]].round(1).to_string())
    return dict(coarse=coarse, ev=ev, calm=calm, windows=windows,
                summary=summary, sc=sc, wsens=wsens, boot=boot,
                ll=ll, ll_pool=ll_pool, ll_sum=ll_sum, pooled_hl=pooled_hl,
                validation=validation)


if __name__ == "__main__":
    main()
