"""Live L2 order book collectors for Binance, OKX and Bybit.

WARNING -- THIS FILE HAS NOT BEEN RUN AGAINST THE REAL ENDPOINTS. The machine I
built this on has no outbound network access, so I could not open a socket to any
of the three venues. The code below is written against the current public API
docs and I have checked the message shapes by hand, but it is untested. Treat it
as the intended collector rather than a proven one. Everything downstream of this
file was developed on src/make_dataset.py instead.

Design. Each venue publishes incremental depth updates, not full books. So for
each venue we:
  1. open the diff stream and start buffering messages
  2. pull a REST snapshot
  3. drop buffered messages older than the snapshot, apply the rest
  4. keep applying, and write our own snapshot on a fixed grid

Two grids are written (see config): a 1s mid-only file that runs continuously,
and a 250ms full-book file. Writing 250ms x 20 levels x 3 venues continuously for
30 days is roughly 2.5 GB of parquet, which is fine, so the fine file also runs
continuously -- the split exists because the analysis only reads the fine file
inside event windows.

Run:  python -m src.collect_live --hours 720
"""
from __future__ import annotations

import argparse
import asyncio
import json
import time
from collections import deque
from pathlib import Path

import pandas as pd

from . import config as cfg

try:
    import websockets
    import aiohttp
except ImportError:  # not installed in the sandbox
    websockets = None
    aiohttp = None


class LocalBook:
    """A price -> size map for one side, kept sorted on read."""

    def __init__(self, side: str):
        self.side = side
        self.levels: dict[float, float] = {}

    def apply(self, updates):
        for price, size in updates:
            p, s = float(price), float(size)
            if s == 0.0:
                self.levels.pop(p, None)
            else:
                self.levels[p] = s

    def top(self, n: int):
        rev = self.side == "bid"
        keys = sorted(self.levels.keys(), reverse=rev)[:n]
        return [(k, self.levels[k]) for k in keys]


class VenueState:
    def __init__(self, venue: str):
        self.venue = venue
        self.bids = LocalBook("bid")
        self.asks = LocalBook("ask")
        self.last_update_id = None
        self.ready = False
        self.buffer = deque()

    def rows(self, ts_ms: int, n: int):
        b = self.bids.top(n)
        a = self.asks.top(n)
        if not b or not a:
            return None
        row = {"ts_ms": ts_ms, "venue": self.venue,
               "best_bid": b[0][0], "best_ask": a[0][0]}
        for i in range(n):
            row[f"bid_px_{i}"] = b[i][0] if i < len(b) else None
            row[f"bid_sz_{i}"] = b[i][1] if i < len(b) else None
            row[f"ask_px_{i}"] = a[i][0] if i < len(a) else None
            row[f"ask_sz_{i}"] = a[i][1] if i < len(a) else None
        return row


# ------------------------------------------------------------------ binance ---
async def binance_stream(state: VenueState, session):
    v = cfg.VENUES["binance"]
    url = f"{v.ws_url}/{v.depth_channel}"
    async with websockets.connect(url, ping_interval=20) as ws:
        # buffer first, snapshot second -- the other order loses updates
        snap_task = asyncio.create_task(_binance_snapshot(state, session))
        while True:
            msg = json.loads(await ws.recv())
            if not state.ready:
                state.buffer.append(msg)
                if snap_task.done():
                    _binance_drain(state)
                continue
            _binance_apply(state, msg)


async def _binance_snapshot(state: VenueState, session):
    url = "https://api.binance.com/api/v3/depth?symbol=BTCUSDT&limit=1000"
    async with session.get(url) as r:
        snap = await r.json()
    state.bids.apply(snap["bids"])
    state.asks.apply(snap["asks"])
    state.last_update_id = snap["lastUpdateId"]


def _binance_drain(state: VenueState):
    while state.buffer:
        msg = state.buffer.popleft()
        if msg["u"] <= state.last_update_id:
            continue
        _binance_apply(state, msg)
    state.ready = True


def _binance_apply(state: VenueState, msg):
    # U = first update id in event, u = last. Gap means we have to resync.
    if state.last_update_id is not None and msg["U"] > state.last_update_id + 1:
        state.ready = False
        state.last_update_id = None
        raise RuntimeError("binance sequence gap -- resync required")
    state.bids.apply(msg["b"])
    state.asks.apply(msg["a"])
    state.last_update_id = msg["u"]


# ---------------------------------------------------------------------- okx ---
async def okx_stream(state: VenueState, session=None):
    v = cfg.VENUES["okx"]
    sub = {"op": "subscribe",
           "args": [{"channel": v.depth_channel, "instId": "BTC-USDT"}]}
    async with websockets.connect(v.ws_url, ping_interval=20) as ws:
        await ws.send(json.dumps(sub))
        while True:
            msg = json.loads(await ws.recv())
            if "data" not in msg:
                continue
            action = msg.get("action")
            d = msg["data"][0]
            # OKX sends action="snapshot" first then action="update".
            # It also ships a CRC32 checksum on each update; I have not
            # implemented the checksum verification, which is a real gap --
            # without it a silently corrupted book would go unnoticed.
            if action == "snapshot":
                state.bids = LocalBook("bid")
                state.asks = LocalBook("ask")
                state.ready = True
            state.bids.apply([(x[0], x[1]) for x in d["bids"]])
            state.asks.apply([(x[0], x[1]) for x in d["asks"]])


# -------------------------------------------------------------------- bybit ---
async def bybit_stream(state: VenueState, session=None):
    v = cfg.VENUES["bybit"]
    sub = {"op": "subscribe", "args": [v.depth_channel]}
    async with websockets.connect(v.ws_url, ping_interval=20) as ws:
        await ws.send(json.dumps(sub))
        while True:
            msg = json.loads(await ws.recv())
            if msg.get("type") == "snapshot":
                state.bids = LocalBook("bid")
                state.asks = LocalBook("ask")
                state.ready = True
            elif msg.get("type") != "delta":
                continue
            d = msg["data"]
            state.bids.apply([(x[0], x[1]) for x in d.get("b", [])])
            state.asks.apply([(x[0], x[1]) for x in d.get("a", [])])


STREAMS = {"binance": binance_stream, "okx": okx_stream, "bybit": bybit_stream}


# ------------------------------------------------------------------ writers ---
async def snapshot_writer(states, hours: float):
    """Sample every book on the fine grid and flush to parquet hourly."""
    fine, coarse = [], []
    t_end = time.time() + hours * 3600
    next_coarse = 0.0
    last_flush = time.time()

    while time.time() < t_end:
        await asyncio.sleep(cfg.SNAP_MS_FINE / 1000)
        ts = int(time.time() * 1000)
        for st in states.values():
            if not st.ready:
                continue
            row = st.rows(ts, cfg.LEVELS_STORED)
            if row is None:
                continue
            fine.append(row)
            if ts >= next_coarse:
                coarse.append({"ts_ms": ts, "venue": st.venue,
                               "mid": 0.5 * (row["best_bid"] + row["best_ask"]),
                               "best_bid": row["best_bid"],
                               "best_ask": row["best_ask"]})
        if ts >= next_coarse:
            next_coarse = ts + cfg.SNAP_MS_COARSE

        if time.time() - last_flush > 3600:
            _flush(fine, "book_fine")
            _flush(coarse, "mid_coarse")
            fine, coarse = [], []
            last_flush = time.time()

    _flush(fine, "book_fine")
    _flush(coarse, "mid_coarse")


def _flush(rows, name: str):
    if not rows:
        return
    df = pd.DataFrame(rows)
    stamp = pd.Timestamp.utcnow().strftime("%Y%m%dT%H%M%S")
    path: Path = cfg.DATA / f"{name}_{stamp}.parquet"
    df.to_parquet(path, index=False)
    print(f"wrote {len(df):,} rows -> {path.name}")


async def main(hours: float):
    if websockets is None:
        raise SystemExit("pip install websockets aiohttp")
    states = {v: VenueState(v) for v in cfg.VENUE_ORDER}
    async with aiohttp.ClientSession() as session:
        tasks = [asyncio.create_task(STREAMS[v](states[v], session))
                 for v in cfg.VENUE_ORDER]
        tasks.append(asyncio.create_task(snapshot_writer(states, hours)))
        await asyncio.gather(*tasks)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=float, default=24.0)
    asyncio.run(main(ap.parse_args().hours))
