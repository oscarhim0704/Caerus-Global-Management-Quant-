"""Simulator standing in for the live collector.

Read this before reading any results. Nothing in this study is a live
observation. The venue rankings that come out of the analysis are the venue
parameters in config.py fed through the metrics and read back out. What is real
is the measurement code, the event definition, and the sensitivity work.

What it produces, in the same schema collect_live.py would write:

  1. a continuous 1s mid series per venue for 30 days  -> data/mid_coarse.npz
  2. a 250ms binned book for +/-5 min around each detected stress event, and for
     a matched set of calm control windows                -> data/books_fine.npz

Model, briefly.
  - one latent efficient log-price, GBM with a two-state vol regime
  - stress events are injected as jumps: a signed move of >=1% spread over 5-45s
  - each venue quotes the latent price with a lag and its own AR(1) noise
  - the book is a power law in distance from mid: cumulative notional within d
    bps = D10 * ((d - halfspread)/(10 - halfspread))^beta
  - under stress, depth is scaled down to `depth_collapse` and the spread is
    scaled up by `spread_blowout`, then both recover exponentially at a
    venue-specific half-life
"""
from __future__ import annotations

import numpy as np

from . import config as cfg

SEC_PER_DAY = 86_400
S0 = 61_500.0                       # arbitrary starting BTC price
CALM_VOL_ANN = 0.45
HIGH_VOL_ANN = 1.10
REGIME_SWITCH_P = 1.0 / (6 * 3600)  # expected 6h in a regime


# ------------------------------------------------------------ latent price ---
def _latent_path(rng, n_sec: int):
    """1s log-price path plus the jump schedule that drives the stress events."""
    dt = 1.0 / (365 * SEC_PER_DAY)

    # two-state vol regime, sampled as a Markov chain on the 1s grid
    regime = np.zeros(n_sec, dtype=np.int8)
    state = 0
    for i in range(1, n_sec):
        if rng.random() < REGIME_SWITCH_P:
            state = 1 - state
        regime[i] = state
    vol = np.where(regime == 1, HIGH_VOL_ANN, CALM_VOL_ANN)
    diffusion = rng.normal(0.0, vol * np.sqrt(dt), n_sec)

    # Jumps. ~1 every 0.95 days lands in the 20-30 events the brief asks for
    # after detection and the 30 min cooldown have thinned them out.
    n_jumps = rng.poisson(n_sec / (0.95 * SEC_PER_DAY))
    jump_add = np.zeros(n_sec)
    jumps = []
    for _ in range(n_jumps):
        t0 = int(rng.integers(1200, n_sec - 2400))
        dur = int(rng.integers(5, 46))
        size = (0.010 + rng.exponential(0.008)) * rng.choice([-1.0, 1.0])
        # smooth s-shaped ramp so the move is not a single-tick discontinuity
        w = np.linspace(-3, 3, dur)
        ramp = 1.0 / (1.0 + np.exp(-w))
        ramp = np.diff(np.concatenate([[0.0], ramp / ramp[-1]]))
        jump_add[t0:t0 + dur] += np.log1p(size) * ramp

        # Partial retracement. Cascades overshoot and then give some back; if I
        # leave every jump permanent the 30-day path drifts absurdly, and the
        # detector never sees the round-trip shape that motivated using range
        # rather than endpoint return in the first place.
        retrace = rng.uniform(0.20, 0.70)
        r_dur = int(rng.integers(120, 900))
        r_end = min(t0 + dur + r_dur, n_sec)
        r_len = r_end - (t0 + dur)
        if r_len > 1:
            decay = np.diff(1.0 - np.exp(-np.linspace(0, 3, r_len + 1)))
            decay = decay / decay.sum()
            jump_add[t0 + dur:r_end] -= np.log1p(size) * retrace * decay
        jumps.append({"t0": t0, "dur": dur, "size": size, "retrace": retrace})

    logp = np.log(S0) + np.cumsum(diffusion + jump_add)
    return logp.astype(np.float64), regime, jumps


def _venue_mid(rng, latent_log, lag_s, noise_bps, grid_dt):
    """Venue quote = latent price seen `lag_s` ago, plus AR(1) quoting noise."""
    n = len(latent_log)
    shift = lag_s / grid_dt
    idx = np.arange(n, dtype=np.float64) - shift
    idx = np.clip(idx, 0, n - 1)
    lagged = np.interp(idx, np.arange(n), latent_log)

    phi = 0.85
    eps = rng.normal(0.0, noise_bps * 1e-4 * np.sqrt(1 - phi ** 2), n)
    noise = np.empty(n)
    noise[0] = eps[0]
    for i in range(1, n):
        noise[i] = phi * noise[i - 1] + eps[i]
    return np.exp(lagged + noise)


def build_coarse(seed=cfg.SEED):
    """30 days of 1s mids for each venue."""
    rng = np.random.default_rng(seed)
    n = cfg.SAMPLE_DAYS * SEC_PER_DAY
    latent, regime, jumps = _latent_path(rng, n)

    mids = {}
    for v in cfg.VENUE_ORDER:
        ven = cfg.VENUES[v]
        mids[v] = _venue_mid(rng, latent, ven.quote_lag_ms / 1000.0,
                             ven.noise_bps, 1.0).astype(np.float32)
    ts = np.arange(n, dtype=np.int64)          # seconds from start of sample
    return {"ts_s": ts, "latent": np.exp(latent).astype(np.float32),
            "regime": regime, "jumps": jumps, **mids}


# ----------------------------------------------------------- book snapshot ---
def _cum_depth(d_bps, half_spread_bps, d10_usd, beta):
    """Cumulative one-side notional resting within d_bps of the mid."""
    x = np.maximum(d_bps - half_spread_bps, 0.0)
    denom = max(10.0 - half_spread_bps, 0.1)
    return d10_usd * (x / denom) ** beta


def _book_bins(half_spread_bps, d10_usd, beta):
    """Notional in each 1bp bucket out to 50bps, one side."""
    edges = np.arange(0.0, cfg.BIN_MAX_BPS + cfg.BIN_BPS, cfg.BIN_BPS)
    cum = _cum_depth(edges, half_spread_bps, d10_usd, beta)
    return np.diff(cum)


def _raw_slices(half_spread_bps, d10_usd, beta):
    """Notional in each 0.2bp slice starting at the touch -- the 'levels'."""
    w = cfg.RAW_SLICE_BPS
    edges = half_spread_bps + np.arange(0, cfg.N_RAW_SLICES + 1) * w
    cum = _cum_depth(edges, half_spread_bps, d10_usd, beta)
    return np.diff(cum)


def _stress_profile(t_rel, halflife_s, trough_offset_s=2.0, ramp_s=10.0):
    """0 in calm, 1 at the trough, exponential decay back to 0 afterwards.

    t_rel is seconds relative to the detected event time.
    """
    g = np.zeros_like(t_rel)
    ramp = (t_rel > -ramp_s) & (t_rel <= trough_offset_s)
    g[ramp] = (t_rel[ramp] + ramp_s) / (ramp_s + trough_offset_s)
    after = t_rel > trough_offset_s
    tau = halflife_s / np.log(2.0)
    g[after] = np.exp(-(t_rel[after] - trough_offset_s) / tau)
    return np.clip(g, 0.0, 1.0)


def build_window(rng, coarse, t_center_s, is_event, pre_s, post_s):
    """250ms binned books for every venue over one window."""
    dt = cfg.SNAP_MS_FINE / 1000.0
    t_rel = np.arange(-pre_s, post_s, dt)
    n = len(t_rel)

    # upsample the 1s latent path over the window, with a small bridge term so
    # the sub-second path is not piecewise linear
    lo, hi = int(t_center_s - pre_s) - 2, int(t_center_s + post_s) + 3
    seg = np.log(coarse["latent"][lo:hi].astype(np.float64))
    tgrid = np.arange(len(seg), dtype=np.float64)
    q = (t_center_s + t_rel - lo)
    latent_fine = np.interp(q, tgrid, seg)
    bridge = rng.normal(0.0, 0.30 * 1e-4, n).cumsum()
    bridge -= np.linspace(0, bridge[-1], n)
    latent_fine = latent_fine + bridge

    out = {}
    for v in cfg.VENUE_ORDER:
        ven = cfg.VENUES[v]
        gv = _stress_profile(t_rel, ven.recovery_halflife_s) if is_event \
            else np.zeros(n)

        # quote lag widens under stress (queueing, rate limits, cancel storms)
        lag_s = ven.quote_lag_ms / 1000.0 * (1.0 + 1.0 * gv)
        idx = np.arange(n, dtype=np.float64) - lag_s / dt
        idx = np.clip(idx, 0, n - 1)
        lagged = np.interp(idx, np.arange(n), latent_fine)

        phi = 0.85
        eps = rng.normal(0.0, ven.noise_bps * 1e-4 * np.sqrt(1 - phi ** 2), n)
        noise = np.empty(n)
        noise[0] = eps[0]
        for i in range(1, n):
            noise[i] = phi * noise[i - 1] + eps[i]
        mid = np.exp(lagged + noise)

        # spread and depth respond to the stress profile, with persistent noise
        z = rng.normal(0, 1, n)
        for i in range(1, n):
            z[i] = 0.97 * z[i - 1] + np.sqrt(1 - 0.97 ** 2) * z[i]
        depth_noise = np.exp(0.22 * z)
        spread_noise = np.exp(0.15 * rng.normal(0, 1, n))

        spread = ven.spread_bps * (1 + (ven.spread_blowout - 1) * gv) * spread_noise
        depth_mult = (1 - (1 - ven.depth_collapse) * gv) * depth_noise

        bid_bins = np.empty((n, cfg.N_BINS), dtype=np.float32)
        ask_bins = np.empty((n, cfg.N_BINS), dtype=np.float32)
        bid_raw = np.empty((n, cfg.N_RAW_SLICES), dtype=np.float32)
        ask_raw = np.empty((n, cfg.N_RAW_SLICES), dtype=np.float32)

        # bid/ask asymmetry: the side the move is running into gets thinner
        drift = np.gradient(latent_fine) / dt
        skew = np.tanh(drift / (3e-4)) * 0.35 * gv

        for i in range(n):
            hs = spread[i] / 2.0
            d10_b = ven.depth_10bps_usd * depth_mult[i] * (1 - skew[i])
            d10_a = ven.depth_10bps_usd * depth_mult[i] * (1 + skew[i])
            bid_bins[i] = _book_bins(hs, d10_b, ven.shape_beta)
            ask_bins[i] = _book_bins(hs, d10_a, ven.shape_beta)
            bid_raw[i] = _raw_slices(hs, d10_b, ven.shape_beta)
            ask_raw[i] = _raw_slices(hs, d10_a, ven.shape_beta)

        out[v] = {
            "t_rel": t_rel.astype(np.float32),
            "mid": mid.astype(np.float32),
            "spread_bps": spread.astype(np.float32),
            "bid_bins": bid_bins, "ask_bins": ask_bins,
            "bid_raw": bid_raw, "ask_raw": ask_raw,
        }
    return out


if __name__ == "__main__":
    c = build_coarse()
    print(f"coarse: {len(c['ts_s']):,} seconds, "
          f"{len(c['jumps'])} injected jumps, "
          f"price range {c['latent'].min():,.0f}-{c['latent'].max():,.0f}")
