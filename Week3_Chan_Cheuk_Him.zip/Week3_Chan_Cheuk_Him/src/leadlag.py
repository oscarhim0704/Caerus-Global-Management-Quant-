"""Bonus section: does one venue move first?

Method is deliberately plain. Take 250ms log returns of the two venue mids over
the same window, cross-correlate over +/-20 lags (+/-5 seconds), and read off the
lag that maximises the correlation. Because the true lag is not a multiple of
250ms, I fit a parabola through the peak and its two neighbours and take the
vertex -- that recovers sub-grid lags well enough to tell 180ms from 320ms, which
a plain argmax cannot.

READ THIS BEFORE READING THE NUMBERS. On simulated data this section does not
measure the market, it measures the estimator. I injected the lags in
make_dataset.py, so recovering them is a unit test with a nice chart attached.
The reason it is still worth having is that it is the part of the pipeline most
likely to be wrong in a way that looks fine, and on live data it is the part I
would trust least. Knowing that the estimator returns the right answer when the
answer is known is the only assurance I can give here.
"""
from __future__ import annotations

import itertools

import numpy as np
import pandas as pd

from . import config as cfg

MAX_LAG = 8             # x 250ms = 2 seconds each way. Wider than this and the
                        # peak search occasionally locks onto a spurious distant
                        # maximum in a quiet window; the lags of interest are all
                        # well under a second.


def _xcorr(x: np.ndarray, y: np.ndarray, max_lag=MAX_LAG):
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt((x ** 2).sum() * (y ** 2).sum())
    lags = np.arange(-max_lag, max_lag + 1)
    out = np.empty(len(lags))
    for i, L in enumerate(lags):
        if L >= 0:
            a, b = x[L:], y[:len(y) - L] if L else y
        else:
            a, b = x[:len(x) + L], y[-L:]
        out[i] = float((a * b).sum() / denom) if denom else np.nan
    return lags, out


def _parabolic_peak(lags, cc):
    k = int(np.argmax(cc))
    if k in (0, len(cc) - 1):
        return float(lags[k])
    y0, y1, y2 = cc[k - 1], cc[k], cc[k + 1]
    denom = (y0 - 2 * y1 + y2)
    shift = 0.5 * (y0 - y2) / denom if denom != 0 else 0.0
    return float(lags[k] + shift)


def pair_lead(mid_a: np.ndarray, mid_b: np.ndarray, dt_ms=cfg.SNAP_MS_FINE):
    """Positive result = A leads B by that many milliseconds."""
    ra = np.diff(np.log(mid_a.astype(np.float64)))
    rb = np.diff(np.log(mid_b.astype(np.float64)))
    lags, cc = _xcorr(ra, rb)
    peak = _parabolic_peak(lags, cc)
    return {"lead_ms": -peak * dt_ms, "peak_corr": float(np.max(cc)),
            "lags": lags, "cc": cc}


def phase_slice(win: dict, lo_s: float, hi_s: float):
    t = win[cfg.VENUE_ORDER[0]]["t_rel"]
    m = (t >= lo_s) & (t <= hi_s)
    return {v: win[v]["mid"][m] for v in cfg.VENUE_ORDER}


def run(windows: dict, phases=None) -> pd.DataFrame:
    """windows: {window_id: (kind, {venue: arrays})}"""
    phases = phases or {"calm_pre": (-300, -60), "stress": (0, 45)}
    rows = []
    for wid, (kind, win) in windows.items():
        if kind != "event":
            continue
        for pname, (lo, hi) in phases.items():
            mids = phase_slice(win, lo, hi)
            for a, b in itertools.combinations(cfg.VENUE_ORDER, 2):
                r = pair_lead(mids[a], mids[b])
                rows.append({"window_id": wid, "phase": pname,
                             "leader": a, "follower": b,
                             "lead_ms": r["lead_ms"],
                             "peak_corr": r["peak_corr"]})
    return pd.DataFrame(rows)


def run_pooled(windows: dict, phases=None) -> pd.DataFrame:
    """Stack the cross-correlations across all events, then find one peak.

    This is the headline estimate and the per-window version below is only for
    the dispersion. Fitting a peak inside a single 45-second stress window gives
    an estimate with a standard deviation of 60-180ms -- the sign of the
    calm-to-stress change flipped depending on whether I averaged the per-window
    peaks or took the median of them, which is a clear sign the per-window
    estimate is too noisy to average. Pooling first and peaking once fixes it.
    """
    phases = phases or {"calm_pre": (-300, -60), "stress": (0, 45)}
    acc = {}
    for wid, (kind, win) in windows.items():
        if kind != "event":
            continue
        for pname, (lo, hi) in phases.items():
            mids = phase_slice(win, lo, hi)
            for a, b in itertools.combinations(cfg.VENUE_ORDER, 2):
                ra = np.diff(np.log(mids[a].astype(np.float64)))
                rb = np.diff(np.log(mids[b].astype(np.float64)))
                lags, cc = _xcorr(ra, rb)
                key = (a, b, pname)
                if key not in acc:
                    acc[key] = [lags, np.zeros_like(cc), 0]
                acc[key][1] += cc
                acc[key][2] += 1

    rows = []
    for (a, b, pname), (lags, cc_sum, n) in acc.items():
        cc = cc_sum / n
        rows.append({"leader": a, "follower": b, "phase": pname,
                     "pooled_lead_ms": -_parabolic_peak(lags, cc) * cfg.SNAP_MS_FINE,
                     "pooled_peak_corr": float(np.max(cc)), "n_windows": n,
                     "true_lag_ms": cfg.VENUES[b].quote_lag_ms
                                    - cfg.VENUES[a].quote_lag_ms})
    return pd.DataFrame(rows)


def summarise(ll: pd.DataFrame) -> pd.DataFrame:
    g = (ll.groupby(["leader", "follower", "phase"])
           .agg(mean_lead_ms=("lead_ms", "mean"),
                median_lead_ms=("lead_ms", "median"),
                sd_lead_ms=("lead_ms", "std"),
                mean_peak_corr=("peak_corr", "mean"),
                n=("lead_ms", "size"))
           .reset_index())
    g["se_lead_ms"] = g.sd_lead_ms / np.sqrt(g.n)
    g["t_stat"] = g.mean_lead_ms / g.se_lead_ms
    return g
