"""Configuration for the Week 3 liquidity study.

Everything that is a number I chose rather than a number I measured lives in this
file, so it is easy to see what the results depend on. That matters a lot here --
see the note at the bottom.
"""
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
FIGS = OUT / "figures"
for _p in (DATA, OUT, FIGS):
    _p.mkdir(parents=True, exist_ok=True)

SYMBOL = "BTC/USDT"
SEED = 20260821

# ---------------------------------------------------------------- sampling ---
# The live collector maintains a local book from each venue's incremental depth
# stream and writes a snapshot on a fixed grid. Two grids, because the two jobs
# have different resolution needs:
#   - event detection only needs the mid, and 1s is plenty for a ">1% in 60s" rule
#   - the depth / slippage / recovery work needs the full book, but only around
#     events, and there 1s is too coarse to see replenishment
SNAP_MS_COARSE = 1000        # continuous, mid only
SNAP_MS_FINE = 250           # full book, event windows only

# What actually gets stored per fine snapshot. Storing raw price levels does not
# work here: the top 20 raw levels of BTC/USDT on Binance span about 2bps (tick is
# $0.01) so they cannot answer "depth within 50bps", and storing the top 1000
# levels for 30 days at 250ms across three venues is ~100 GB. So the collector
# rebins the book onto fixed 1bp buckets out to 50bps, which is lossless for
# everything the brief asks for, plus the top 5 aggregated slices for the
# recovery metric.
BIN_BPS = 1.0
BIN_MAX_BPS = 50
N_BINS = int(BIN_MAX_BPS / BIN_BPS)
RAW_SLICE_BPS = 0.2          # width of an aggregated "level"
N_RAW_SLICES = 5

SAMPLE_DAYS = 30
WINDOW_PRE_S = 300           # event window starts 5 min before
WINDOW_POST_S = 300          # ... and ends 5 min after

# ------------------------------------------------------------------ events ---
EVENT_MOVE_PCT = 1.0         # |mid return| over the lookback
EVENT_LOOKBACK_S = 60
EVENT_COOLDOWN_S = 1800      # 30 min, so one selloff is not counted eight times
EVENT_TARGET_RANGE = (20, 30)

# ------------------------------------------------------------------- clips ---
CLIP_SIZES_USD = [10_000, 50_000, 100_000, 250_000, 500_000, 1_000_000]
DEPTH_BANDS_BPS = [1, 5, 10, 25, 50]

# ---------------------------------------------------------------- recovery ---
RECOVERY_LEVELS = 3          # "top 3 levels" from the brief (as 0.2bp slices, see README)
RECOVERY_THRESHOLD = 0.80    # back to 80% of the pre-event baseline
RECOVERY_PERSIST = 20        # ... and hold it for 20 consecutive snapshots (5s)
RECOVERY_CENSOR_S = 300      # give up after 5 min and mark as censored


@dataclass
class Venue:
    name: str
    ws_url: str
    depth_channel: str
    taker_fee_bps: float
    # ---- book shape in calm conditions -------------------------------------
    spread_bps: float        # median quoted spread
    depth_10bps_usd: float   # USD resting within 10bps of mid, one side
    shape_beta: float        # cumulative depth ~ distance^beta; higher = thinner at touch
    tick_usd: float
    # ---- behaviour under stress --------------------------------------------
    depth_collapse: float    # fraction of depth that survives at the trough
    spread_blowout: float    # multiple applied to the quoted spread at the trough
    recovery_halflife_s: float
    quote_lag_ms: float      # lag behind the common efficient price
    noise_bps: float         # sd of venue-specific microstructure noise


# NOTE ON THESE NUMBERS. Fees are public and correct as of Aug 2026. Everything
# below the fee line is a prior, not a measurement -- I set the calm depth from
# eyeballing public depth charts and the stress parameters from what I would
# expect given each venue's maker programme. On live data these get overwritten
# by what the collector sees. See the provenance warning in the README.
VENUES = {
    "binance": Venue(
        name="binance",
        ws_url="wss://stream.binance.com:9443/ws",
        depth_channel="btcusdt@depth@100ms",
        taker_fee_bps=10.0,
        spread_bps=0.9, depth_10bps_usd=3_200_000, shape_beta=1.18, tick_usd=0.01,
        depth_collapse=0.34, spread_blowout=4.2, recovery_halflife_s=18.0,
        quote_lag_ms=0.0, noise_bps=0.35,
    ),
    "okx": Venue(
        name="okx",
        ws_url="wss://ws.okx.com:8443/ws/v5/public",
        depth_channel="books",
        taker_fee_bps=10.0,
        spread_bps=1.4, depth_10bps_usd=1_150_000, shape_beta=1.28, tick_usd=0.1,
        depth_collapse=0.29, spread_blowout=5.1, recovery_halflife_s=26.0,
        quote_lag_ms=180.0, noise_bps=0.55,
    ),
    "bybit": Venue(
        name="bybit",
        ws_url="wss://stream.bybit.com/v5/public/spot",
        depth_channel="orderbook.200.BTCUSDT",
        taker_fee_bps=10.0,
        spread_bps=1.2, depth_10bps_usd=1_400_000, shape_beta=1.24, tick_usd=0.01,
        depth_collapse=0.41, spread_blowout=3.8, recovery_halflife_s=31.0,
        quote_lag_ms=320.0, noise_bps=0.48,
    ),
}
VENUE_ORDER = ["binance", "okx", "bybit"]

# ------------------------------------------------------- resilience scoring ---
# Four components, each mapped to 0-100 across the three venues, then weighted.
# The weights are a judgement call and I do not think there is a right answer,
# which is why run_all.py also resamples them -- see the sensitivity section.
SCORE_WEIGHTS = {
    "depth_retention": 0.30,   # how much of the book survives the trough
    "slippage_stability": 0.30,  # $1m slippage in stress vs calm
    "recovery_speed": 0.25,    # how quickly the top 3 levels come back
    "spread_stability": 0.15,  # how far the quoted spread blows out
}

# ---------------------------------------------------------------- baseline ---
# "calm" comparison periods, sampled away from any detected event
CALM_SAMPLES_PER_EVENT = 1
CALM_MIN_DISTANCE_S = 7200
