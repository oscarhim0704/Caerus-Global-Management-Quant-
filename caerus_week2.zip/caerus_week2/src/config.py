"""
Configuration for the Week 2 funding rate arbitrage study.

Everything that is a number I looked up (fees, funding intervals, caps) lives in
here rather than being scattered through the code, so that if a venue changes its
fee schedule there is exactly one place to edit.

Fee figures are the public VIP-0 / base tier as of the study date. I am using the
base tier deliberately -- an intern account would not have volume rebates, and if
a strategy only works at VIP 5 that is worth knowing separately.
"""

from dataclasses import dataclass, field


# ----------------------------------------------------------------------------
# Exchanges
# ----------------------------------------------------------------------------

@dataclass
class Exchange:
    name: str
    funding_hours: int        # settlement interval in hours
    taker_fee_bps: float      # per side, base tier
    maker_fee_bps: float      # per side, base tier (negative would be a rebate)
    funding_cap: float        # max absolute funding per settlement, as a decimal
    typical_spread_bps: float # top-of-book spread on a tier-1 name
    depth_1bp_usd: float      # USD notional resting within 1bp of mid, tier-1 name
    liquidity_factor: float   # relative size vs Binance, used to scale depth
    settle_offset_h: int = 0  # hour-of-day offset of the first settlement


EXCHANGES = {
    "binance": Exchange(
        name="binance",
        funding_hours=8,
        taker_fee_bps=5.0,
        maker_fee_bps=2.0,
        funding_cap=0.0075,
        typical_spread_bps=0.8,
        depth_1bp_usd=1_200_000,
        liquidity_factor=1.00,
        settle_offset_h=0,      # 00:00 / 08:00 / 16:00 UTC
    ),
    "bybit": Exchange(
        name="bybit",
        funding_hours=8,
        taker_fee_bps=5.5,
        maker_fee_bps=2.0,
        funding_cap=0.0075,
        typical_spread_bps=1.0,
        depth_1bp_usd=650_000,
        liquidity_factor=0.55,
        settle_offset_h=0,
    ),
    "okx": Exchange(
        name="okx",
        funding_hours=8,
        taker_fee_bps=5.0,
        maker_fee_bps=2.0,
        funding_cap=0.0150,
        typical_spread_bps=1.1,
        depth_1bp_usd=520_000,
        liquidity_factor=0.45,
        settle_offset_h=0,
    ),
    # Hyperliquid is the interesting one for this task: it settles every hour,
    # so its rates cannot be compared to the others without normalising first.
    "hyperliquid": Exchange(
        name="hyperliquid",
        funding_hours=1,
        taker_fee_bps=4.5,
        maker_fee_bps=1.5,
        funding_cap=0.0040,     # per hour
        typical_spread_bps=1.4,
        depth_1bp_usd=280_000,
        liquidity_factor=0.24,
        settle_offset_h=0,
    ),
}

# Settlements per year, used to annualise. 8h venues settle 3x/day, HL 24x/day.
def settlements_per_year(exchange: str) -> float:
    return 365.0 * 24.0 / EXCHANGES[exchange].funding_hours


# ----------------------------------------------------------------------------
# Symbol universe
# ----------------------------------------------------------------------------
# 36 perpetuals split into three liquidity tiers. The task asked for 30+, and I
# wanted enough small names to see whether the opportunity is concentrated in
# illiquid instruments (it is -- see the report).

@dataclass
class Symbol:
    ticker: str
    tier: int                 # 1 = major, 2 = mid, 3 = small
    depth_mult: float         # depth relative to a tier-1 name on the same venue
    funding_vol_mult: float   # how volatile this name's funding is vs BTC
    listed_on: list = field(default_factory=list)


def _sym(ticker, tier, depth_mult, fvol, venues):
    return Symbol(ticker, tier, depth_mult, fvol, venues)


_ALL4 = ["binance", "bybit", "okx", "hyperliquid"]
_NO_OKX = ["binance", "bybit", "hyperliquid"]
_NO_HL = ["binance", "bybit", "okx"]
_BB_HL = ["binance", "bybit", "hyperliquid"]

UNIVERSE = [
    # --- Tier 1: majors ---------------------------------------------------
    _sym("BTC",   1, 1.00, 1.00, _ALL4),
    _sym("ETH",   1, 0.72, 1.05, _ALL4),
    _sym("SOL",   1, 0.38, 1.25, _ALL4),
    _sym("XRP",   1, 0.30, 1.30, _ALL4),
    _sym("BNB",   1, 0.22, 1.20, _NO_HL),
    _sym("DOGE",  1, 0.25, 1.40, _ALL4),

    # --- Tier 2: mid caps -------------------------------------------------
    _sym("ADA",   2, 0.14, 1.45, _ALL4),
    _sym("AVAX",  2, 0.12, 1.55, _ALL4),
    _sym("LINK",  2, 0.13, 1.50, _ALL4),
    _sym("DOT",   2, 0.10, 1.50, _ALL4),
    _sym("LTC",   2, 0.11, 1.35, _ALL4),
    _sym("TRX",   2, 0.09, 1.40, _NO_HL),
    _sym("NEAR",  2, 0.08, 1.65, _ALL4),
    _sym("APT",   2, 0.08, 1.70, _ALL4),
    _sym("ARB",   2, 0.09, 1.70, _ALL4),
    _sym("OP",    2, 0.07, 1.75, _ALL4),
    _sym("SUI",   2, 0.10, 1.80, _ALL4),
    _sym("INJ",   2, 0.06, 1.85, _NO_OKX),
    _sym("TIA",   2, 0.06, 1.90, _ALL4),
    _sym("ATOM",  2, 0.07, 1.55, _ALL4),

    # --- Tier 3: small caps ----------------------------------------------
    _sym("SEI",   3, 0.040, 2.10, _ALL4),
    _sym("LDO",   3, 0.035, 2.00, _NO_OKX),
    _sym("AAVE",  3, 0.045, 1.95, _ALL4),
    _sym("CRV",   3, 0.030, 2.20, _NO_HL),
    _sym("RUNE",  3, 0.025, 2.30, _BB_HL),
    _sym("FIL",   3, 0.035, 1.90, _ALL4),
    _sym("ETC",   3, 0.038, 1.80, _NO_HL),
    _sym("ICP",   3, 0.028, 2.05, _ALL4),
    _sym("IMX",   3, 0.022, 2.25, _NO_OKX),
    _sym("STX",   3, 0.024, 2.30, _BB_HL),
    _sym("PENDLE",3, 0.020, 2.40, _NO_OKX),
    _sym("JUP",   3, 0.026, 2.35, _ALL4),
    _sym("WLD",   3, 0.032, 2.45, _ALL4),
    _sym("ORDI",  3, 0.018, 2.55, _NO_OKX),
    _sym("GMX",   3, 0.015, 2.20, _BB_HL),
    _sym("ENA",   3, 0.030, 2.50, _ALL4),
]

SYMBOLS = {s.ticker: s for s in UNIVERSE}
TICKERS = [s.ticker for s in UNIVERSE]

TIER_LABEL = {1: "Tier 1 (major)", 2: "Tier 2 (mid)", 3: "Tier 3 (small)"}


def pairs_for(ticker: str):
    """All ordered venue pairs (long_venue, short_venue) where a symbol is listed."""
    venues = SYMBOLS[ticker].listed_on
    out = []
    for a in venues:
        for b in venues:
            if a != b:
                out.append((a, b))
    return out


# ----------------------------------------------------------------------------
# Study / backtest parameters
# ----------------------------------------------------------------------------

DAYS = 90                      # length of the sample
SEED = 20260814

CAPITAL_USD = 1_000_000.0      # notional the book is allowed to deploy
MAX_CONCURRENT = 6             # how many pairs we hold at once
LEVERAGE = 3.0                 # notional per leg / margin posted per leg
MAINT_MARGIN = 0.005           # 0.5% maintenance margin, isolated

# If a leg is liquidated the exchange takes the whole isolated margin and
# charges a clearance fee on top. 75bp is mid-range across the four venues.
LIQ_FEE_BPS = 75.0
# How long it takes to notice and unwind the surviving leg. This matters: the
# hedge is only worth what it is worth when you actually close it.
LIQ_UNWIND_DELAY_H = 1

# Entry gate: annualised net carry must beat this before we look at a trade.
MIN_NET_CARRY_ANN = 0.05       # 5% annualised
# Exit when the pair's own annualised gross spread falls under this.
EXIT_CARRY_ANN = 0.01
MAX_HOLD_INTERVALS = 42        # 14 days at 8h -- hard stop so nothing sits forever

# Sizing rule: pick the largest leg notional whose expected slippage from
# walking the book is still under this. Using an impact budget rather than a
# flat "x% of depth" rule means thin names get sized down automatically.
MAX_IMPACT_BPS = 3.0

# Maker execution never fills at the touch for free -- you queue, you get
# repriced, and sometimes you cross to finish. This is the haircut I charge
# on top of the maker fee. It is a guess, not something I measured.
MAKER_SLIPPAGE_BPS = 1.0
