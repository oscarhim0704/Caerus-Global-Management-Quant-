"""
Event-driven backtest for the cross-venue funding carry trade.

Structure of a trade: long the perp on the cheap-funding venue, short the same
perp on the expensive-funding venue, same notional both sides. Delta is roughly
flat, so the PnL is

    funding collected  -  round-trip execution cost  +/-  basis drift

The third term is the one people forget. The two legs are marked on two
different venues, so the position is not actually delta-flat -- it is long the
basis between the two venues. On the majors this is a rounding error. On a
small cap on a thin venue it is not.

What is modelled
  - funding settled every 8h on the common grid, at the venue's own rate
  - taker or maker entry/exit, fees + half-spread + book-walking impact
  - position size capped by an impact budget on the thinner leg
  - isolated margin per leg, with an hourly liquidation check on both venues
  - one position per symbol, a cap on concurrent positions

What is not modelled
  - limit order fill probability (needs trade prints, which I do not have)
  - funding rate caps binding during a squeeze
  - transferring margin between venues mid-trade (see the report -- this is the
    single biggest thing that would change the liquidation numbers)
"""

import numpy as np
import pandas as pd

from src.config import (LEVERAGE, MAINT_MARGIN, MAX_CONCURRENT, CAPITAL_USD,
                        EXIT_CARRY_ANN, MAX_HOLD_INTERVALS, LIQ_FEE_BPS,
                        LIQ_UNWIND_DELAY_H)
from src.screen import PER_YEAR_8H

# Fractional adverse move that wipes the isolated margin on one leg.
def liq_move(leverage=LEVERAGE, maint=MAINT_MARGIN):
    return 1.0 / leverage - maint


# ----------------------------------------------------------------------------
# lookups
# ----------------------------------------------------------------------------

def build_lookups(panel, marks):
    """Dicts keyed for fast access inside the event loop."""
    rate = {}
    for r in panel.itertuples():
        rate[(r.symbol, r.exchange, r.ts)] = r.rate_8h

    mk = {}
    for r in marks.itertuples():
        mk[(r.symbol, r.exchange, r.ts)] = r.mark_price
    return rate, mk


def path_between(mk, symbol, exchange, t0, t1):
    """Hourly marks in (t0, t1], used for the liquidation check."""
    out = []
    t = t0 + pd.Timedelta(hours=1)
    while t <= t1:
        v = mk.get((symbol, exchange, t))
        if v is not None:
            out.append((t, v))
        t += pd.Timedelta(hours=1)
    return out


# ----------------------------------------------------------------------------
# the loop
# ----------------------------------------------------------------------------

def run(opportunities, panel, marks, leverage=LEVERAGE,
        max_concurrent=MAX_CONCURRENT, capital=CAPITAL_USD,
        exit_carry_ann=EXIT_CARRY_ANN, max_hold=MAX_HOLD_INTERVALS,
        ref_notional=250_000.0, verbose=False):

    rate, mk = build_lookups(panel, marks)
    lm = liq_move(leverage)

    stamps = sorted(opportunities.ts.unique())
    by_ts = {t: g for t, g in opportunities.groupby("ts")}
    # Signal lookup so an OPEN position can be checked on its own pair, not on
    # whatever pair happens to look best right now. Getting this wrong makes the
    # book churn: you exit a perfectly good trade because a different pair on
    # the same symbol is now wider.
    sig = {}
    for r in opportunities.itertuples():
        sig[(r.symbol, r.ts)] = r

    open_pos = []
    trades = []
    equity_rows = []
    cash = 0.0

    for i, t in enumerate(stamps):
        t = pd.Timestamp(t)

        # ---------------- 1. funding settles on everything held -------------
        funding_this_step = 0.0
        for p in open_pos:
            r_s = rate.get((p["symbol"], p["short_venue"], t))
            r_l = rate.get((p["symbol"], p["long_venue"], t))
            if r_s is None or r_l is None:
                continue
            amt = (r_s - r_l) * p["notional"]
            p["funding_pnl"] += amt
            funding_this_step += amt
            p["intervals"] += 1

        # ---------------- 2. liquidation check, hour by hour ----------------
        still_open = []
        for p in open_pos:
            liquidated = None
            t_prev = p["last_check"]
            long_path = path_between(mk, p["symbol"], p["long_venue"], t_prev, t)
            short_path = path_between(mk, p["symbol"], p["short_venue"], t_prev, t)
            for (ta, pl), (_, ps) in zip(long_path, short_path):
                if pl <= p["entry_mark_long"] * (1 - lm):
                    liquidated = ("long", ta)
                    break
                if ps >= p["entry_mark_short"] * (1 + lm):
                    liquidated = ("short", ta)
                    break
            p["last_check"] = t
            if liquidated:
                side, t_liq = liquidated
                # The surviving leg is not closed at the liquidation print --
                # it is closed once someone reacts, LIQ_UNWIND_DELAY_H later.
                t_unwind = t_liq + pd.Timedelta(hours=LIQ_UNWIND_DELAY_H)
                p["liquidated"] = True
                p["liq_side"] = side
                p["exit_ts"] = t_unwind
                p["exit_mark_long"] = mk.get((p["symbol"], p["long_venue"], t_unwind),
                                             p["entry_mark_long"])
                p["exit_mark_short"] = mk.get((p["symbol"], p["short_venue"], t_unwind),
                                              p["entry_mark_short"])
                trades.append(close_position(p, liquidated=True, leverage=leverage))
            else:
                still_open.append(p)
        open_pos = still_open

        # ---------------- 3. discretionary exits ----------------------------
        still_open = []
        for p in open_pos:
            row = sig.get((p["symbol"], t))
            # Own-pair spread, not the best pair available on this symbol.
            r_s = rate.get((p["symbol"], p["short_venue"], t))
            r_l = rate.get((p["symbol"], p["long_venue"], t))
            own_carry_ann = ((r_s - r_l) * PER_YEAR_8H
                             if (r_s is not None and r_l is not None) else 0.0)
            p["carry_history"].append(own_carry_ann)
            smoothed = float(np.mean(p["carry_history"][-3:]))

            reason = None
            if smoothed < exit_carry_ann:
                reason = "carry gone"
            elif p["intervals"] >= max_hold:
                reason = "max hold"
            elif i == len(stamps) - 1:
                reason = "end of sample"

            if reason:
                p["exit_ts"] = t
                p["exit_mark_long"] = mk.get((p["symbol"], p["long_venue"], t),
                                             p["entry_mark_long"])
                p["exit_mark_short"] = mk.get((p["symbol"], p["short_venue"], t),
                                              p["entry_mark_short"])
                p["exit_reason"] = reason
                trades.append(close_position(p, leverage=leverage))
            else:
                still_open.append(p)
        open_pos = still_open

        # ---------------- 4. new entries ------------------------------------
        held_symbols = {p["symbol"] for p in open_pos}
        margin_used = sum(p["margin"] for p in open_pos)

        cands = by_ts.get(t)
        if cands is not None and len(open_pos) < max_concurrent:
            cands = cands[cands.tradeable].sort_values("net_pnl_bps",
                                                       ascending=False)
            for r in cands.itertuples():
                if len(open_pos) >= max_concurrent:
                    break
                if r.symbol in held_symbols:
                    continue
                notional = min(ref_notional, r.capacity_usd)
                margin = 2.0 * notional / leverage
                if margin_used + margin > capital:
                    continue
                ml = mk.get((r.symbol, r.long_venue, t))
                ms = mk.get((r.symbol, r.short_venue, t))
                if ml is None or ms is None:
                    continue

                entry_cost = r.round_trip_bps / 2.0 / 1e4 * notional * 2
                cash -= entry_cost
                open_pos.append({
                    "symbol": r.symbol, "tier": r.tier,
                    "long_venue": r.long_venue, "short_venue": r.short_venue,
                    "entry_ts": t, "notional": notional, "margin": margin,
                    "entry_mark_long": ml, "entry_mark_short": ms,
                    "entry_carry_ann": r.carry_ann,
                    "round_trip_bps": r.round_trip_bps,
                    "entry_cost": entry_cost,
                    "funding_pnl": 0.0, "intervals": 0,
                    "last_check": t, "carry_history": [],
                    "liquidated": False, "liq_side": None, "exit_reason": None,
                })
                held_symbols.add(r.symbol)
                margin_used += margin

        # ---------------- 5. equity curve -----------------------------------
        realised = sum(tr["net_pnl"] for tr in trades)
        unreal = sum(unrealised(p, mk, t) for p in open_pos)
        equity_rows.append({
            "ts": t,
            "realised_pnl": realised,
            "unrealised_pnl": unreal,
            "equity": capital + realised + unreal,
            "funding_this_step": funding_this_step,
            "n_open": len(open_pos),
            "margin_used": sum(p["margin"] for p in open_pos),
        })

    return pd.DataFrame(trades), pd.DataFrame(equity_rows)


# ----------------------------------------------------------------------------
# position accounting
# ----------------------------------------------------------------------------

def long_leg_pnl(p, exit_long):
    return (exit_long - p["entry_mark_long"]) / p["entry_mark_long"] * p["notional"]


def short_leg_pnl(p, exit_short):
    return (p["entry_mark_short"] - exit_short) / p["entry_mark_short"] * p["notional"]


def leg_price_pnl(p, exit_long, exit_short):
    """
    Both legs are the same size, so the common price move cancels and what is
    left is the change in the basis between the two venues. Only valid while
    BOTH legs are still open -- once one is force-closed they must be accounted
    for separately, which is what close_position does.
    """
    return long_leg_pnl(p, exit_long) + short_leg_pnl(p, exit_short)


def unrealised(p, mk, t):
    el = mk.get((p["symbol"], p["long_venue"], t), p["entry_mark_long"])
    es = mk.get((p["symbol"], p["short_venue"], t), p["entry_mark_short"])
    return p["funding_pnl"] + leg_price_pnl(p, el, es) - p["entry_cost"]


def close_position(p, liquidated=False, leverage=LEVERAGE):
    """
    Normal close: both legs unwound at the exit marks, so the price term is just
    basis drift and the cost term is a full round trip.

    Liquidation: one leg is force-closed by the exchange, which keeps the whole
    isolated margin on that leg and charges a clearance fee. Crucially the OTHER
    leg is deep in profit at that moment -- a 33% move against the long is a 33%
    move in favour of the short -- so the damage is not the full margin. It is
    the maintenance buffer, the clearance fee, and whatever the surviving leg
    gives back between the liquidation print and the unwind. Netting the legs
    before applying the margin loss double-counts and makes liquidation look
    roughly ten times worse than it is.
    """
    exit_cost_one_leg = p["round_trip_bps"] / 4.0 / 1e4 * p["notional"]

    if liquidated:
        margin_per_leg = p["margin"] / 2.0
        dead_leg = -margin_per_leg
        if p["liq_side"] == "long":
            live_leg = short_leg_pnl(p, p["exit_mark_short"])
        else:
            live_leg = long_leg_pnl(p, p["exit_mark_long"])
        clearance = LIQ_FEE_BPS / 1e4 * p["notional"]
        price_pnl = dead_leg + live_leg
        exit_cost = exit_cost_one_leg
        reason = "liquidated"
    else:
        price_pnl = leg_price_pnl(p, p["exit_mark_long"], p["exit_mark_short"])
        clearance = 0.0
        exit_cost = 2 * exit_cost_one_leg
        reason = p["exit_reason"] or "closed"

    net = p["funding_pnl"] + price_pnl - p["entry_cost"] - exit_cost - clearance

    hold_h = (p["exit_ts"] - p["entry_ts"]).total_seconds() / 3600.0
    return {
        "symbol": p["symbol"], "tier": p["tier"],
        "long_venue": p["long_venue"], "short_venue": p["short_venue"],
        "entry_ts": p["entry_ts"], "exit_ts": p["exit_ts"],
        "hold_hours": hold_h, "intervals": p["intervals"],
        "notional": p["notional"], "margin": p["margin"],
        "entry_carry_ann": p["entry_carry_ann"],
        "funding_pnl": p["funding_pnl"],
        "price_pnl": price_pnl,
        "cost_pnl": -(p["entry_cost"] + exit_cost),
        "liq_fee_pnl": -clearance,
        "net_pnl": net,
        "net_bps": net / p["notional"] * 1e4,
        "liquidated": liquidated,
        "exit_reason": reason,
    }


# ----------------------------------------------------------------------------
# summary stats
# ----------------------------------------------------------------------------

def summarise(trades, equity, capital=CAPITAL_USD):
    if len(trades) == 0:
        return {"trades": 0}

    days = (equity.ts.max() - equity.ts.min()).total_seconds() / 86400.0
    years = days / 365.0
    net = trades.net_pnl.sum()

    # Notional-weighted holding, used to express return per dollar actually at risk.
    notional_days = (trades.notional * trades.hold_hours / 24.0).sum()
    avg_notional = notional_days / days if days else np.nan

    step = equity.equity.diff().dropna()
    per_year = PER_YEAR_8H
    sharpe = (step.mean() / step.std() * np.sqrt(per_year)) if step.std() > 0 else np.nan

    peak = equity.equity.cummax()
    max_dd = float((equity.equity - peak).min())

    return {
        "trades": int(len(trades)),
        "days": round(days, 1),
        "total_net_pnl_usd": round(net, 0),
        "gross_funding_usd": round(trades.funding_pnl.sum(), 0),
        "cost_usd": round(trades.cost_pnl.sum(), 0),
        "liq_fee_usd": round(trades.liq_fee_pnl.sum(), 0),
        "basis_pnl_usd": round(trades.price_pnl.sum(), 0),
        "avg_notional_usd": round(avg_notional, 0),
        "ann_return_on_notional_pct": round(net / avg_notional / years * 100, 2)
                                      if avg_notional else np.nan,
        "ann_return_on_capital_pct": round(net / capital / years * 100, 2),
        "sharpe": round(float(sharpe), 2),
        "max_drawdown_usd": round(max_dd, 0),
        "hit_rate_pct": round(float((trades.net_pnl > 0).mean() * 100), 1),
        "liquidation_rate_pct": round(float(trades.liquidated.mean() * 100), 1),
        "avg_hold_days": round(float(trades.hold_hours.mean() / 24.0), 2),
        "avg_net_bps": round(float(trades.net_bps.mean()), 2),
        "mean_margin_used_usd": round(float(equity.margin_used.mean()), 0),
    }
