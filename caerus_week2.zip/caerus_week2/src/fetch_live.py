"""
Pulls real funding history + order book depth from the four venues.

This is the module you point at the live APIs. It writes exactly the same three
CSVs that make_dataset.py writes, so everything downstream (screen.py,
backtest.py, run_all.py) does not care which one produced the data.

    python -m src.fetch_live            # ~90 days, all 36 symbols

Endpoints used (all public, no API key needed):
  Binance     GET  https://fapi.binance.com/fapi/v1/fundingRate
              GET  https://fapi.binance.com/fapi/v1/depth
  Bybit       GET  https://api.bybit.com/v5/market/funding/history
              GET  https://api.bybit.com/v5/market/orderbook
  OKX         GET  https://www.okx.com/api/v5/public/funding-rate-history
              GET  https://www.okx.com/api/v5/market/books
  Hyperliquid POST https://api.hyperliquid.xyz/info   (type=fundingHistory / l2Book)

NOTE ON THE SUBMITTED RUN: the machine I built this on has no outbound network
access, so the numbers in the report come from make_dataset.py, not from here.
This file is written and the request/parse logic is real, but it is untested
against the live endpoints. Running the command above regenerates everything
from live data.
"""

import time
import json
import urllib.request
import urllib.parse
from datetime import datetime, timedelta, timezone

import pandas as pd

from src.config import EXCHANGES, UNIVERSE, SYMBOLS, DAYS

TIMEOUT = 20
PAUSE = 0.25          # be polite; all four have per-IP rate limits


# ----------------------------------------------------------------------------
# tiny HTTP helpers
# ----------------------------------------------------------------------------

def _get(url, params=None):
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "caerus-week2/1.0"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode())


def _post(url, payload):
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json",
                 "User-Agent": "caerus-week2/1.0"},
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode())


def _ms(dt):
    return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)


# ----------------------------------------------------------------------------
# funding history, one venue at a time
# ----------------------------------------------------------------------------
# Each venue returns a different shape, so each gets its own small function that
# normalises to (ts, exchange, symbol, funding_rate, interval_hours).

def binance_funding(ticker, start, end):
    rows, cursor = [], _ms(start)
    while cursor < _ms(end):
        data = _get("https://fapi.binance.com/fapi/v1/fundingRate",
                    {"symbol": f"{ticker}USDT", "startTime": cursor,
                     "endTime": _ms(end), "limit": 1000})
        if not data:
            break
        for d in data:
            rows.append({"ts": pd.to_datetime(d["fundingTime"], unit="ms"),
                         "funding_rate": float(d["fundingRate"])})
        cursor = data[-1]["fundingTime"] + 1
        time.sleep(PAUSE)
    return rows


def bybit_funding(ticker, start, end):
    rows, cursor = [], _ms(end)
    # Bybit pages backwards from endTime.
    while cursor > _ms(start):
        data = _get("https://api.bybit.com/v5/market/funding/history",
                    {"category": "linear", "symbol": f"{ticker}USDT",
                     "startTime": _ms(start), "endTime": cursor, "limit": 200})
        items = data.get("result", {}).get("list", [])
        if not items:
            break
        for d in items:
            rows.append({"ts": pd.to_datetime(int(d["fundingRateTimestamp"]), unit="ms"),
                         "funding_rate": float(d["fundingRate"])})
        cursor = int(items[-1]["fundingRateTimestamp"]) - 1
        time.sleep(PAUSE)
    return rows


def okx_funding(ticker, start, end):
    rows, cursor = [], _ms(end)
    while cursor > _ms(start):
        data = _get("https://www.okx.com/api/v5/public/funding-rate-history",
                    {"instId": f"{ticker}-USDT-SWAP", "after": cursor, "limit": 100})
        items = data.get("data", [])
        if not items:
            break
        for d in items:
            rows.append({"ts": pd.to_datetime(int(d["fundingTime"]), unit="ms"),
                         "funding_rate": float(d["fundingRate"])})
        cursor = int(items[-1]["fundingTime"]) - 1
        time.sleep(PAUSE)
    return rows


def hyperliquid_funding(ticker, start, end):
    rows, cursor = [], _ms(start)
    while cursor < _ms(end):
        data = _post("https://api.hyperliquid.xyz/info",
                     {"type": "fundingHistory", "coin": ticker,
                      "startTime": cursor, "endTime": _ms(end)})
        if not data:
            break
        for d in data:
            rows.append({"ts": pd.to_datetime(d["time"], unit="ms"),
                         "funding_rate": float(d["fundingRate"])})
        cursor = data[-1]["time"] + 1
        time.sleep(PAUSE)
    return rows


FUNDING_FN = {
    "binance": binance_funding,
    "bybit": bybit_funding,
    "okx": okx_funding,
    "hyperliquid": hyperliquid_funding,
}


# ----------------------------------------------------------------------------
# order book depth (one snapshot per venue/symbol -- enough for a size cap)
# ----------------------------------------------------------------------------

def _depth_from_levels(bids, asks, bps=1.0):
    """USD resting within `bps` of mid, and the top-of-book spread in bps."""
    if not bids or not asks:
        return None
    best_bid, best_ask = float(bids[0][0]), float(asks[0][0])
    mid = 0.5 * (best_bid + best_ask)
    spread_bps = (best_ask - best_bid) / mid * 1e4
    window = mid * bps / 1e4
    usd = 0.0
    for p, q in bids:
        p, q = float(p), float(q)
        if mid - p <= window:
            usd += p * q
    for p, q in asks:
        p, q = float(p), float(q)
        if p - mid <= window:
            usd += p * q
    return {"depth_1bp_usd": usd, "spread_bps": spread_bps}


def fetch_depth(exchange, ticker):
    if exchange == "binance":
        d = _get("https://fapi.binance.com/fapi/v1/depth",
                 {"symbol": f"{ticker}USDT", "limit": 100})
        return _depth_from_levels(d["bids"], d["asks"])
    if exchange == "bybit":
        d = _get("https://api.bybit.com/v5/market/orderbook",
                 {"category": "linear", "symbol": f"{ticker}USDT", "limit": 50})
        r = d["result"]
        return _depth_from_levels(r["b"], r["a"])
    if exchange == "okx":
        d = _get("https://www.okx.com/api/v5/market/books",
                 {"instId": f"{ticker}-USDT-SWAP", "sz": 100})
        r = d["data"][0]
        return _depth_from_levels([x[:2] for x in r["bids"]],
                                  [x[:2] for x in r["asks"]])
    if exchange == "hyperliquid":
        d = _post("https://api.hyperliquid.xyz/info", {"type": "l2Book", "coin": ticker})
        bids = [[lv["px"], lv["sz"]] for lv in d["levels"][0]]
        asks = [[lv["px"], lv["sz"]] for lv in d["levels"][1]]
        return _depth_from_levels(bids, asks)
    raise ValueError(exchange)


# ----------------------------------------------------------------------------
# mark prices -- 1h candles, used as the mark for PnL and liquidation checks
# ----------------------------------------------------------------------------

def binance_marks(ticker, start, end):
    rows, cursor = [], _ms(start)
    while cursor < _ms(end):
        data = _get("https://fapi.binance.com/fapi/v1/markPriceKlines",
                    {"symbol": f"{ticker}USDT", "interval": "1h",
                     "startTime": cursor, "endTime": _ms(end), "limit": 1000})
        if not data:
            break
        for d in data:
            rows.append({"ts": pd.to_datetime(d[0], unit="ms"),
                         "mark_price": float(d[4])})
        cursor = data[-1][0] + 3_600_000
        time.sleep(PAUSE)
    return rows


# ----------------------------------------------------------------------------
# driver
# ----------------------------------------------------------------------------

def build(days=DAYS, outdir="data"):
    end = datetime.utcnow().replace(minute=0, second=0, microsecond=0)
    start = end - timedelta(days=days)

    funding_rows, depth_rows, mark_rows = [], [], []

    for sym in UNIVERSE:
        for ex in sym.listed_on:
            try:
                got = FUNDING_FN[ex](sym.ticker, start, end)
            except Exception as e:                      # noqa: BLE001
                print(f"  ! funding {ex} {sym.ticker}: {e}")
                continue
            for r in got:
                funding_rows.append({**r, "exchange": ex, "symbol": sym.ticker,
                                     "interval_hours": EXCHANGES[ex].funding_hours})
            try:
                d = fetch_depth(ex, sym.ticker)
                if d:
                    depth_rows.append({**d, "exchange": ex, "symbol": sym.ticker})
            except Exception as e:                      # noqa: BLE001
                print(f"  ! depth {ex} {sym.ticker}: {e}")
        print(f"{sym.ticker:8s} done")

        # One mark series per symbol (Binance) is enough for liquidation checks;
        # per-venue basis is small relative to the moves that matter here.
        try:
            for r in binance_marks(sym.ticker, start, end):
                mark_rows.append({**r, "symbol": sym.ticker})
        except Exception as e:                          # noqa: BLE001
            print(f"  ! marks {sym.ticker}: {e}")

    funding = pd.DataFrame(funding_rows).drop_duplicates(["ts", "exchange", "symbol"])
    depth = pd.DataFrame(depth_rows)
    marks = pd.DataFrame(mark_rows).drop_duplicates(["ts", "symbol"])

    # Give every venue its own copy of the mark so the schema matches the simulator.
    expanded = []
    for ex in EXCHANGES:
        m = marks.copy()
        m["exchange"] = ex
        expanded.append(m)
    marks = pd.concat(expanded, ignore_index=True)

    funding.to_csv(f"{outdir}/funding_panel.csv.gz", index=False)
    marks.to_csv(f"{outdir}/marks.csv.gz", index=False)
    depth.to_csv(f"{outdir}/depth.csv.gz", index=False)
    print(f"\nfunding {len(funding):,} rows | marks {len(marks):,} | depth {len(depth):,}")


if __name__ == "__main__":
    build()
