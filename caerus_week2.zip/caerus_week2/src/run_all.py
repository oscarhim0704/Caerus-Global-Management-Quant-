"""
Runs the whole study end to end and writes everything the report quotes.

    python -m src.run_all

Outputs:
    outputs/figures/*.png
    outputs/funding_arb_results.xlsx
    outputs/summary.txt
"""

import os
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src import config as cfg
from src import make_dataset
from src.screen import (load_panel, load_marks, to_common_8h_grid, to_wide,
                        cost_table, build_opportunities, spread_decay,
                        decay_factors, half_life, cumulative_carry,
                        add_ewma_signal, PER_YEAR_8H)
from src.backtest import run, summarise, liq_move

warnings.filterwarnings("ignore")

FIG = "outputs/figures"
CAL_DAYS = 30          # first 30 days calibrate the decay curve, rest is the test
BLUE, ORANGE, GREY = "#1f4e79", "#c55a11", "#808080"
TIER_COLOR = {1: "#1f4e79", 2: "#c55a11", 3: "#548235"}


def _tidy(ax, title, xlabel="", ylabel=""):
    ax.set_title(title, fontsize=11, loc="left")
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(alpha=0.25, linewidth=0.6)
    ax.tick_params(labelsize=8)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


# ----------------------------------------------------------------------------
# figures
# ----------------------------------------------------------------------------

def fig_frequency(funding, panel):
    """Why the raw rates cannot be compared, and what they look like aligned."""
    sym = "SOL"
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.6))

    raw = funding[(funding.symbol == sym)]
    raw = raw[raw.ts < raw.ts.min() + pd.Timedelta(days=6)]
    for ex, g in raw.groupby("exchange"):
        axes[0].plot(g.ts, g.funding_rate * 1e4, lw=1.1, label=ex,
                     marker="." if ex != "hyperliquid" else None, ms=4)
    _tidy(axes[0], f"(a) {sym} raw printed funding rate — not comparable",
          "", "bps per settlement")
    axes[0].legend(fontsize=7, frameon=False)

    al = panel[(panel.symbol == sym)]
    al = al[al.ts < al.ts.min() + pd.Timedelta(days=6)]
    for ex, g in al.groupby("exchange"):
        axes[1].plot(g.ts, g.rate_8h * 1e4, lw=1.2, marker=".", ms=4, label=ex)
    _tidy(axes[1], f"(b) {sym} on a common 8h grid — hourly rates summed",
          "", "bps per 8h")
    axes[1].legend(fontsize=7, frameon=False)
    for a in axes:
        a.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    fig.savefig(f"{FIG}/frequency_normalisation.png", dpi=140)
    plt.close(fig)


def fig_dispersion(panel):
    """How wide the cross-venue spread is, by liquidity tier."""
    wide = to_wide(panel)
    sp = (wide.max(axis=1) - wide.min(axis=1)).rename("spread").reset_index()
    sp["tier"] = sp.symbol.map(lambda s: cfg.SYMBOLS[s].tier)
    sp["ann_pct"] = sp.spread * PER_YEAR_8H * 100

    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
    data = [sp[sp.tier == t].ann_pct.clip(upper=250) for t in (1, 2, 3)]
    bp = axes[0].boxplot(data, tick_labels=[cfg.TIER_LABEL[t] for t in (1, 2, 3)],
                         showfliers=False, patch_artist=True, widths=0.55)
    for patch, t in zip(bp["boxes"], (1, 2, 3)):
        patch.set_facecolor(TIER_COLOR[t]); patch.set_alpha(0.35)
    for med in bp["medians"]:
        med.set_color("black")
    _tidy(axes[0], "(a) Best-pair funding spread, annualised", "", "% p.a.")

    med = (sp.groupby("symbol").ann_pct.median()
             .sort_values(ascending=False))
    cols = [TIER_COLOR[cfg.SYMBOLS[s].tier] for s in med.index]
    axes[1].bar(range(len(med)), med.values, color=cols)
    axes[1].set_xticks(range(len(med)))
    axes[1].set_xticklabels(med.index, rotation=90, fontsize=6)
    _tidy(axes[1], "(b) Median spread by symbol (colour = tier)", "", "% p.a.")
    fig.tight_layout()
    fig.savefig(f"{FIG}/dispersion_by_tier.png", dpi=140)
    plt.close(fig)


def fig_decay(agg, cc, costs_taker, costs_maker):
    """The central figure: the entry spread does not stay put."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))

    for t in (1, 2, 3):
        g = agg[agg.tier == t].sort_values("lag")
        axes[0].plot(g.lag, g.ratio_to_entry, lw=1.6, color=TIER_COLOR[t],
                     label=cfg.TIER_LABEL[t])
    axes[0].axhline(0.5, color=GREY, ls="--", lw=0.9)
    axes[0].text(0.3, 0.52, "half of entry spread", fontsize=7, color=GREY)
    _tidy(axes[0], "(a) Survival of the entry spread, same pair held",
          "8h intervals after entry", "fraction of entry spread")
    axes[0].legend(fontsize=7, frameon=False)

    for t in (1, 2, 3):
        g = cc[cc.tier == t]
        axes[1].plot(g.hold_intervals, g.cum_carry_bps, lw=1.6,
                     color=TIER_COLOR[t], label=cfg.TIER_LABEL[t])
    for lbl, val, ls in [("median round trip, taker",
                          costs_taker, "--"),
                         ("median round trip, maker", costs_maker, ":")]:
        axes[1].axhline(val, color="black", ls=ls, lw=1.0)
        axes[1].text(0.4, val + 0.7, lbl, fontsize=7)
    _tidy(axes[1], "(b) Cumulative carry vs the cost of getting in and out",
          "8h intervals held", "bps of leg notional")
    axes[1].legend(fontsize=7, frameon=False, loc="upper left")
    fig.tight_layout()
    fig.savefig(f"{FIG}/decay_and_breakeven.png", dpi=140)
    plt.close(fig)


def fig_capacity(costs, opp):
    """Where the edge is, and how much size it will take."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))

    c = costs.copy()
    c["tier"] = c.symbol.map(lambda s: cfg.SYMBOLS[s].tier)
    for t in (1, 2, 3):
        g = c[c.tier == t]
        axes[0].scatter(g.max_notional_usd, g.fixed_cost_bps, s=18,
                        color=TIER_COLOR[t], alpha=0.7, label=cfg.TIER_LABEL[t])
    axes[0].set_xscale("log")
    _tidy(axes[0], "(a) One-way cost vs max leg size (taker)",
          "max leg notional, USD (log)", "one-way cost, bps")
    axes[0].legend(fontsize=7, frameon=False)

    o = opp.groupby("symbol").agg(net=("net_pnl_bps", "median"),
                                  cap=("capacity_usd", "median")).reset_index()
    o["tier"] = o.symbol.map(lambda s: cfg.SYMBOLS[s].tier)
    for t in (1, 2, 3):
        g = o[o.tier == t]
        axes[1].scatter(g.cap, g.net, s=26, color=TIER_COLOR[t],
                        alpha=0.8, label=cfg.TIER_LABEL[t])
    axes[1].axhline(0, color="black", lw=0.9)
    axes[1].set_xscale("log")
    _tidy(axes[1], "(b) Expected net edge vs capacity (maker, 7-day hold)",
          "capacity per leg, USD (log)", "net bps per round trip")
    axes[1].legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/capacity_vs_edge.png", dpi=140)
    plt.close(fig)


def fig_equity(eq_maker, tr_maker, eq_taker):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))

    for eq, lbl, col in [(eq_maker, "maker entry", BLUE),
                         (eq_taker, "taker entry", ORANGE)]:
        axes[0].plot(eq.ts, eq.equity - cfg.CAPITAL_USD, lw=1.4,
                     color=col, label=lbl)
    axes[0].axhline(0, color="black", lw=0.8)
    _tidy(axes[0], "(a) Cumulative PnL on $1m of capital", "", "USD")
    axes[0].legend(fontsize=8, frameon=False)
    axes[0].tick_params(axis="x", rotation=20)

    comp = pd.Series({
        "gross\nfunding": tr_maker.funding_pnl.sum(),
        "execution\ncost": tr_maker.cost_pnl.sum(),
        "basis +\nliquidated legs": tr_maker.price_pnl.sum(),
        "liquidation\nfees": tr_maker.liq_fee_pnl.sum(),
    })
    net = comp.sum()
    colors = [BLUE if v > 0 else ORANGE for v in comp.values]
    axes[1].bar(range(len(comp)), comp.values, color=colors)
    axes[1].bar(len(comp), net, color=GREY)
    axes[1].set_xticks(range(len(comp) + 1))
    axes[1].set_xticklabels(list(comp.index) + ["net"], fontsize=7.5)
    axes[1].axhline(0, color="black", lw=0.8)
    _tidy(axes[1], "(b) Where the PnL comes from (maker)", "", "USD")
    fig.tight_layout()
    fig.savefig(f"{FIG}/equity_and_attribution.png", dpi=140)
    plt.close(fig)


def fig_sensitivity(lev_df, thr_df):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))

    ax = axes[0]
    ax.plot(lev_df.leverage, lev_df.ann_return_on_capital_pct, "o-",
            color=BLUE, lw=1.6, label="return on capital")
    _tidy(ax, "(a) Leverage: return against liquidations",
          "leverage per leg", "% p.a. on capital")
    ax2 = ax.twinx()
    ax2.plot(lev_df.leverage, lev_df.liquidation_rate_pct, "s--",
             color=ORANGE, lw=1.4, label="liquidation rate")
    ax2.set_ylabel("% of trades liquidated", fontsize=9, color=ORANGE)
    ax2.tick_params(labelsize=8, colors=ORANGE)
    ax2.spines["top"].set_visible(False)
    ax.legend(fontsize=7, frameon=False, loc="lower left")
    ax2.legend(fontsize=7, frameon=False, loc="upper left",
               bbox_to_anchor=(0.0, 0.92))

    ax = axes[1]
    ax.plot(thr_df.min_net_carry_ann * 100, thr_df.ann_return_on_notional_pct,
            "o-", color=BLUE, lw=1.6)
    for _, r in thr_df.iterrows():
        ax.annotate(f"{int(r.trades)}", (r.min_net_carry_ann * 100,
                                         r.ann_return_on_notional_pct),
                    fontsize=7, xytext=(0, 6), textcoords="offset points",
                    ha="center")
    _tidy(ax, "(b) Entry threshold (labels = trade count)",
          "minimum net carry, % p.a.", "% p.a. on notional")
    fig.tight_layout()
    fig.savefig(f"{FIG}/sensitivity.png", dpi=140)
    plt.close(fig)


def fig_robustness(rob):
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    for i, (ex, g) in enumerate(rob.groupby("execution")):
        ax.scatter(g.ann_return_on_notional_pct, g.sharpe, s=45,
                   color=[BLUE, ORANGE][i], alpha=0.85, label=f"{ex} entry")
    ax.axvline(0, color="black", lw=0.8)
    ax.axhline(0, color="black", lw=0.8)
    _tidy(ax, "Eight independent simulated paths",
          "% p.a. on notional", "Sharpe")
    ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/robustness_paths.png", dpi=140)
    plt.close(fig)


# ----------------------------------------------------------------------------
# excel
# ----------------------------------------------------------------------------

def write_excel(path, universe_df, spec_df, snapshot, opp_maker, decay_tbl,
                cc, trades, summaries, lev_df, thr_df, sig_df, rob, notes):
    from openpyxl.styles import Font, Alignment, PatternFill
    from openpyxl.utils import get_column_letter

    with pd.ExcelWriter(path, engine="openpyxl") as xl:
        pd.DataFrame({"Read me": notes}).to_excel(xl, sheet_name="Read me", index=False)
        universe_df.to_excel(xl, sheet_name="Universe", index=False)
        spec_df.to_excel(xl, sheet_name="Exchange specs", index=False)
        snapshot.to_excel(xl, sheet_name="Funding snapshot", index=False)
        opp_maker.to_excel(xl, sheet_name="Opportunity screen", index=False)
        decay_tbl.to_excel(xl, sheet_name="Spread decay", index=False)
        cc.to_excel(xl, sheet_name="Breakeven", index=False)
        trades.to_excel(xl, sheet_name="Trade log", index=False)
        summaries.to_excel(xl, sheet_name="Backtest summary", index=False)
        lev_df.to_excel(xl, sheet_name="Sensitivity leverage", index=False)
        thr_df.to_excel(xl, sheet_name="Sensitivity threshold", index=False)
        sig_df.to_excel(xl, sheet_name="Sensitivity signal", index=False)
        rob.to_excel(xl, sheet_name="Robustness paths", index=False)

    # --- formatting pass, plus live formulas on the derived columns ---------
    from openpyxl import load_workbook
    wb = load_workbook(path)
    head_fill = PatternFill("solid", fgColor="1F4E79")

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for c in ws[1]:
            c.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
            c.fill = head_fill
            c.alignment = Alignment(horizontal="left", vertical="center",
                                    wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.font = Font(name="Arial", size=10)
        for i, col in enumerate(ws.columns, start=1):
            width = max((len(str(c.value)) for c in col if c.value is not None),
                        default=10)
            ws.column_dimensions[get_column_letter(i)].width = min(max(width + 2, 10), 34)

    # Funding snapshot: annualised columns as formulas off the 8h rates, so the
    # sheet still works if someone pastes their own rates in.
    ws = wb["Funding snapshot"]
    heads = [c.value for c in ws[1]]
    for src, dst in [("binance", "binance_ann_pct"), ("bybit", "bybit_ann_pct"),
                     ("okx", "okx_ann_pct"),
                     ("hyperliquid", "hyperliquid_ann_pct")]:
        if src in heads and dst in heads:
            s = get_column_letter(heads.index(src) + 1)
            d = get_column_letter(heads.index(dst) + 1)
            for r in range(2, ws.max_row + 1):
                ws[f"{d}{r}"] = f"=IFERROR({s}{r}*{PER_YEAR_8H}*100,\"\")"
                ws[f"{d}{r}"].number_format = "0.0"
                ws[f"{d}{r}"].font = Font(name="Arial", size=10)

    # Breakeven sheet: net = cumulative carry - round trip, as a formula.
    ws = wb["Breakeven"]
    heads = [c.value for c in ws[1]]
    if "cum_carry_bps" in heads and "net_vs_maker_bps" in heads:
        cc_col = get_column_letter(heads.index("cum_carry_bps") + 1)
        mk_col = get_column_letter(heads.index("maker_round_trip_bps") + 1)
        tk_col = get_column_letter(heads.index("taker_round_trip_bps") + 1)
        nm = get_column_letter(heads.index("net_vs_maker_bps") + 1)
        nt = get_column_letter(heads.index("net_vs_taker_bps") + 1)
        for r in range(2, ws.max_row + 1):
            ws[f"{nm}{r}"] = f"={cc_col}{r}-{mk_col}{r}"
            ws[f"{nt}{r}"] = f"={cc_col}{r}-{tk_col}{r}"
            for cl in (nm, nt):
                ws[f"{cl}{r}"].number_format = "0.0"
                ws[f"{cl}{r}"].font = Font(name="Arial", size=10)

    ws = wb["Read me"]
    ws.column_dimensions["A"].width = 118
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(path)


# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------

def main():
    os.makedirs(FIG, exist_ok=True)
    os.makedirs("outputs", exist_ok=True)

    if not os.path.exists("data/funding_panel.csv.gz"):
        print("no data found, generating...")
        make_dataset.build()

    funding, depth = load_panel()
    marks = load_marks()
    panel = to_common_8h_grid(funding)

    cal_end = panel.ts.min() + pd.Timedelta(days=CAL_DAYS)
    cal, test = panel[panel.ts < cal_end], panel[panel.ts >= cal_end]
    marks_test = marks[marks.ts >= cal_end]

    print(f"calibration {panel.ts.min():%Y-%m-%d} to {cal_end:%Y-%m-%d}, "
          f"test {cal_end:%Y-%m-%d} to {panel.ts.max():%Y-%m-%d}")

    # --- decay measured on the calibration window only ---------------------
    agg = spread_decay(cal, max_lag=24)
    dec = decay_factors(agg)
    cc = cumulative_carry(agg)

    costs_t = cost_table(depth, "taker")
    costs_m = cost_table(depth, "maker")
    med_rt_t = float(2 * (costs_t.fixed_cost_bps.median() * 2))
    med_rt_m = float(2 * (costs_m.fixed_cost_bps.median() * 2))

    opp_t = build_opportunities(test, costs_t, "taker", "ewma", decay=dec)
    opp_m = build_opportunities(test, costs_m, "maker", "ewma", decay=dec)

    # --- base case backtests ------------------------------------------------
    tr_t, eq_t = run(opp_t, test, marks_test)
    tr_m, eq_m = run(opp_m, test, marks_test)
    s_t, s_m = summarise(tr_t, eq_t), summarise(tr_m, eq_m)
    print(f"taker: {s_t['trades']} trades, "
          f"{s_t['ann_return_on_notional_pct']}% p.a. on notional, SR {s_t['sharpe']}")
    print(f"maker: {s_m['trades']} trades, "
          f"{s_m['ann_return_on_notional_pct']}% p.a. on notional, SR {s_m['sharpe']}")

    # --- sensitivities ------------------------------------------------------
    lev_rows = []
    for L in (2.0, 3.0, 5.0, 10.0):
        tr, eq = run(opp_m, test, marks_test, leverage=L)
        s = summarise(tr, eq)
        lev_rows.append({"leverage": L, "liq_move_pct": round(liq_move(L) * 100, 1),
                         **s})
    lev_df = pd.DataFrame(lev_rows)

    thr_rows = []
    for thr in (0.02, 0.05, 0.10, 0.20, 0.35):
        o = opp_m.copy()
        o["tradeable"] = o.net_carry_ann >= thr
        tr, eq = run(o, test, marks_test)
        thr_rows.append({"min_net_carry_ann": thr, **summarise(tr, eq)})
    thr_df = pd.DataFrame(thr_rows)

    sig_rows = []
    for rank in ("spot", "ewma"):
        for ex, ct in (("taker", costs_t), ("maker", costs_m)):
            o = build_opportunities(test, ct, ex, rank, decay=dec)
            tr, eq = run(o, test, marks_test)
            sig_rows.append({"rank_by": rank, "execution": ex,
                             **summarise(tr, eq)})
    sig_df = pd.DataFrame(sig_rows)

    # --- robustness across independent paths --------------------------------
    rob_rows = []
    tmp = "data/_paths"
    os.makedirs(tmp, exist_ok=True)
    for seed in range(1, 9):
        make_dataset.build(outdir=tmp, seed=seed)
        f2, d2 = load_panel(tmp)
        m2 = load_marks(tmp)
        p2 = to_common_8h_grid(f2)
        ce = p2.ts.min() + pd.Timedelta(days=CAL_DAYS)
        d_ = decay_factors(spread_decay(p2[p2.ts < ce], max_lag=24))
        t2, mm2 = p2[p2.ts >= ce], m2[m2.ts >= ce]
        for ex in ("taker", "maker"):
            o = build_opportunities(t2, cost_table(d2, ex), ex, "ewma", decay=d_)
            tr, eq = run(o, t2, mm2)
            rob_rows.append({"path": seed, "execution": ex, **summarise(tr, eq)})
    rob = pd.DataFrame(rob_rows)
    make_dataset.build(seed=cfg.SEED)      # restore the headline dataset

    # --- figures ------------------------------------------------------------
    fig_frequency(funding, panel)
    fig_dispersion(panel)
    fig_decay(agg, cc, med_rt_t, med_rt_m)
    fig_capacity(costs_t, opp_m)
    fig_equity(eq_m, tr_m, eq_t)
    fig_sensitivity(lev_df, thr_df)
    fig_robustness(rob)
    print(f"figures -> {FIG}")

    # --- tables for the workbook -------------------------------------------
    universe_df = pd.DataFrame([{
        "symbol": s.ticker, "tier": s.tier, "tier_label": cfg.TIER_LABEL[s.tier],
        "venues": ", ".join(s.listed_on), "n_venues": len(s.listed_on),
        "depth_multiplier_vs_tier1": s.depth_mult,
        "funding_vol_multiplier": s.funding_vol_mult,
    } for s in cfg.UNIVERSE])

    spec_df = pd.DataFrame([{
        "exchange": e.name, "funding_interval_hours": e.funding_hours,
        "settlements_per_year": cfg.settlements_per_year(e.name),
        "taker_fee_bps": e.taker_fee_bps, "maker_fee_bps": e.maker_fee_bps,
        "funding_cap_per_settlement": e.funding_cap,
        "typical_spread_bps_tier1": e.typical_spread_bps,
        "depth_within_1bp_usd_tier1": e.depth_1bp_usd,
    } for e in cfg.EXCHANGES.values()])

    last_ts = panel.ts.max()
    snap = (panel[panel.ts == last_ts]
            .pivot_table(index="symbol", columns="exchange", values="rate_8h")
            .reset_index())
    snap["tier"] = snap.symbol.map(lambda s: cfg.SYMBOLS[s].tier)
    for ex in cfg.EXCHANGES:
        if ex not in snap.columns:
            snap[ex] = np.nan
        snap[f"{ex}_ann_pct"] = np.nan
    snap = snap[["symbol", "tier"] + list(cfg.EXCHANGES)
                + [f"{e}_ann_pct" for e in cfg.EXCHANGES]]

    decay_tbl = agg.rename(columns={"lag": "intervals_after_entry",
                                    "spread_bps": "mean_spread_bps"})
    cc_out = cc.copy()
    cc_out["taker_round_trip_bps"] = med_rt_t
    cc_out["maker_round_trip_bps"] = med_rt_m
    cc_out["net_vs_taker_bps"] = np.nan
    cc_out["net_vs_maker_bps"] = np.nan

    trades = pd.concat([tr_t.assign(execution="taker"),
                        tr_m.assign(execution="maker")], ignore_index=True)
    summaries = pd.DataFrame([{"execution": "taker", **s_t},
                              {"execution": "maker", **s_m}])

    notes = [
        "Caerus Global Management — 2026 Summer Analyst Programme, Week 2.",
        "Cross-exchange funding rate arbitrage: 36 perpetual futures across "
        "Binance, Bybit, OKX and Hyperliquid.",
        "",
        "DATA PROVENANCE. The machine this was built on has no outbound network "
        "access, so the numbers in every sheet come from src/make_dataset.py, a "
        "simulator, and not from the live venue APIs. src/fetch_live.py contains "
        "the real REST calls and writes the identical schema; running "
        "`python -m src.fetch_live` and then `python -m src.run_all` regenerates "
        "this whole workbook from live data with no other changes. The structure "
        "of the results (which tiers work, why taker execution fails, how fast "
        "the spread decays) is a property of the cost arithmetic and should hold; "
        "the exact figures are not live observations and should not be quoted as "
        "such.",
        "",
        "METHOD IN ONE PARAGRAPH. Every venue's funding rate is put on the same "
        "00/08/16 UTC grid — Hyperliquid settles hourly, so its eight hourly "
        "payments are summed into each 8h bucket. For each symbol at each stamp "
        "the widest long/short venue pair is selected on a 3-day trailing EWMA of "
        "the rate (not the spot rate, which is mostly noise). Expected carry is "
        "the entry spread shrunk by a measured decay profile, and it is compared "
        "against a full round trip: fees plus half-spread plus book-walking "
        "impact, on both legs, in and out. The decay profile is fitted on the "
        "first 30 days and the backtest runs on the remaining 60.",
        "",
        "SHEETS.",
        "Universe / Exchange specs — what is covered and the fee and interval "
        "assumptions behind every cost number.",
        "Funding snapshot — 8h-equivalent rates at the last stamp. The annualised "
        "columns are live formulas (rate x 1095 x 100), so pasting your own rates "
        "over the 8h columns updates them.",
        "Opportunity screen — every symbol/stamp in the test window with its best "
        "pair, expected carry, round-trip cost and capacity.",
        "Spread decay / Breakeven — how much of the entry spread survives, and how "
        "many intervals it takes to clear the round trip. The net columns are "
        "formulas so you can substitute your own fee tier.",
        "Trade log / Backtest summary — every position, and the headline stats.",
        "Sensitivity leverage / threshold / signal — the three choices the result "
        "is most exposed to.",
        "Robustness paths — the same pipeline on eight independent simulated "
        "paths. The spread of these is a better guide to the uncertainty than the "
        "single headline number.",
        "",
        "KEY ASSUMPTIONS, all set in src/config.py.",
        f"Base-tier (VIP 0) fees. Impact budget {cfg.MAX_IMPACT_BPS} bps caps leg size. "
        f"Maker execution charged a {cfg.MAKER_SLIPPAGE_BPS} bp haircut on top of the "
        "maker fee for queueing and partial fills — this is a judgement, not "
        "something I measured.",
        f"Isolated margin at {cfg.LEVERAGE:.0f}x per leg, {cfg.MAINT_MARGIN*100:.1f}% "
        f"maintenance, {cfg.LIQ_FEE_BPS:.0f} bp liquidation clearance fee, surviving "
        f"leg unwound {cfg.LIQ_UNWIND_DELAY_H}h after the liquidation print.",
        "No margin transfer between venues mid-trade. This is conservative and is "
        "the assumption most worth revisiting.",
    ]

    out = "outputs/funding_arb_results.xlsx"
    write_excel(out, universe_df, spec_df, snap, opp_m, decay_tbl, cc_out,
                trades, summaries, lev_df, thr_df, sig_df, rob, notes)
    print(f"workbook -> {out}")

    # --- plain text summary for writing the report -------------------------
    with open("outputs/summary.txt", "w") as fh:
        fh.write("BASE CASE\n")
        for name, s in (("taker", s_t), ("maker", s_m)):
            fh.write(f"\n[{name}]\n")
            for k, v in s.items():
                fh.write(f"  {k:32s} {v}\n")
        fh.write("\nDECAY FACTORS (cumulative multiple of entry spread)\n")
        for t in (1, 2, 3):
            fh.write(f"  tier {t}: half-life {half_life(agg, t)} intervals, "
                     f"H=21 factor {dec[(t,21)]:.1f}\n")
        fh.write(f"\nmedian round trip: taker {med_rt_t:.1f} bps, "
                 f"maker {med_rt_m:.1f} bps\n")
        fh.write("\nLEVERAGE\n" + lev_df[["leverage", "liq_move_pct", "trades",
                 "ann_return_on_capital_pct", "sharpe",
                 "liquidation_rate_pct", "max_drawdown_usd"]].to_string(index=False))
        fh.write("\n\nTHRESHOLD\n" + thr_df[["min_net_carry_ann", "trades",
                 "ann_return_on_notional_pct", "sharpe",
                 "hit_rate_pct"]].to_string(index=False))
        fh.write("\n\nSIGNAL\n" + sig_df[["rank_by", "execution", "trades",
                 "ann_return_on_notional_pct", "sharpe", "avg_net_bps",
                 "avg_hold_days"]].to_string(index=False))
        fh.write("\n\nROBUSTNESS\n" + rob[["path", "execution", "trades",
                 "ann_return_on_notional_pct", "sharpe",
                 "liquidation_rate_pct"]].to_string(index=False))
        fh.write("\n\nBY TIER (maker trades)\n")
        if len(tr_m):
            fh.write(tr_m.groupby("tier").agg(
                n=("net_pnl", "size"), net_usd=("net_pnl", "sum"),
                avg_bps=("net_bps", "mean"),
                liq=("liquidated", "mean")).round(2).to_string())
        fh.write("\n\nOPPORTUNITY SCREEN, share tradeable by tier\n")
        for nm, o in (("taker", opp_t), ("maker", opp_m)):
            fh.write(f"  {nm}: " + str(o.groupby("tier").tradeable.mean()
                                       .round(3).to_dict()) + "\n")
    print("summary -> outputs/summary.txt")


if __name__ == "__main__":
    main()
