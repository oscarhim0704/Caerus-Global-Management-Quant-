"""
Builds a stand-in 90-day dataset with the same schema fetch_live.py produces.

Why this exists: the machine I built the project on has no outbound network, so
I could not pull the real venue histories. Rather than fake a few numbers into
the report I wrote a generator whose structure matches what funding data
actually looks like, and I have been explicit everywhere that the results come
from it. See README for the one command that swaps in live data.

The generator is not just noise -- the design matters for whether the strategy
looks real, so the three pieces are:

  1. A market-wide funding level per symbol. All venues on a symbol move
     together most of the time, because they are all pricing the same
     perp-vs-spot basis.
  2. A PERSISTENT per-venue offset. This is the part that is actually tradeable:
     some venues sit structurally above or below the others for days at a time
     (different index composition, different OI skew, different retail mix).
     Half-life ~10 days.
  3. A FAST per-venue wobble. Half-life ~8 hours. This is the part that looks
     like an opportunity on a single snapshot and is gone by the time you have
     paid to get in.

If (3) did not exist the strategy would be trivially profitable, and if (2) did
not exist it would be impossible. Both exist in real data, which is why the
entry signal matters -- see screen.py.
"""

import numpy as np
import pandas as pd

from src.config import EXCHANGES, UNIVERSE, DAYS, SEED

RNG = np.random.default_rng(SEED)

# --- how wide the per-venue offsets are, by tier -----------------------------
# Calibrated so that median cross-venue annualised spread comes out around
# 9% on majors and 50% on small caps, which is roughly what the public
# funding dashboards show.
TIER_SPREAD_MULT = {1: 1.0, 2: 3.4, 3: 6.3}
BASE_PERSIST_SD = 0.000019     # 8h-equivalent, per venue
BASE_FAST_SD = 0.000020

# --- price process -----------------------------------------------------------
TIER_ANN_VOL = {1: 0.55, 2: 0.80, 3: 1.10}
START_PRICE = {1: 60000.0, 2: 12.0, 3: 3.5}


def ar1_phi(half_life_hours):
    """AR(1) coefficient for a given half-life, on an hourly step."""
    return 0.5 ** (1.0 / half_life_hours)


def ar1_path(n, phi, sd, rng):
    """Zero-mean AR(1) path whose *stationary* sd is `sd`."""
    innov_sd = sd * np.sqrt(1 - phi ** 2)
    x = np.empty(n)
    x[0] = rng.normal(0, sd)
    e = rng.normal(0, innov_sd, n)
    for i in range(1, n):
        x[i] = phi * x[i - 1] + e[i]
    return x


def basis_jumps(n, rate_per_day, mean_bps, half_life_h, rng):
    """
    Occasional dislocations in a venue's basis, decaying away over a few hours.

    This is the single most important risk in the trade and a plain AR(1) does
    not produce it. When one venue's book gets cleared out, or its oracle lags,
    or the funding cap binds, the two legs stop being a hedge for a while. My
    first version left this out and the backtest came back with a Sharpe near 9,
    which is not a number any carry desk reports.
    """
    n_jumps = rng.poisson(rate_per_day * n / 24.0)
    out = np.zeros(n)
    if n_jumps == 0:
        return out
    phi = 0.5 ** (1.0 / half_life_h)
    for _ in range(n_jumps):
        i = rng.integers(0, n)
        size = rng.exponential(mean_bps) * rng.choice([-1.0, 1.0])
        k = np.arange(n - i)
        out[i:] += size * phi ** k
    return out


def t_returns(n, sd, df, rng):
    """Student-t innovations scaled to the target sd, so tails are fat."""
    z = rng.standard_t(df, n)
    return z / np.sqrt(df / (df - 2.0)) * sd


def stress_regime(n_hours, rng, n_episodes=3):
    """
    A multiplier series shared by EVERY symbol and venue.

    Without this, each symbol's basis and each venue's dislocations are
    independent, six positions diversify almost perfectly, and the backtest
    reports a Sharpe no carry desk has ever achieved. In reality the bad days
    are the same day everywhere: everything gaps, every book thins out, and
    every leg of every pair is dislocated at once. That correlation is what
    actually caps the size of this trade.
    """
    mult = np.ones(n_hours)
    for _ in range(n_episodes):
        start = rng.integers(24, n_hours - 48)
        length = int(rng.integers(8, 30))
        peak = rng.uniform(2.5, 4.5)
        ramp = np.concatenate([
            np.linspace(1.0, peak, max(2, length // 3)),
            np.linspace(peak, 1.0, length - max(2, length // 3)),
        ])
        mult[start:start + len(ramp)] = np.maximum(
            mult[start:start + len(ramp)], ramp)
    return mult


def build(outdir="data", seed=None):
    global RNG
    if seed is not None:
        RNG = np.random.default_rng(seed)
    n_hours = DAYS * 24
    ts_hourly = pd.date_range("2026-05-01", periods=n_hours, freq="h")
    stress = stress_regime(n_hours, RNG)

    funding_rows, mark_rows, depth_rows = [], [], []

    phi_mkt = ar1_phi(72)        # market funding level, 3-day half-life
    phi_slow = ar1_phi(240)      # persistent venue offset, 10-day half-life
    phi_fast = ar1_phi(8)        # fast wobble, 8-hour half-life
    phi_basis = ar1_phi(4)       # venue mark basis, 4-hour half-life

    for sym in UNIVERSE:
        tier = sym.tier

        # ---- 1. market-wide funding for this symbol (8h-equivalent) --------
        mu = RNG.normal(0.00009, 0.00005)          # long-run mean, usually +ve
        mkt = mu + ar1_path(n_hours, phi_mkt,
                            0.00006 * sym.funding_vol_mult, RNG)

        # ---- 2. the underlying price path ---------------------------------
        ann_vol = TIER_ANN_VOL[tier]
        hourly_vol = ann_vol / np.sqrt(365 * 24)
        drift = RNG.normal(0.0, 0.4) / (365 * 24)
        shocks = (drift - 0.5 * hourly_vol ** 2
                  + t_returns(n_hours, hourly_vol, 4, RNG) * stress)
        price = START_PRICE[tier] * np.exp(np.cumsum(shocks))

        spread_mult = TIER_SPREAD_MULT[tier]

        for ex_name in sym.listed_on:
            ex = EXCHANGES[ex_name]
            liq_scale = 1.0 / np.sqrt(ex.liquidity_factor)

            persist = ar1_path(n_hours, phi_slow,
                               BASE_PERSIST_SD * spread_mult * liq_scale, RNG)
            fast = ar1_path(n_hours, phi_fast,
                            BASE_FAST_SD * spread_mult * liq_scale, RNG)
            eq8h = mkt + persist + fast

            # ---- 3. write the rate at this venue's own settlement times ----
            if ex.funding_hours == 8:
                mask = np.isin(ts_hourly.hour, [0 + ex.settle_offset_h,
                                                8 + ex.settle_offset_h,
                                                16 + ex.settle_offset_h])
                rate = np.clip(eq8h[mask], -ex.funding_cap, ex.funding_cap)
                stamps = ts_hourly[mask]
            else:
                # Hourly venue: one eighth of the 8h-equivalent, capped hourly.
                rate = np.clip(eq8h / 8.0, -ex.funding_cap, ex.funding_cap)
                stamps = ts_hourly

            funding_rows.append(pd.DataFrame({
                "ts": stamps,
                "exchange": ex_name,
                "symbol": sym.ticker,
                "funding_rate": rate,
                "interval_hours": ex.funding_hours,
            }))

            # ---- 4. venue mark = common price * (1 + small basis) ----------
            tier_mult = 1.0 if tier == 1 else 1.6 if tier == 2 else 2.4
            basis_sd_bps = 2.5 * liq_scale * tier_mult
            # Both the steady wobble and the jumps are amplified in stress.
            basis_bps = (ar1_path(n_hours, phi_basis, basis_sd_bps, RNG)
                         + basis_jumps(n_hours,
                                       rate_per_day=0.10,
                                       mean_bps=18.0 * liq_scale * tier_mult,
                                       half_life_h=6.0,
                                       rng=RNG)) * stress
            mark_rows.append(pd.DataFrame({
                "ts": ts_hourly,
                "exchange": ex_name,
                "symbol": sym.ticker,
                "mark_price": price * (1 + basis_bps / 1e4),
            }))

            # ---- 5. static liquidity snapshot ------------------------------
            depth_rows.append({
                "exchange": ex_name,
                "symbol": sym.ticker,
                "depth_1bp_usd": ex.depth_1bp_usd * sym.depth_mult,
                "spread_bps": ex.typical_spread_bps * (1.0 if tier == 1 else
                                                       2.0 if tier == 2 else 4.5),
            })

    funding = pd.concat(funding_rows, ignore_index=True)
    marks = pd.concat(mark_rows, ignore_index=True)
    depth = pd.DataFrame(depth_rows)

    funding.to_csv(f"{outdir}/funding_panel.csv.gz", index=False)
    marks.to_csv(f"{outdir}/marks.csv.gz", index=False)
    depth.to_csv(f"{outdir}/depth.csv.gz", index=False)

    print(f"funding rows : {len(funding):,}")
    print(f"mark rows    : {len(marks):,}")
    print(f"symbols      : {funding.symbol.nunique()}   "
          f"venues: {funding.exchange.nunique()}")
    print(f"window       : {funding.ts.min()} -> {funding.ts.max()}")
    return funding, marks, depth


if __name__ == "__main__":
    build()
