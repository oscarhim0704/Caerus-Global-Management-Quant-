"""
Turns the raw funding panel into a table of tradeable opportunities.

Three jobs:
  1. Put every venue on the same clock (frequency normalisation).
  2. Attach a cost and a capacity number to every venue/symbol.
  3. For each symbol at each 8h stamp, work out the best long/short venue pair
     and whether the carry actually clears the round trip.

The one thing worth reading carefully is `to_common_8h_grid`. Hyperliquid pays
hourly and everyone else pays every 8 hours, and you cannot put 0.0001 next to
0.0000125 and call one bigger than the other.
"""

import numpy as np
import pandas as pd

from src.config import (EXCHANGES, SYMBOLS, TICKERS, MAX_IMPACT_BPS,
                        MAKER_SLIPPAGE_BPS, MIN_NET_CARRY_ANN)

# 8h settlements per year. Every rate in this module is expressed as an
# 8h-equivalent decimal, so this is the only annualisation constant used.
PER_YEAR_8H = 365 * 3


# ----------------------------------------------------------------------------
# loading
# ----------------------------------------------------------------------------

def load_panel(datadir="data"):
    funding = pd.read_csv(f"{datadir}/funding_panel.csv.gz", parse_dates=["ts"])
    depth = pd.read_csv(f"{datadir}/depth.csv.gz")
    return funding, depth


def load_marks(datadir="data"):
    return pd.read_csv(f"{datadir}/marks.csv.gz", parse_dates=["ts"])


# ----------------------------------------------------------------------------
# 1. frequency normalisation
# ----------------------------------------------------------------------------

def to_common_8h_grid(funding):
    """
    Collapse every venue onto the 00/08/16 UTC settlement grid.

    An 8h venue contributes its own rate. Hyperliquid contributes the SUM of the
    eight hourly payments that land in the bucket (t-8h, t], because that is what
    a position actually pays or receives over those eight hours. Summing is right
    and averaging is wrong -- you are settled eight separate times.

    Returns a long frame: symbol, ts, exchange, rate_8h.
    """
    out = []

    eight = funding[funding.interval_hours == 8].copy()
    out.append(eight[["symbol", "ts", "exchange", "funding_rate"]]
               .rename(columns={"funding_rate": "rate_8h"}))

    hourly = funding[funding.interval_hours == 1].copy()
    if len(hourly):
        # Bucket label = the 8h settlement at or after each hourly payment, so a
        # payment at 03:00 belongs to the bucket stamped 08:00.
        hourly["bucket"] = hourly["ts"].dt.ceil("8h")
        # A payment landing exactly on a boundary belongs to that boundary.
        grp = (hourly.groupby(["symbol", "exchange", "bucket"], as_index=False)
                     .agg(rate_8h=("funding_rate", "sum"),
                          n_pay=("funding_rate", "size")))
        # Drop part-filled buckets at the edges of the sample.
        grp = grp[grp.n_pay == 8]
        out.append(grp.rename(columns={"bucket": "ts"})[
            ["symbol", "ts", "exchange", "rate_8h"]])

    long = pd.concat(out, ignore_index=True)
    return long.sort_values(["symbol", "ts", "exchange"]).reset_index(drop=True)


def to_wide(long_panel):
    """symbol x ts rows, one column per exchange."""
    return long_panel.pivot_table(index=["symbol", "ts"],
                                  columns="exchange", values="rate_8h")


def add_ewma_signal(long_panel, span=9):
    """
    Trailing EWMA of each venue's 8h rate. span=9 is three days.

    This is shifted by one so the value at time t only uses settlements strictly
    before t. Ranking on the *spot* spread means ranking partly on the fast
    wobble, which is gone by the time the trade is on.
    """
    p = long_panel.sort_values(["symbol", "exchange", "ts"]).copy()
    p["rate_ewma"] = (p.groupby(["symbol", "exchange"])["rate_8h"]
                       .transform(lambda s: s.shift(1).ewm(span=span, min_periods=3).mean()))
    return p


# ----------------------------------------------------------------------------
# 2. costs and capacity
# ----------------------------------------------------------------------------

def cost_table(depth, execution="taker"):
    """
    Per venue/symbol: one-way cost in bps, and the biggest leg we can put on.

    Slippage from walking the book is modelled as impact_bps = 0.5 * Q / D1bp,
    i.e. the book is locally flat with D1bp of notional per basis point, and the
    average fill sits halfway down the walk. Inverting that at the impact budget
    gives the size cap.
    """
    rows = []
    for r in depth.itertuples():
        ex = EXCHANGES[r.exchange]
        max_notional = 2.0 * MAX_IMPACT_BPS * r.depth_1bp_usd

        if execution == "taker":
            fixed = ex.taker_fee_bps + 0.5 * r.spread_bps
        elif execution == "maker":
            # Post at the touch: no spread paid, but charge a slippage haircut
            # for queue position and partial fills.
            fixed = ex.maker_fee_bps + MAKER_SLIPPAGE_BPS
        else:
            raise ValueError(execution)

        rows.append({
            "exchange": r.exchange,
            "symbol": r.symbol,
            "depth_1bp_usd": r.depth_1bp_usd,
            "spread_bps": r.spread_bps,
            "fixed_cost_bps": fixed,
            "max_notional_usd": max_notional,
        })
    return pd.DataFrame(rows)


def impact_bps(notional, depth_1bp_usd):
    return 0.5 * notional / depth_1bp_usd


def leg_cost_bps(notional, fixed_cost_bps, depth_1bp_usd, execution="taker"):
    """One crossing of one leg, in bps of that leg's notional."""
    if execution == "maker":
        return fixed_cost_bps          # passive: assume no book walking
    return fixed_cost_bps + impact_bps(notional, depth_1bp_usd)


# ----------------------------------------------------------------------------
# 3. opportunity construction
# ----------------------------------------------------------------------------

def build_opportunities(long_panel, costs, execution="taker",
                        rank_by="ewma", ref_notional=150_000.0, decay=None):
    """
    For every (symbol, ts): the best long/short venue pair and its economics.

    Sign convention. Funding > 0 means longs pay shorts. So we want to be SHORT
    where the rate is high and LONG where it is low, and the carry we collect per
    8h interval is  rate_short - rate_long.

    `rank_by` picks which rate we choose the pair on:
        "spot"  -- the last printed rate (noisy)
        "ewma"  -- 3-day trailing EWMA (persistent part only)
    Either way the columns describing the *current* state are the spot rates,
    and nothing here looks forward.
    """
    p = add_ewma_signal(long_panel)
    key = "rate_ewma" if rank_by == "ewma" else "rate_8h"
    p = p.dropna(subset=[key])

    cost_map = costs.set_index(["exchange", "symbol"])
    rows = []

    for (sym, ts), g in p.groupby(["symbol", "ts"], sort=False):
        if len(g) < 2:
            continue
        g = g.set_index("exchange")
        hi = g[key].idxmax()      # short here
        lo = g[key].idxmin()      # long here
        if hi == lo:
            continue

        try:
            c_hi = cost_map.loc[(hi, sym)]
            c_lo = cost_map.loc[(lo, sym)]
        except KeyError:
            continue

        cap = float(min(c_hi.max_notional_usd, c_lo.max_notional_usd))
        notional = min(ref_notional, cap)

        cost_in = (leg_cost_bps(notional, c_hi.fixed_cost_bps,
                                c_hi.depth_1bp_usd, execution)
                   + leg_cost_bps(notional, c_lo.fixed_cost_bps,
                                  c_lo.depth_1bp_usd, execution))
        round_trip_bps = 2.0 * cost_in          # in and out

        carry_spot = float(g.loc[hi, "rate_8h"] - g.loc[lo, "rate_8h"])
        carry_sig = float(g.loc[hi, key] - g.loc[lo, key])
        carry_bps = carry_sig * 1e4

        rows.append({
            "symbol": sym,
            "ts": ts,
            "tier": SYMBOLS[sym].tier,
            "long_venue": lo,
            "short_venue": hi,
            "rate_long_8h": float(g.loc[lo, "rate_8h"]),
            "rate_short_8h": float(g.loc[hi, "rate_8h"]),
            "carry_spot_8h": carry_spot,
            "carry_signal_8h": carry_sig,
            "carry_ann": carry_sig * PER_YEAR_8H,
            "round_trip_bps": round_trip_bps,
            "breakeven_intervals": (round_trip_bps / carry_bps
                                    if carry_bps > 1e-9 else np.inf),
            "capacity_usd": cap,
            "notional_usd": notional,
        })

    opp = pd.DataFrame(rows)
    if len(opp):
        hold = 21   # 7 days, roughly the hold the backtest ends up using

        # Naive view: assume the entry spread just sits there for the whole hold.
        # This is what a screen built straight off a funding dashboard tells you,
        # and it is too optimistic.
        opp["net_carry_naive_ann"] = (
            (opp.carry_signal_8h * hold - opp.round_trip_bps / 1e4)
            / hold * PER_YEAR_8H)

        # Decay-adjusted view: shrink the expected carry using the measured
        # survival profile for that tier.
        if decay is None:
            factor = pd.Series(hold, index=opp.index)     # falls back to naive
        else:
            factor = opp.tier.map(lambda t: decay.get((t, hold), hold))
        opp["expected_carry_bps"] = opp.carry_signal_8h * 1e4 * factor
        opp["net_pnl_bps"] = opp.expected_carry_bps - opp.round_trip_bps
        opp["net_carry_ann"] = opp.net_pnl_bps / 1e4 / hold * PER_YEAR_8H
        opp["tradeable"] = opp.net_carry_ann >= MIN_NET_CARRY_ANN
    return opp.sort_values(["ts", "carry_ann"], ascending=[True, False]) \
              .reset_index(drop=True)


def decay_factors(agg, horizons=(1, 3, 6, 9, 12, 15, 18, 21, 24)):
    """
    {(tier, H): sum of ratio_to_entry over lags 1..H}

    Multiply an entry spread by this to get the cumulative carry you should
    actually expect over an H-interval hold. For tier 1 the factor is far below
    H, which is the whole reason the majors do not work.
    """
    out = {}
    for tier, g in agg.groupby("tier"):
        g = g.sort_values("lag").set_index("lag")["ratio_to_entry"]
        for H in horizons:
            out[(tier, H)] = float(g.loc[1:H].sum())
    return out


# ----------------------------------------------------------------------------
# 4. how long does an observed spread survive?
# ----------------------------------------------------------------------------

def spread_decay(long_panel, max_lag=24):
    """
    Take the best pair at time t, then measure what that SAME pair's spread is
    k intervals later. This is the number that decides whether the trade works:
    the entry spread is not what you collect, the average over the hold is.

    Returns a frame of tier, lag, mean_spread_bps, and the ratio to lag 0.
    """
    wide = to_wide(long_panel)
    out = []
    for sym, g in wide.groupby(level="symbol"):
        g = g.droplevel("symbol").sort_index()
        arr = g.to_numpy()
        cols = list(g.columns)
        valid = ~np.isnan(arr)
        n = len(g)
        for i in range(n - max_lag):
            row = arr[i]
            if valid[i].sum() < 2:
                continue
            hi = int(np.nanargmax(row))
            lo = int(np.nanargmin(row))
            if hi == lo:
                continue
            fut = arr[i:i + max_lag + 1, hi] - arr[i:i + max_lag + 1, lo]
            for k, v in enumerate(fut):
                if not np.isnan(v):
                    out.append((SYMBOLS[sym].tier, k, v * 1e4))

    d = pd.DataFrame(out, columns=["tier", "lag", "spread_bps"])
    agg = d.groupby(["tier", "lag"], as_index=False)["spread_bps"].mean()
    base = agg[agg.lag == 0].set_index("tier")["spread_bps"]
    agg["ratio_to_entry"] = agg.apply(
        lambda r: r.spread_bps / base[r.tier], axis=1)
    return agg


def half_life(agg, tier):
    """First lag at which the mean spread for a tier has halved."""
    g = agg[agg.tier == tier].sort_values("lag")
    below = g[g.ratio_to_entry <= 0.5]
    if len(below) == 0:
        return np.nan
    return float(below.iloc[0]["lag"])


def cumulative_carry(agg, max_lag=24):
    """
    Cumulative bps collected by holding k intervals, per tier. This is what gets
    compared against the round-trip cost to find the real break-even.
    """
    rows = []
    for tier, g in agg.groupby("tier"):
        g = g.sort_values("lag")
        # lag 0 is the entry snapshot; carry starts accruing from lag 1.
        cum = g[g.lag >= 1]["spread_bps"].cumsum().to_numpy()
        for k, v in enumerate(cum, start=1):
            rows.append({"tier": tier, "hold_intervals": k, "cum_carry_bps": v})
    return pd.DataFrame(rows)
