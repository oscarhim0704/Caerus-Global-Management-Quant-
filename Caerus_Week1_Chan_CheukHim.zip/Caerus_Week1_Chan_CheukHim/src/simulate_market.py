"""
Offline orderbook simulator for BTC/USDT perpetuals on Binance and Hyperliquid.

IMPORTANT CONTEXT: this sandbox's outbound network is locked down to a small
package-registry allowlist, so the live collectors in collect_binance.py and
collect_hyperliquid.py can't actually reach either exchange from here (both
return connection errors, not auth errors, I checked). Those two scripts
are written to run as-is on a machine with normal internet access, which is
what I'd use for a real capture. To still be able to do the analysis and
backtest this week, this script produces a synthetic but parameter-calibrated
top-10-level orderbook panel for both venues that reproduces the stylised
facts we'd expect to see live:
  - a shared underlying BTC price path (GBM + occasional jumps)
  - Binance leading Hyperliquid by a short, noisy lag (Binance is the deeper,
    more liquid venue for BTC perps, so this is the expected direction)
  - realistic tick sizes, spreads and depth decay across levels
  - short bursts of order-book imbalance that lead price by a few seconds,
    which is exactly the kind of pattern task 2 asks us to look for

Everything downstream (features.py, backtest.py) is written generically
against that same column layout, so if/when this runs against a real capture the
rest of the pipeline doesn't change.
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

RNG_SEED = 42

BINANCE_TICK = 0.1       # USDT
HYPERLIQUID_TICK = 1.0   # USD, HL BTC-PERP quotes in whole dollars
N_LEVELS = 10


def simulate_mid_price(n_seconds: int, rng: np.random.Generator, s0: float = 63000.0) -> np.ndarray:
    """Shared 'true' BTC price path: GBM drift/vol plus Poisson jumps."""
    dt = 1.0 / (24 * 3600)  # 1 second, in "days" for an annualised vol figure
    mu = 0.0
    sigma = 0.55  # roughly BTC's realised annualised vol
    z = rng.standard_normal(n_seconds)
    log_ret = (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * z

    # occasional jumps (news, liquidations), Poisson arrivals at ~6/day
    jump_prob = 6 / (24 * 3600)
    jump_mask = rng.random(n_seconds) < jump_prob
    jump_size = rng.normal(0, 0.0012, n_seconds) * jump_mask

    log_ret = log_ret + jump_size
    log_price = np.log(s0) + np.cumsum(log_ret)
    return np.exp(log_price)


def make_book_side(mid: float, tick: float, base_size: float, rng: np.random.Generator,
                    imbalance: float, side: int):
    """
    Build one side (bid or ask) of a 10-level book around `mid`.
    imbalance in [-1, 1]: positive means more resting size on the bid side.
    side: +1 for bid (levels sit below mid), -1 for ask (levels sit above mid).
    Level 0 is always the best (closest-to-mid) level.
    """
    half_spread_ticks = rng.integers(1, 4)  # 1-3 ticks off mid at best level
    prices = np.empty(N_LEVELS)
    sizes = np.empty(N_LEVELS)
    for i in range(N_LEVELS):
        prices[i] = mid - side * (half_spread_ticks + i) * tick
        depth_decay = 1.0 + 0.35 * i  # deeper levels carry more size on average
        size_mult = (1 + imbalance * side * 0.5)
        noise = np.exp(rng.normal(0, 0.35))
        sizes[i] = max(0.001, base_size * depth_decay * size_mult * noise)
    return prices, sizes


def simulate_venue(n_seconds: int, base_mid: np.ndarray, rng: np.random.Generator,
                    tick: float, base_size: float, lag_seconds: int, noise_bps: float,
                    imbalance_persistence: float) -> pd.DataFrame:
    """
    Build a top-10 book panel for one venue from the shared base mid path.
    lag_seconds: how many seconds this venue's price trails the base path
    (used to give Hyperliquid a small lag behind Binance).
    """
    n = n_seconds
    lagged_mid = np.empty(n)
    if lag_seconds > 0:
        lagged_mid[:lag_seconds] = base_mid[0]
        lagged_mid[lag_seconds:] = base_mid[:-lag_seconds]
    else:
        lagged_mid = base_mid.copy()

    venue_noise = rng.normal(0, noise_bps / 10000.0, n)
    venue_mid = lagged_mid * (1 + venue_noise)
    venue_mid = np.round(venue_mid / tick) * tick

    # imbalance regime: an AR(1) process that occasionally spikes. This is
    # the "predictive signal" the notebook goes looking for in task 2
    imb = np.zeros(n)
    shock = rng.normal(0, 0.08, n)
    spike_prob = 1 / 90.0  # a fresh imbalance episode roughly every 90s on average
    spikes = rng.random(n) < spike_prob
    spike_size = rng.choice([-1, 1], n) * rng.uniform(0.4, 0.9, n) * spikes
    for t in range(1, n):
        imb[t] = imbalance_persistence * imb[t - 1] + shock[t] + spike_size[t]
    imb = np.clip(imb, -1, 1)

    rows = []
    for t in range(n):
        bid_px, bid_sz = make_book_side(venue_mid[t], tick, base_size, rng, imb[t], side=1)
        ask_px, ask_sz = make_book_side(venue_mid[t], tick, base_size, rng, imb[t], side=-1)
        row = {"ts": t, "mid_ref": venue_mid[t], "imbalance_true": imb[t]}
        for i in range(N_LEVELS):
            row[f"bid_px_{i}"] = bid_px[i]
            row[f"bid_sz_{i}"] = bid_sz[i]
            row[f"ask_px_{i}"] = ask_px[i]
            row[f"ask_sz_{i}"] = ask_sz[i]
        rows.append(row)

    df = pd.DataFrame(rows)
    return df


def run(hours: float, out_dir: str, start_ts: str):
    rng = np.random.default_rng(RNG_SEED)
    n_seconds = int(hours * 3600)
    base_mid = simulate_mid_price(n_seconds, rng)

    binance = simulate_venue(
        n_seconds, base_mid, rng,
        tick=BINANCE_TICK, base_size=8.5, lag_seconds=0,
        noise_bps=3.0, imbalance_persistence=0.85,
    )
    hyperliquid = simulate_venue(
        n_seconds, base_mid, rng,
        tick=HYPERLIQUID_TICK, base_size=3.2, lag_seconds=2,
        noise_bps=18.0, imbalance_persistence=0.80,
    )

    ts_index = pd.date_range(start=start_ts, periods=n_seconds, freq="1s", tz="UTC")
    binance["timestamp"] = ts_index
    hyperliquid["timestamp"] = ts_index

    # keep the ground-truth simulation columns aside for our own sanity checks --
    # a real capture wouldn't have these, and shipping them in the "raw" data
    # would leak the answer to the detection task
    binance_truth = binance[["timestamp", "mid_ref", "imbalance_true"]].copy()
    hl_truth = hyperliquid[["timestamp", "mid_ref", "imbalance_true"]].copy()
    binance = binance.drop(columns=["mid_ref", "imbalance_true", "ts"])
    hyperliquid = hyperliquid.drop(columns=["mid_ref", "imbalance_true", "ts"])

    # round to sensible precision before writing out. Prices are tick-aligned
    # anyway and sizes only matter to about 1e-3 BTC, so full float64 output
    # just bloats the CSV for no reason
    price_cols = [c for c in binance.columns if c.startswith(("bid_px", "ask_px"))]
    size_cols = [c for c in binance.columns if c.startswith(("bid_sz", "ask_sz"))]
    for df_ in (binance, hyperliquid):
        df_[price_cols] = df_[price_cols].round(2)
        df_[size_cols] = df_[size_cols].round(4)

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    binance.to_csv(out_path / "binance_btcusdt_perp_book.csv.gz", index=False, compression="gzip")
    hyperliquid.to_csv(out_path / "hyperliquid_btc_perp_book.csv.gz", index=False, compression="gzip")

    sim_dir = out_path / "_sim_truth"
    sim_dir.mkdir(exist_ok=True)
    binance_truth.to_csv(sim_dir / "binance_truth.csv.gz", index=False, compression="gzip")
    hl_truth.to_csv(sim_dir / "hyperliquid_truth.csv.gz", index=False, compression="gzip")

    print(f"binance rows: {len(binance)}, hyperliquid rows: {len(hyperliquid)}")
    print(f"wrote to {out_path}/")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--hours", type=float, default=60.0, help="length of the simulated capture window")
    p.add_argument("--out", default="data")
    p.add_argument("--start", default="2026-09-08 00:00:00")
    args = p.parse_args()
    run(args.hours, args.out, args.start)
