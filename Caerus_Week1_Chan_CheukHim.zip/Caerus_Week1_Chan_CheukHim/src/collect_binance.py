"""
Binance USDT-M perpetual orderbook collector.

Polls the top-10 depth snapshot for BTCUSDT perpetual futures on a fixed
interval and appends each snapshot to a local gzipped CSV file. Timestamps are
recorded at the moment the local machine receives the response (not the
exchange's internal book time), since that's the reference point that
actually matters for a latency-aware backtest later on.

Usage:
    python collect_binance.py --symbol BTCUSDT --minutes 60 --interval 0.5 --out data/binance_raw

Note: Binance's public REST depth endpoint is rate-limited (weight-based).
At 2 requests/sec this stays well under the limit for a single symbol.
For a "real" production collector you'd want the diff-depth websocket
stream instead of REST polling, but polling is simpler to reason about
and good enough to capture the top-of-book dynamics we care about here.
"""
import argparse
import time
import sys
from pathlib import Path

import pandas as pd
import requests

BASE_URL = "https://fapi.binance.com/fapi/v1/depth"


def fetch_snapshot(symbol: str, limit: int = 10) -> dict:
    resp = requests.get(BASE_URL, params={"symbol": symbol, "limit": limit}, timeout=5)
    resp.raise_for_status()
    return resp.json()


def snapshot_to_row(snap: dict, recv_ts: float) -> dict:
    row = {"ts": recv_ts, "exchange_ts": snap.get("E", None)}
    bids = snap["bids"]
    asks = snap["asks"]
    for i in range(10):
        if i < len(bids):
            row[f"bid_px_{i}"] = float(bids[i][0])
            row[f"bid_sz_{i}"] = float(bids[i][1])
        else:
            row[f"bid_px_{i}"] = None
            row[f"bid_sz_{i}"] = None
        if i < len(asks):
            row[f"ask_px_{i}"] = float(asks[i][0])
            row[f"ask_sz_{i}"] = float(asks[i][1])
        else:
            row[f"ask_px_{i}"] = None
            row[f"ask_sz_{i}"] = None
    return row


def run(symbol: str, minutes: float, interval: float, out_prefix: str):
    end_time = time.time() + minutes * 60
    rows = []
    n_errors = 0
    print(f"[binance] collecting {symbol} for {minutes} min, interval={interval}s")

    while time.time() < end_time:
        loop_start = time.time()
        try:
            snap = fetch_snapshot(symbol)
            recv_ts = time.time()
            rows.append(snapshot_to_row(snap, recv_ts))
        except Exception as e:
            n_errors += 1
            print(f"[binance] fetch error ({n_errors}): {e}", file=sys.stderr)

        elapsed = time.time() - loop_start
        sleep_for = max(0.0, interval - elapsed)
        time.sleep(sleep_for)

        # flush periodically so we don't lose everything on a crash
        if len(rows) >= 500:
            _flush(rows, out_prefix)
            rows = []

    if rows:
        _flush(rows, out_prefix)
    print(f"[binance] done, {n_errors} errors")


def _flush(rows, out_prefix):
    df = pd.DataFrame(rows)
    Path(out_prefix).parent.mkdir(parents=True, exist_ok=True)
    fname = f"{out_prefix}_{int(rows[0]['ts'])}.csv.gz"
    df.to_csv(fname, index=False, compression="gzip")
    print(f"[binance] wrote {len(df)} rows -> {fname}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", default="BTCUSDT")
    p.add_argument("--minutes", type=float, default=60)
    p.add_argument("--interval", type=float, default=0.5)
    p.add_argument("--out", default="data/binance_raw/btcusdt")
    args = p.parse_args()
    run(args.symbol, args.minutes, args.interval, args.out)
