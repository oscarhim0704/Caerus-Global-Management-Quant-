"""
Hyperliquid BTC-PERP orderbook collector.

Subscribes to the l2Book channel over Hyperliquid's public websocket API
and writes a top-10 level snapshot every time an update arrives, tagged
with local receive time. Hyperliquid pushes book diffs quite frequently,
so this can generate a lot of rows during volatile periods. Rows are
flushed to a gzipped CSV file in batches to keep memory bounded.

Usage:
    python collect_hyperliquid.py --coin BTC --minutes 60 --out data/hyperliquid_raw

Docs: https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/websocket
"""
import argparse
import json
import time
import sys
from pathlib import Path

import pandas as pd
import websocket

WS_URL = "wss://api.hyperliquid.xyz/ws"


class BookCollector:
    def __init__(self, coin: str, minutes: float, out_prefix: str):
        self.coin = coin
        self.end_time = time.time() + minutes * 60
        self.out_prefix = out_prefix
        self.rows = []
        self.n_msgs = 0

    def on_open(self, ws):
        sub = {
            "method": "subscribe",
            "subscription": {"type": "l2Book", "coin": self.coin},
        }
        ws.send(json.dumps(sub))
        print(f"[hyperliquid] subscribed to l2Book for {self.coin}")

    def on_message(self, ws, message):
        recv_ts = time.time()
        try:
            msg = json.loads(message)
        except json.JSONDecodeError:
            return
        if msg.get("channel") != "l2Book":
            return
        data = msg.get("data", {})
        levels = data.get("levels", [[], []])
        row = {"ts": recv_ts, "exchange_ts": data.get("time", None)}
        bids, asks = levels[0], levels[1]
        for i in range(10):
            if i < len(bids):
                row[f"bid_px_{i}"] = float(bids[i]["px"])
                row[f"bid_sz_{i}"] = float(bids[i]["sz"])
            else:
                row[f"bid_px_{i}"] = None
                row[f"bid_sz_{i}"] = None
            if i < len(asks):
                row[f"ask_px_{i}"] = float(asks[i]["px"])
                row[f"ask_sz_{i}"] = float(asks[i]["sz"])
            else:
                row[f"ask_px_{i}"] = None
                row[f"ask_sz_{i}"] = None
        self.rows.append(row)
        self.n_msgs += 1

        if len(self.rows) >= 1000:
            self._flush()

        if time.time() >= self.end_time:
            ws.close()

    def on_error(self, ws, error):
        print(f"[hyperliquid] error: {error}", file=sys.stderr)

    def on_close(self, ws, close_status_code, close_msg):
        if self.rows:
            self._flush()
        print(f"[hyperliquid] closed, total messages: {self.n_msgs}")

    def _flush(self):
        df = pd.DataFrame(self.rows)
        Path(self.out_prefix).parent.mkdir(parents=True, exist_ok=True)
        fname = f"{self.out_prefix}_{int(self.rows[0]['ts'])}.csv.gz"
        df.to_csv(fname, index=False, compression="gzip")
        print(f"[hyperliquid] wrote {len(df)} rows -> {fname}")
        self.rows = []

    def run(self):
        ws = websocket.WebSocketApp(
            WS_URL,
            on_open=self.on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close,
        )
        ws.run_forever()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--coin", default="BTC")
    p.add_argument("--minutes", type=float, default=60)
    p.add_argument("--out", default="data/hyperliquid_raw/btc_perp")
    args = p.parse_args()
    BookCollector(args.coin, args.minutes, args.out).run()
