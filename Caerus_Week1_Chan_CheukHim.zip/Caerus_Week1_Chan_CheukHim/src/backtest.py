"""
Event-driven backtester for a short-horizon orderbook signal.

Kept deliberately simple: one signal, one instrument, flat-or-long-or-short,
fixed holding period. The point of this week's exercise isn't strategy
sophistication, it's whether a believable cost model kills the edge or not,
so most of the code here is the cost model, not the strategy logic.

Cost model has three pieces:
  1. Trading fees (taker, in bps of notional), charged on both entry and exit.
  2. Market impact: executed price is worse than the quoted mid by an
     amount that grows with trade size relative to visible top-of-book
     depth (square-root impact, which is the standard rule of thumb for
     futures/crypto venues: cost ~ sigma * sqrt(size / depth)).
  3. Latency: the signal is computed on data available at time t, but
     the order doesn't actually land until t + latency. Since our capture
     is 1-second resolution, we approximate latency by shifting execution
     forward by ceil(latency) seconds and charging an extra slippage term
     for the sub-second slice we can't resolve directly.
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class CostModel:
    taker_fee_bps: float = 4.0        # Binance USDT-M perp taker fee ~0.04%
    latency_s: float = 0.3            # round-trip signal-to-fill latency
    impact_coef_bps: float = 8.0      # bps of impact when size == depth
    vol_bps_per_s: float = 1.2        # short-horizon vol used for latency slippage


def sqrt_impact_bps(trade_size: float, top_depth: float, coef_bps: float) -> float:
    if top_depth <= 0:
        return coef_bps * 3  # no visible depth -> assume the worst
    ratio = min(trade_size / top_depth, 5.0)  # cap so a tiny-depth edge case doesn't explode
    return coef_bps * np.sqrt(ratio)


def run_backtest(df: pd.DataFrame, signal_col: str, price_col: str, depth_col: str,
                  horizon_s: int, entry_threshold: float, trade_size: float,
                  cost: CostModel) -> pd.DataFrame:
    """
    df must be sorted by time with no gaps (1 row per second). signal_col is
    assumed to be computed using only information available at that row
    (i.e. already lagged appropriately upstream, this function does not
    lag it for you).

    Strategy: go long when signal > +threshold, short when signal < -threshold,
    flat otherwise. Each trade holds exactly `horizon_s` seconds, entered
    `latency_s` after the signal fires, and cannot be re-entered while a
    position is open (no pyramiding).
    """
    n = len(df)
    prices = df[price_col].values
    signals = df[signal_col].values
    depths = df[depth_col].values
    latency_rows = max(1, int(np.ceil(cost.latency_s)))

    trades = []
    i = 0
    while i < n - horizon_s - latency_rows - 1:
        sig = signals[i]
        if np.isnan(sig) or abs(sig) < entry_threshold:
            i += 1
            continue

        direction = 1 if sig > 0 else -1
        entry_idx = i + latency_rows
        exit_idx = entry_idx + horizon_s
        if exit_idx >= n:
            break

        quote_price_at_signal = prices[i]
        quote_price_at_entry = prices[entry_idx]
        exit_price_quote = prices[exit_idx]

        impact_bps = sqrt_impact_bps(trade_size, depths[i], cost.impact_coef_bps)
        # sub-second latency slippage: extra adverse drift we can't resolve
        # at 1s resolution, modelled as half the assumed short-horizon vol
        latency_slip_bps = 0.5 * cost.vol_bps_per_s * cost.latency_s

        entry_price = quote_price_at_entry * (1 + direction * (impact_bps + latency_slip_bps) / 10000)
        exit_price = exit_price_quote * (1 - direction * impact_bps / 10000)

        gross_ret = direction * (exit_price - entry_price) / entry_price
        fee_ret = 2 * cost.taker_fee_bps / 10000  # entry + exit
        net_ret = gross_ret - fee_ret

        trades.append({
            "signal_idx": i,
            "entry_idx": entry_idx,
            "exit_idx": exit_idx,
            "direction": direction,
            "signal_value": sig,
            "gross_ret": gross_ret,
            "fee_cost": fee_ret,
            "impact_bps": impact_bps,
            "net_ret": net_ret,
        })

        i = exit_idx + 1  # no overlapping trades

    return pd.DataFrame(trades)


def summarize_trades(trades: pd.DataFrame) -> dict:
    if len(trades) == 0:
        return {"n_trades": 0}
    win_rate = (trades["net_ret"] > 0).mean()
    return {
        "n_trades": len(trades),
        "gross_mean_bps": trades["gross_ret"].mean() * 10000,
        "net_mean_bps": trades["net_ret"].mean() * 10000,
        "net_total_bps": trades["net_ret"].sum() * 10000,
        "win_rate": win_rate,
        "avg_fee_bps": trades["fee_cost"].mean() * 10000,
        "avg_impact_bps": trades["impact_bps"].mean(),
        "sharpe_like": (trades["net_ret"].mean() / trades["net_ret"].std()) if trades["net_ret"].std() > 0 else np.nan,
    }
