"""
Quick end-to-end run: load data -> build features -> check predictive power ->
fit a threshold on train, backtest on test. This is basically a script
version of what the notebook does interactively, used here to sanity check
numbers before writing them into the notebook/report.
"""
import numpy as np
import pandas as pd

from features import build_cross_exchange_panel, lead_lag_correlation, add_basic_book_features
from backtest import CostModel, run_backtest, summarize_trades

DATA_DIR = "data"


def main():
    binance = pd.read_csv(f"{DATA_DIR}/binance_btcusdt_perp_book.csv.gz", parse_dates=["timestamp"])
    hl = pd.read_csv(f"{DATA_DIR}/hyperliquid_btc_perp_book.csv.gz", parse_dates=["timestamp"])
    print(f"binance: {len(binance)} rows, hl: {len(hl)} rows")

    ll = lead_lag_correlation(binance.set_index("timestamp")["bid_px_0"].add(
        binance.set_index("timestamp")["ask_px_0"]).div(2),
        hl.set_index("timestamp")["bid_px_0"].add(hl.set_index("timestamp")["ask_px_0"]).div(2),
        max_lag=10)
    print("\nLead-lag correlation table:")
    print(ll.to_string(index=False))
    best = ll.loc[ll["corr"].idxmax()]
    print(f"\nPeak correlation at lag={best['lag_s']:.0f}s, corr={best['corr']:.3f}")

    panel = build_cross_exchange_panel(binance, hl, depth=5, horizons=(1, 5, 10, 30))
    panel = panel.dropna(subset=["fwd_ret_hl_10s"])
    print(f"\npanel rows after dropna: {len(panel)}")

    # quick predictive check: correlation between obi_hl (lagged 0) and fwd_ret_hl
    for h in (1, 5, 10, 30):
        col = f"fwd_ret_hl_{h}s"
        c_obi = panel["obi_hl"].corr(panel[col])
        c_xgap = panel["xgap_bps"].corr(panel[col])
        print(f"h={h:>2}s  corr(obi_hl, fwd_ret)={c_obi: .4f}   corr(xgap_bps, fwd_ret)={c_xgap: .4f}")

    # chronological split
    n = len(panel)
    split = int(n * 0.7)
    train, test = panel.iloc[:split].copy(), panel.iloc[split:].copy()

    # combine both signals into one simple z-scored composite on train stats
    for part in (train, test):
        pass
    obi_mu, obi_sd = train["obi_hl"].mean(), train["obi_hl"].std()
    xgap_mu, xgap_sd = train["xgap_bps"].mean(), train["xgap_bps"].std()

    for part in (train, test):
        part["obi_z"] = (part["obi_hl"] - obi_mu) / obi_sd
        part["xgap_z"] = (part["xgap_bps"] - xgap_mu) / xgap_sd
        part["composite_signal"] = 0.5 * part["obi_z"] + 0.5 * part["xgap_z"]

    # pick threshold on train: top/bottom decile of |signal|
    thresh = train["composite_signal"].abs().quantile(0.90)
    print(f"\nentry threshold (90th pct of |signal| on train): {thresh:.3f}")

    cost = CostModel()
    test_bt = test.set_index("timestamp") if "timestamp" in test.columns else test
    test_bt = test.reset_index(drop=True)

    trades = run_backtest(
        test_bt, signal_col="composite_signal", price_col="mid_hl", depth_col="bid_depth_hl",
        horizon_s=10, entry_threshold=thresh, trade_size=1.0, cost=cost,
    )
    summary = summarize_trades(trades)
    print("\nOut-of-sample backtest summary (test set, 10s horizon):")
    for k, v in summary.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
