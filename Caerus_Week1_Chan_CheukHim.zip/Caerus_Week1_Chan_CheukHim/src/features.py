"""
Feature construction for the cross-exchange orderbook panel.

Everything here operates on a single-venue book DataFrame with columns
bid_px_0..9, bid_sz_0..9, ask_px_0..9, ask_sz_0..9, timestamp (one row per
second). Cross-exchange features need both venues aligned on `timestamp`.
"""
import numpy as np
import pandas as pd


def add_basic_book_features(df: pd.DataFrame, depth: int = 5) -> pd.DataFrame:
    """Mid price, microprice, spread, and order book imbalance (top `depth` levels)."""
    df = df.copy()
    df["mid"] = (df["bid_px_0"] + df["ask_px_0"]) / 2
    df["spread"] = df["ask_px_0"] - df["bid_px_0"]

    bid_sz_cols = [f"bid_sz_{i}" for i in range(depth)]
    ask_sz_cols = [f"ask_sz_{i}" for i in range(depth)]
    bid_depth = df[bid_sz_cols].sum(axis=1)
    ask_depth = df[ask_sz_cols].sum(axis=1)
    df["bid_depth"] = bid_depth
    df["ask_depth"] = ask_depth

    # order book imbalance in [-1, 1], positive = more resting size on bid side
    df["obi"] = (bid_depth - ask_depth) / (bid_depth + ask_depth)

    # microprice: size-weighted average of best bid/ask, a slightly better
    # short-horizon price proxy than the plain mid
    df["microprice"] = (
        df["bid_px_0"] * df["ask_sz_0"] + df["ask_px_0"] * df["bid_sz_0"]
    ) / (df["ask_sz_0"] + df["bid_sz_0"])

    return df


def add_forward_returns(df: pd.DataFrame, horizons=(1, 5, 10, 30), price_col: str = "mid") -> pd.DataFrame:
    """Forward log-returns at each horizon (seconds), assuming 1 row = 1 second."""
    df = df.copy()
    for h in horizons:
        fwd = df[price_col].shift(-h)
        df[f"fwd_ret_{h}s"] = np.log(fwd / df[price_col])
    return df


def build_cross_exchange_panel(binance: pd.DataFrame, hyperliquid: pd.DataFrame,
                                depth: int = 5, horizons=(1, 5, 10, 30)) -> pd.DataFrame:
    """
    Merge Binance and Hyperliquid on timestamp and compute cross-venue
    features: price gap, lead/lag proxy, and combined imbalance signal.
    """
    b = add_basic_book_features(binance, depth=depth)
    h = add_basic_book_features(hyperliquid, depth=depth)

    b = b.set_index("timestamp")
    h = h.set_index("timestamp")

    merged = b[["mid", "microprice", "spread", "obi", "bid_depth", "ask_depth"]].join(
        h[["mid", "microprice", "spread", "obi", "bid_depth", "ask_depth"]],
        lsuffix="_binance", rsuffix="_hl", how="inner",
    )

    # cross-venue price gap in bps. If Binance leads, a positive gap here
    # should predict Hyperliquid catching up (i.e. HL's forward return)
    merged["xgap_bps"] = (
        (merged["mid_binance"] - merged["mid_hl"]) / merged["mid_hl"]
    ) * 10000

    merged = merged.reset_index()
    merged = add_forward_returns(merged, horizons=horizons, price_col="mid_hl")
    merged = merged.rename(columns={f"fwd_ret_{h}s": f"fwd_ret_hl_{h}s" for h in horizons})
    merged = add_forward_returns(merged, horizons=horizons, price_col="mid_binance")
    merged = merged.rename(columns={f"fwd_ret_{h}s": f"fwd_ret_binance_{h}s" for h in horizons})

    return merged


def lead_lag_correlation(binance_mid: pd.Series, hl_mid: pd.Series, max_lag: int = 10) -> pd.DataFrame:
    """
    Cross-correlation of returns between venues at lags from -max_lag to
    +max_lag seconds. Positive lag k: binance return at t vs hl return at
    t+k. If Binance leads Hyperliquid, correlation should peak at some k>0.
    """
    b_ret = np.log(binance_mid).diff().dropna()
    h_ret = np.log(hl_mid).diff().dropna()
    idx = b_ret.index.intersection(h_ret.index)
    b_ret = b_ret.loc[idx]
    h_ret = h_ret.loc[idx]

    results = []
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            x = b_ret.iloc[: len(b_ret) - lag].values if lag > 0 else b_ret.values
            y = h_ret.iloc[lag:].values
        else:
            x = b_ret.iloc[-lag:].values
            y = h_ret.iloc[: len(h_ret) + lag].values
        n = min(len(x), len(y))
        if n < 10:
            continue
        corr = np.corrcoef(x[:n], y[:n])[0, 1]
        results.append({"lag_s": lag, "corr": corr, "n": n})
    return pd.DataFrame(results)
