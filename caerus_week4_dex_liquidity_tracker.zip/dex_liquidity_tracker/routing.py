"""
routing.py
----------
Naive vs optimal routing and the execution-cost gap between them.

  naive  : send the whole order to a single venue. I use the venue that is
           deepest right now (max depth_at_10bps) - a sensible default a simple
           router would pick. (Sending to a *fixed* venue is even worse; this is
           the charitable naive baseline.)
  optimal: split the order across venues to minimise total cost. AMM cost is
           convex in size, so the optimum equalises the marginal execution price
           across venues. I approximate that with a greedy marginal allocator:
           chop the order into chunks and give each chunk to whichever venue is
           cheapest on the margin at that moment. For convex curves this
           converges to the marginal-price-equalisation optimum and is much
           easier to defend than a black-box solver.

Everything is on the buy side (USD -> base); costs are symmetric enough that
the buy side is representative for the headline number.
"""
import numpy as np
import pandas as pd

import config as C
import depth as D


def _buy_out(v, price, usd_in):
    """base tokens out for a USD buy on one venue; 0 if it can't fill."""
    out, _ = D._quote(v, price, "buy", usd_in)
    return out if out is not None else 0.0


def _cost_bps(v, price, size_usd):
    out = _buy_out(v, price, size_usd)
    if out <= 0:
        return None
    return (size_usd / out - price) / price * 10_000.0


def _naive_deepest(venues, depth10, price, size_usd):
    """Naive heuristic #1: 'trade where the liquidity is' - send all to deepest pool."""
    best = max(depth10, key=depth10.get)
    return _cost_bps(venues[best], price, size_usd), best


def _naive_best_single(venues, price, size_usd):
    """Naive heuristic #2 (charitable): best single venue by all-in cost, no split."""
    costs = {v: _cost_bps(venues[v], price, size_usd) for v in venues}
    costs = {k: c for k, c in costs.items() if c is not None}
    if not costs:
        return None, None
    best = min(costs, key=costs.get)
    return costs[best], best


def _optimal(venues, price, size_usd, chunks=12):
    names = list(venues.keys())
    alloc = {v: 0.0 for v in names}
    step = size_usd / chunks
    for _ in range(chunks):
        # marginal base gained by putting this chunk on each venue
        best_v, best_gain = None, -1.0
        for v in names:
            cur = _buy_out(venues[v], price, alloc[v])
            nxt = _buy_out(venues[v], price, alloc[v] + step)
            gain = nxt - cur
            if gain > best_gain:
                best_gain, best_v = gain, v
        alloc[best_v] += step
    total_out = sum(_buy_out(venues[v], price, alloc[v]) for v in names)
    if total_out <= 0:
        return None, alloc
    eff = size_usd / total_out
    return (eff - price) / price * 10_000.0, alloc


def build(store, depth_df):
    """route_df: one row per (timestamp, pair, size) with naive/opt cost + saving."""
    # index depth10 for the naive choice
    d10 = {(r.timestamp, r.pair, r.venue): r.depth_10bps_usd
           for r in depth_df.itertuples()}
    rows = []
    hours = len(store["timestamps"])
    for pair in store["liq"].keys():
        for h in range(hours):
            ts = int(store["timestamps"][h])
            price, venues = D._state_at(store, pair, h)
            depth10 = {v: d10[(ts, pair, v)] for v in venues}
            for size in C.TRADE_SIZES_USD:
                deep_bps, deep_v = _naive_deepest(venues, depth10, price, size)
                best_bps, best_v = _naive_best_single(venues, price, size)
                opt_bps, alloc = _optimal(venues, price, size)
                if best_bps is None or opt_bps is None:
                    continue
                # optimal shouldn't beat best-single by a rounding artefact
                opt_bps = min(opt_bps, best_bps)
                save_vs_best = best_bps - opt_bps        # true value of splitting
                save_vs_deep = (deep_bps - opt_bps) if deep_bps is not None else None
                split = {v: round(alloc[v] / size, 3) for v in alloc if alloc[v] > 0}
                rows.append({
                    "timestamp": ts, "utc_hour": int(store["utc_hour"][h]),
                    "pair": pair, "size_usd": size,
                    "naive_deepest_venue": deep_v,
                    "naive_deepest_bps": round(deep_bps, 3) if deep_bps is not None else None,
                    "best_single_venue": best_v,
                    "best_single_bps": round(best_bps, 3),
                    "optimal_bps": round(opt_bps, 3),
                    "saving_vs_best_bps": round(save_vs_best, 3),
                    "saving_vs_best_usd": round(save_vs_best / 10_000.0 * size, 2),
                    "saving_vs_deepest_bps": round(save_vs_deep, 3) if save_vs_deep is not None else None,
                    "optimal_split": split,
                })
    return pd.DataFrame(rows)
