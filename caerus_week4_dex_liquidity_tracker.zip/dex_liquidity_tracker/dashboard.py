"""
dashboard.py
------------
Daily liquidity dashboard mock-up (deliverable #2). Reads the CSVs in outputs/
and presents the depth, fragmentation, routing and time-of-day views with a
pair selector and a date slider.

Run:  streamlit run dashboard.py
(If outputs/ is empty, run `python run_pipeline.py` first.)

NOTE: the underlying data is simulated (see README / config.py) - this is a
mock-up of what the daily monitor would look like on live data.
"""
import os
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

import config as C
import viz

st.set_page_config(page_title="DEX Liquidity Fragmentation", layout="wide")


@st.cache_data
def load():
    if not os.path.exists(f"{C.OUTPUT_DIR}/fragmentation.csv"):
        import run_pipeline
        run_pipeline.main()
    return viz._load()


d = load()

st.title("DEX Liquidity Fragmentation Tracker")
st.caption("ETH/USDC & WBTC/USDC across Uniswap v3 and Curve  -  "
           "**simulated data mock-up** (see README).")

# ---- controls ----
c1, c2 = st.columns([1, 3])
pair = c1.selectbox("Pair", ["ETH/USDC", "WBTC/USDC"])
frag = d["fragmentation"][d["fragmentation"].pair == pair].copy()
frag["dt"] = pd.to_datetime(frag["timestamp"], unit="s")
days = sorted(frag["dt"].dt.date.unique())
day = c2.select_slider("Day", options=days, value=days[-1])

# ---- top KPI row (for the selected day) ----
day_rows = frag[frag["dt"].dt.date == day]
flips = d["venue_flips"][d["venue_flips"].pair == pair].iloc[0]
k1, k2, k3, k4 = st.columns(4)
k1.metric("Avg total depth (10bps)", f"${day_rows['total_depth_10bps_usd'].mean()/1e6:.1f}M")
k2.metric("Avg Gini (concentration)", f"{day_rows['gini_depth'].mean():.2f}")
k3.metric("Effective # venues", f"{day_rows['eff_num_venues'].mean():.2f}")
k4.metric("Leader flip rate (30d)", f"{flips['flip_rate']*100:.1f}%")

st.divider()

# ---- row 1: depth + share ----
a, b = st.columns(2)
with a:
    st.subheader("Depth by venue (30d)")
    st.pyplot(viz.fig_depth_timeseries(d))
with b:
    st.subheader("Share of total depth")
    st.pyplot(viz.fig_depth_share(d))

# ---- row 2: fragmentation + leadership ----
a, b = st.columns(2)
with a:
    st.subheader("Fragmentation metrics")
    st.pyplot(viz.fig_fragmentation(d))
with b:
    st.subheader("Most-liquid venue by session")
    st.pyplot(viz.fig_leadership(d))

# ---- row 3: routing + time of day ----
a, b = st.columns(2)
with a:
    st.subheader("Execution cost by routing strategy")
    st.pyplot(viz.fig_routing(d))
with b:
    st.subheader("Depth & concentration by UTC hour")
    st.pyplot(viz.fig_hour_of_day(d))

# ---- routing table for the selected pair ----
st.divider()
st.subheader(f"Routing detail - {pair}")
r = (d["routing"][d["routing"].pair == pair]
     .groupby("size_usd")
     .agg(naive_deepest_bps=("naive_deepest_bps", "mean"),
          best_single_bps=("best_single_bps", "mean"),
          optimal_bps=("optimal_bps", "mean"),
          save_vs_best_usd=("saving_vs_best_usd", "mean"),
          save_vs_deepest_bps=("saving_vs_deepest_bps", "mean")).round(2))
st.dataframe(r, use_container_width=True)
st.caption("Optimal splitting beats the best single venue by <1bp; the big gap is "
           "vs the 'trade in the deepest pool' heuristic, which overpays on WBTC "
           "because the deepest pool is the 0.30% fee tier.")
