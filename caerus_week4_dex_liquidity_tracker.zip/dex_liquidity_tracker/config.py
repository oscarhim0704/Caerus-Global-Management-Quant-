"""
config.py
---------
One place for all the settings I use across the pipeline so I don't have
addresses / numbers scattered around the code.

Pairs analysed: ETH/USDC and WBTC/USDC on Ethereum mainnet.
Venues per pair: two Uniswap v3 fee tiers + the Curve TriCryptoUSDC pool.

NOTE ON DATA (read me):
The task asks to pull 30 days of pool data from Uniswap v3 / Curve via public
RPCs or subgraphs. My build sandbox has no outbound access to Ethereum RPCs,
The Graph gateway, or the Curve contracts, so the numbers in the delivered run
come from the OFFLINE SIMULATOR (simulator.py), not from live chain reads.
The live fetchers in live_data.py are real and written to the current subgraph
/ contract schema - point them at a funded RPC + Graph API key and set
USE_LIVE_DATA = True to run against mainnet. Everything downstream (depth,
fragmentation, routing) runs identically on either data source.
"""

USE_LIVE_DATA = False          # flip to True when a real RPC + Graph key are available
LOOKBACK_DAYS = 30
HOURS = LOOKBACK_DAYS * 24     # 720 hourly snapshots

# trade sizes to probe depth at (USD notional), from the brief
TRADE_SIZES_USD = [10_000, 50_000, 250_000]

# depth magnitude = max notional tradeable within this much PRICE IMPACT
# (fee excluded on purpose, so venues compete on liquidity not fee tier).
DEPTH_THRESHOLD_BPS = 10.0

# ---- token metadata (mainnet) ----
TOKENS = {
    "USDC": {"address": "0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", "decimals": 6},
    "WETH": {"address": "0xC02aaa39b223FE8D0A0e5C4F27eAD9083C756Cc2", "decimals": 18},
    "WBTC": {"address": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", "decimals": 8},
}

# ---- Uniswap v3 pools (address, fee tier, tick spacing) ----
# fee is in bps of 1 (0.0005 = 5bps = 0.05%)
UNISWAP_POOLS = {
    "ETH/USDC": [
        {"venue": "UniV3-0.05%", "address": "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640",
         "fee": 0.0005, "tick_spacing": 10},
        {"venue": "UniV3-0.30%", "address": "0x8ad599c3a0ff1de082011efddc58f1908eb6e6d8",
         "fee": 0.0030, "tick_spacing": 60},
    ],
    "WBTC/USDC": [
        {"venue": "UniV3-0.30%", "address": "0x99ac8cA7087fA4A2A1FB6357269965A2014ABc35",
         "fee": 0.0030, "tick_spacing": 60},
        {"venue": "UniV3-0.05%", "address": "0x9a772018fbd77fcd2d25657e5c547baff3fd7d16",
         "fee": 0.0005, "tick_spacing": 10},
    ],
}

# ---- Curve TriCryptoUSDC pool (USDC / WBTC / WETH) ----
# same pool serves both pairs; coin indices: 0=USDC, 1=WBTC, 2=WETH
CURVE_POOL = {
    "venue": "Curve-TriCrypto",
    "address": "0x7f86bf177dd4f3494b841a37e810a34dd56c829b",
    "coins": {"USDC": 0, "WBTC": 1, "WETH": 2},
    "fee": 0.0007,   # representative effective fee (mid_fee ~0.03%, out_fee ~0.34%)
}

# ---- endpoints (only used in live mode) ----
# Graph gateway needs a Studio API key: put it in the URL where shown.
GRAPH_API_KEY = "YOUR_API_KEY_HERE"
UNISWAP_V3_SUBGRAPH = (
    f"https://gateway.thegraph.com/api/{GRAPH_API_KEY}"
    "/subgraphs/id/5zvR82QoaXYFyDEKLZ9t6v9adgnptxYpKpSbxtgVENFV"
)
ETH_RPC_URL = "https://ethereum-rpc.publicnode.com"   # swap for an archive node for history

# ---- reference spot prices (USD) used to seed the simulator ----
# rough mid-window levels; the sim adds a random walk on top of these.
SEED_PRICES = {"WETH": 3200.0, "WBTC": 95000.0}

# ---- per-venue liquidity calibration ----
# base_tvl_usd is the rough active liquidity each venue supplies to the pair.
# these are order-of-magnitude figures anchored to public pool sizes, NOT live
# reads - they set how deep each venue looks in the simulation.
# NB: these are *active* liquidity figures (roughly the value sitting within a
# few % of mid, which is what actually backstops a trade), not headline TVL.
# Active liquidity is far more comparable across venues than TVL, which is why
# the venues genuinely compete here.
VENUE_TVL_USD = {
    "ETH/USDC": {                       # 0.05% tier leads but 0.30%/Curve are close
        "UniV3-0.05%":      70_000_000,
        "UniV3-0.30%":      35_000_000,
        "Curve-TriCrypto":  25_000_000,
    },
    "WBTC/USDC": {                      # genuinely contested across all three
        "UniV3-0.30%":      17_000_000,
        "Curve-TriCrypto":  16_000_000,
        "UniV3-0.05%":       9_000_000,
    },
}

# fraction of active liquidity sitting in the tight band around mid. Uniswap v3
# LPs concentrate hardest; Curve tricrypto concentrates around its internal
# price scale but a touch less peaked, so it's modelled with the same
# concentrated-liquidity machinery and a slightly lower concentration.
CONCENTRATION = {
    "UniV3-0.05%": 0.55,
    "UniV3-0.30%": 0.48,
    "Curve-TriCrypto": 0.42,
}

RANDOM_SEED = 7   # reproducible sim
OUTPUT_DIR = "outputs"
