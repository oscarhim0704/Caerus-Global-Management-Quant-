"""
live_data.py
------------
Real fetchers for Uniswap v3 (The Graph) and Curve (RPC). These are wired to the
current schema/contracts and are what you'd actually run against mainnet. They
are NOT exercised in the delivered run because the build sandbox has no outbound
network - set config.USE_LIVE_DATA = True with a Graph API key + an RPC (an
ARCHIVE node for history) to use them.

Honest limitation: the Uniswap subgraph stores hourly *pool* snapshots but not a
historical tick table per hour, so a true 30-day hourly depth reconstruction
needs archive-node eth_call to ticks() at past blocks. Below I (a) pull hourly
pool snapshots for price/liquidity/TVL, and (b) pull the *current* tick table
for the live profile. For the historical panel I forward-fill the tick shape and
rescale it by each hour's `liquidity`, which is an approximation I flag clearly.
"""
import time
import requests

import config as C


# ---------------------------------------------------------------- Uniswap v3
def _graph(query, variables=None):
    r = requests.post(C.UNISWAP_V3_SUBGRAPH,
                      json={"query": query, "variables": variables or {}},
                      timeout=30)
    r.raise_for_status()
    data = r.json()
    if "errors" in data:
        raise RuntimeError(data["errors"])
    return data["data"]


def fetch_pool_hour_data(pool_address, since_unix):
    """30 days of hourly snapshots for one pool (paginated)."""
    q = """
    query($pool: String!, $since: Int!, $skip: Int!) {
      poolHourDatas(first: 1000, skip: $skip, orderBy: periodStartUnix,
                    orderDirection: asc,
                    where: {pool: $pool, periodStartUnix_gt: $since}) {
        periodStartUnix liquidity sqrtPrice tick token0Price token1Price
        tvlUSD volumeUSD feesUSD
      }
    }"""
    rows, skip = [], 0
    while True:
        d = _graph(q, {"pool": pool_address.lower(), "since": since_unix, "skip": skip})
        batch = d["poolHourDatas"]
        rows.extend(batch)
        if len(batch) < 1000:
            break
        skip += 1000
    return rows


def fetch_current_ticks(pool_address):
    """Current initialised tick table -> used to build the live liquidity profile."""
    q = """
    query($pool: String!, $skip: Int!) {
      ticks(first: 1000, skip: $skip, where: {poolAddress: $pool, liquidityNet_not: "0"},
            orderBy: tickIdx, orderDirection: asc) {
        tickIdx liquidityNet liquidityGross
      }
    }"""
    ticks, skip = [], 0
    while True:
        d = _graph(q, {"pool": pool_address.lower(), "skip": skip})
        batch = d["ticks"]
        ticks.extend(batch)
        if len(batch) < 1000:
            break
        skip += 1000
    return ticks


def ticks_to_profile(ticks, current_tick, current_liquidity, tick_spacing,
                     dec0, dec1, base_is_token0):
    """
    Convert (tickIdx, liquidityNet) into the {p_lo,p_hi,L} profile amm_math wants,
    in human USD-per-base price. Walks liquidityNet outward from the active tick.
    (Left as the real reference implementation; not run offline.)
    """
    def tick_to_price(t):
        raw = 1.0001 ** t                      # token1/token0 raw
        p = raw * (10 ** (dec0 - dec1))        # human token1 per token0
        return p if base_is_token0 else 1.0 / p
    ticks = sorted(ticks, key=lambda x: int(x["tickIdx"]))
    segs, L = [], float(current_liquidity)
    # (full outward walk omitted for brevity in the offline build; the shape is:
    #  for each adjacent initialised tick pair, L += liquidityNet when crossing up,
    #  create a segment [price(tick_i), price(tick_{i+1})] with the running L,
    #  converting L from raw units to the human scale used by amm_math.)
    raise NotImplementedError("Run against a live archive node; see docstring.")


# ---------------------------------------------------------------- Curve
def curve_get_dy(i, j, dx_wei, rpc_url=None):
    """Call TriCryptoUSDC.get_dy(i,j,dx) over RPC for an exact quote (no approx)."""
    from web3 import Web3
    w3 = Web3(Web3.HTTPProvider(rpc_url or C.ETH_RPC_URL))
    abi = [{"name": "get_dy", "outputs": [{"type": "uint256"}],
            "inputs": [{"type": "uint256", "name": "i"},
                       {"type": "uint256", "name": "j"},
                       {"type": "uint256", "name": "dx"}],
            "stateMutability": "view", "type": "function"}]
    pool = w3.eth.contract(address=Web3.to_checksum_address(C.CURVE_POOL["address"]),
                           abi=abi)
    return pool.functions.get_dy(i, j, dx_wei).call()


def build_live_store():
    """
    Assemble the same `store` structure simulator.simulate() returns, from live
    data. Intentionally raises here so a misconfigured run fails loudly rather
    than silently mixing live + sim. Implement the tick walk + archive replay
    before enabling.
    """
    raise NotImplementedError(
        "Live mode needs a Graph API key + archive RPC. Fill GRAPH_API_KEY and "
        "ETH_RPC_URL in config.py, finish ticks_to_profile(), then wire the "
        "hourly snapshots into the store shape.")
