"""
run_pipeline.py
---------------
The ETL orchestrator. One command builds everything:

  raw state (sim or live)
     -> depth panels (slippage-at-size, depth-at-10bps)
     -> fragmentation panel + venue-flip stats
     -> routing panel (naive vs optimal)
     -> hour-of-day summary (bonus)
  and writes them to outputs/ as parquet + csv.

Run:  python run_pipeline.py
"""
import os
import pandas as pd

import config as C
import simulator as sim
import depth as D
import fragmentation as F
import routing as R


def get_store():
    if C.USE_LIVE_DATA:
        import live_data
        return live_data.build_live_store()
    return sim.simulate()


def hour_of_day_summary(frag_df, slip_df):
    """Bonus: when does fragmentation worsen? Average by UTC hour + session label."""
    def session(h):
        if 0 <= h < 8:   return "Asia (00-08 UTC)"
        if 8 <= h < 13:  return "EU (08-13 UTC)"
        if 13 <= h < 22: return "US (13-22 UTC)"
        return "Off (22-24 UTC)"

    frag = frag_df.copy()
    frag["session"] = frag["utc_hour"].map(session)
    by_hour = (frag.groupby(["pair", "utc_hour"])
               .agg(dominant_share=("dominant_share", "mean"),
                    hhi=("hhi", "mean"),
                    eff_num_venues=("eff_num_venues", "mean"),
                    total_depth=("total_depth_10bps_usd", "mean"))
               .reset_index())
    by_session = (frag.groupby(["pair", "session"])
                  .agg(dominant_share=("dominant_share", "mean"),
                       hhi=("hhi", "mean"),
                       eff_num_venues=("eff_num_venues", "mean"),
                       total_depth=("total_depth_10bps_usd", "mean"))
                  .reset_index())
    # slippage on the biggest probe size, by hour, as a cost proxy
    big = slip_df[slip_df["size_usd"] == max(C.TRADE_SIZES_USD)]
    slip_by_hour = (big.groupby(["pair", "utc_hour"])["slippage_bps"]
                    .mean().reset_index()
                    .rename(columns={"slippage_bps": "slip_bps_250k"}))
    by_hour = by_hour.merge(slip_by_hour, on=["pair", "utc_hour"], how="left")
    return by_hour, by_session


def main():
    os.makedirs(C.OUTPUT_DIR, exist_ok=True)
    print(f"[1/5] loading state  (live={C.USE_LIVE_DATA}) ...")
    store = get_store()

    print("[2/5] depth panels ...")
    slip_df, depth_df = D.build_panels(store)

    print("[3/5] fragmentation ...")
    frag_df = F.build(depth_df)
    flip_df = F.venue_flip_stats(frag_df)

    print("[4/5] routing ...")
    route_df = R.build(store, depth_df)

    print("[5/5] hour-of-day + save ...")
    hod_hour, hod_session = hour_of_day_summary(frag_df, slip_df)

    out = C.OUTPUT_DIR
    slip_df.to_parquet(f"{out}/slippage_at_size.parquet", index=False)
    depth_df.to_parquet(f"{out}/depth_10bps.parquet", index=False)
    frag_df.to_parquet(f"{out}/fragmentation.parquet", index=False)
    route_df.to_parquet(f"{out}/routing.parquet", index=False)
    # csv copies for quick eyeballing / the dashboard
    slip_df.to_csv(f"{out}/slippage_at_size.csv", index=False)
    depth_df.to_csv(f"{out}/depth_10bps.csv", index=False)
    frag_df.to_csv(f"{out}/fragmentation.csv", index=False)
    route_df.to_csv(f"{out}/routing.csv", index=False)
    flip_df.to_csv(f"{out}/venue_flips.csv", index=False)
    hod_hour.to_csv(f"{out}/hour_of_day.csv", index=False)
    hod_session.to_csv(f"{out}/by_session.csv", index=False)

    # ---- console summary so the run is legible ----
    pd.set_option("display.width", 120)
    print("\n=== venue flips (how often the most-liquid venue changes) ===")
    print(flip_df.to_string(index=False))
    print("\n=== median slippage by venue / size (bps) ===")
    piv = (slip_df.groupby(["pair", "venue", "size_usd"])["slippage_bps"]
           .median().round(2).reset_index())
    print(piv.to_string(index=False))
    print("\n=== routing: naive baselines vs optimal split ===")
    rs = (route_df.groupby(["pair", "size_usd"])
          .agg(naive_deepest_bps=("naive_deepest_bps", "mean"),
               best_single_bps=("best_single_bps", "mean"),
               optimal_bps=("optimal_bps", "mean"),
               save_vs_best_bps=("saving_vs_best_bps", "mean"),
               save_vs_best_usd=("saving_vs_best_usd", "mean"),
               save_vs_deepest_bps=("saving_vs_deepest_bps", "mean")).round(2).reset_index())
    print(rs.to_string(index=False))
    print("\n=== fragmentation by session ===")
    print(hod_session.round(3).to_string(index=False))
    print("\nwrote outputs to ./outputs/")
    return dict(slip=slip_df, depth=depth_df, frag=frag_df, flips=flip_df,
                route=route_df, hod_hour=hod_hour, hod_session=hod_session)


if __name__ == "__main__":
    main()
