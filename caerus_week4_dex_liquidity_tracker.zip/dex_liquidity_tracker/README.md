# DEX Liquidity Fragmentation Tracker — Ethereum

Week 4 task. Measures how liquidity for **ETH/USDC** and **WBTC/USDC** is
fragmented across **Uniswap v3** (0.05% and 0.30% fee tiers) and **Curve**
(TriCryptoUSDC), and what that fragmentation does to execution cost and routing.

---

## ⚠️ Data disclosure — please read first

The task asks for 30 days of on-chain pool data pulled from Uniswap v3 / Curve
via public RPCs or subgraphs. **The environment I built this in has no outbound
network access to Ethereum RPCs or The Graph gateway**, so I could not pull live
chain data.

**The numbers in the delivered run therefore come from an offline simulator
(`simulator.py`), not from live chain reads.** The simulator generates 30 days
of hourly pool *state* (a Uniswap-v3-style liquidity profile + mid price per
venue per hour), calibrated to public pool sizes. All the analysis downstream of
the data layer — depth, fragmentation, routing, time-of-day — then runs the
*same* code it would run on live data.

The real fetchers are written and included in **`live_data.py`** (Uniswap v3 via
The Graph, Curve via `get_dy` over RPC), wired to the current schema/contracts.
To run on live mainnet data: add a Graph API key + an archive RPC in `config.py`,
set `USE_LIVE_DATA = True`, and finish the tick→profile reconstruction noted in
`live_data.py`.

**What to trust:** the *relative* patterns (which venue leads, how cost scales
with size, when fragmentation worsens, the value of routing) are the robust
findings. The *absolute* bps levels depend on the liquidity calibration and would
be replaced by live reads.

---

## Headline findings

1. **ETH/USDC liquidity leadership is extremely persistent** — the Uni 0.05% pool
   is the deepest venue in 100% of hours (0 flips over 720h). Little to route around.
2. **WBTC/USDC is genuinely contested** — the deepest venue rotates between Uni
   0.30% (~78% of hours) and Curve (~22%), flipping in ~17% of hourly transitions,
   and the rotation is **regional** (Curve leads in Asia/EU hours, Uniswap in the US session).
3. **Depth ≠ best execution** — WBTC's *deepest* pool is the 0.30% fee tier, so the
   naive "trade where the liquidity is" heuristic overpays by **~20 bps**.
4. **Splitting adds little** — once you pick the cheapest single venue, optimal
   splitting saves **<1 bp** even at $250k. The ROI of a full smart-order-router is
   low for these two pairs at ≤$250k.
5. **Asia hours (00–08 UTC) are the worst time to trade** — total depth is ~25–30%
   thinner than the US session and fragmentation is higher.

A note on wording: the brief's suggested "Gini of pool depth" measures
**concentration** (high Gini = one venue dominates = *less* fragmented), which is
the opposite of the "fragmentation" the execution-cost question cares about. The
code reports both a concentration index (Gini/HHI) and a dispersion index
(normalised entropy / effective venue count) and is explicit about which is which.

---

## How to run

```bash
pip install -r requirements.txt

python run_pipeline.py       # builds all panels -> outputs/ (parquet + csv)
python viz.py                # regenerates the charts -> outputs/figs/
jupyter notebook analysis_notebook.ipynb   # the written-up analysis
streamlit run dashboard.py   # the daily dashboard mock-up
```

`run_pipeline.py` runs the simulator by default. Flip `USE_LIVE_DATA = True` in
`config.py` to point the identical pipeline at live data.

---

## Repo layout

| file | what it does |
|------|--------------|
| `config.py` | all settings: pool addresses, venues, trade sizes, calibration, endpoints |
| `amm_math.py` | the swap maths — Uniswap v3 liquidity-profile walk + Curve reference model |
| `simulator.py` | offline generator: 30 days of hourly pool state, calibrated to public sizes |
| `live_data.py` | **real** subgraph + RPC fetchers (used when `USE_LIVE_DATA=True`; not run offline) |
| `depth.py` | depth engine: all-in cost at $10k/$50k/$250k + depth-within-10bps per venue/hour |
| `fragmentation.py` | Gini / HHI / entropy / dominant-share + most-liquid-venue flip stats |
| `routing.py` | naive (deepest / best-single) vs optimal-split routing and the cost gap |
| `run_pipeline.py` | orchestrator / ETL — builds every panel and writes `outputs/` |
| `viz.py` | all charts, built from the output CSVs |
| `dashboard.py` | Streamlit daily dashboard mock-up |
| `analysis_notebook.ipynb` | the full written analysis with charts (executed) |
| `outputs/` | generated panels (parquet + csv) and figures |

---

## Method in one paragraph

Each venue is represented as a **concentrated-liquidity profile** — a set of price
segments each holding a constant liquidity `L` — which is exactly what a Uniswap v3
tick table gives you. A trade is walked through the segments to get its exact
price impact; the pool fee is added on top for all-in cost. Curve TriCrypto is
approximated with the same concentrated-liquidity machinery (it concentrates
around its internal price scale); live mode uses the pool's exact `get_dy` instead.
"Depth" is the notional tradeable within 10 bps of price impact (fee excluded, so
venues compete on liquidity). Fragmentation is computed on each hour's vector of
per-venue depths. Optimal routing splits an order by greedily giving each marginal
chunk to the cheapest venue on the margin, which converges to marginal-price
equalisation for convex AMM curves.

---

## Known limitations

- Simulated data, as above — absolute levels are calibrated, not measured.
- Curve is modelled via the concentrated-liquidity approximation offline, not the
  exact CryptoSwap invariant (live mode uses `get_dy`).
- A true hourly *historical* depth reconstruction needs archive-node tick replay:
  the Uniswap subgraph stores hourly *pool* snapshots but not per-hour tick tables.
  This is flagged in `live_data.py`.
- Costs are computed on the buy side as representative; buy/sell are averaged for
  the depth figures.
