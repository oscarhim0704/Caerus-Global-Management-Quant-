"""
depth.py
--------
Turns raw pool state into the two depth numbers the analysis needs:

  * slippage_at_size  - taker cost in bps for a $10k / $50k / $250k trade
                        (average of a buy and a sell), used for the routing
                        sim and the summary tables.
  * depth_at_10bps    - the max USD notional you can push through the venue
                        before slippage hits 10bps (size-at-slippage). This is
                        the clean "how deep is this venue right now" magnitude,
                        so I use it for the fragmentation / most-liquid-venue work.

Both are computed by running the real swap maths from amm_math.py on whatever
state is provided, so live and simulated data go through the identical path.
"""
import numpy as np
import pandas as pd

import config as C
import amm_math as amm
import simulator as sim


# ---- build a per-hour, per-venue state dict from the sim store ----
def _state_at(store, pair, h):
    price = float(store["prices"][pair][h])
    venues = {}
    for venue, arr in store["liq"][pair].items():
        active_tvl = float(arr[h])
        # all three venues modelled as concentrated liquidity, each with its fee.
        # (Curve tricrypto concentrates around its internal price scale, so the
        #  same profile machinery is a reasonable approximation of its shape;
        #  live mode swaps this for the pool's exact get_dy.)
        if venue.startswith("Curve"):
            fee = C.CURVE_POOL["fee"]
        else:
            fee = 0.0005 if "0.05" in venue else 0.0030
        segs = sim.build_v3_profile(active_tvl, price, venue)
        venues[venue] = {"type": "v3", "segments": segs, "fee": fee}
    return price, venues


def _quote(v, price, side, amount_in, use_fee=True):
    """use_fee=False gives pure price impact (fee zeroed) - used for depth magnitude."""
    fee = v["fee"] if use_fee else 0.0
    if v["type"] == "v3":
        return amm.swap_v3_profile(v["segments"], price, side, amount_in, fee)
    return amm.swap_curve_cp(v["base_reserve"], v["usdc_reserve"], side, amount_in, fee)


def slippage_at_size(v, price, size_usd, use_fee=True):
    """
    Average buy+sell cost (bps) for a given USD notional. None if it can't fill.
    use_fee=True  -> total taker cost (price impact + pool fee)  [tables/routing]
    use_fee=False -> price impact only                          [depth magnitude]
    """
    # buy: spend USD (=size). sell: sell size/price of base.
    _, buy_px = _quote(v, price, "buy", size_usd, use_fee)
    _, sell_px = _quote(v, price, "sell", size_usd / price, use_fee)
    b = amm.slippage_bps(buy_px, price, "buy")
    s = amm.slippage_bps(sell_px, price, "sell")
    vals = [x for x in (b, s) if x is not None]
    return float(np.mean(vals)) if vals else None


def depth_at_slippage(v, price, target_bps=None, hi=200_000_000):
    """Max USD notional tradeable within target_bps of PRICE IMPACT, via bisection."""
    if target_bps is None:
        target_bps = C.DEPTH_THRESHOLD_BPS
    lo = 0.0
    # make sure hi actually exceeds the target (else return hi as a floor)
    s_hi = slippage_at_size(v, price, hi, use_fee=False)
    if s_hi is not None and s_hi < target_bps:
        return hi
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        s = slippage_at_size(v, price, mid, use_fee=False)
        if s is None or s > target_bps:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)


def build_panels(store):
    """
    Returns two tidy DataFrames:
      slip_df : one row per (timestamp, pair, venue, size_usd) with slippage_bps
      depth_df: one row per (timestamp, pair, venue) with depth_at_10bps_usd
    """
    slip_rows, depth_rows = [], []
    hours = len(store["timestamps"])
    for pair in store["liq"].keys():
        for h in range(hours):
            ts = int(store["timestamps"][h])
            utc = int(store["utc_hour"][h])
            price, venues = _state_at(store, pair, h)
            for venue, v in venues.items():
                for size in C.TRADE_SIZES_USD:
                    sl = slippage_at_size(v, price, size)
                    slip_rows.append({"timestamp": ts, "utc_hour": utc, "pair": pair,
                                      "venue": venue, "size_usd": size,
                                      "slippage_bps": sl})
                d10 = depth_at_slippage(v, price)
                depth_rows.append({"timestamp": ts, "utc_hour": utc, "pair": pair,
                                   "venue": venue, "price": price,
                                   "depth_10bps_usd": d10})
    return pd.DataFrame(slip_rows), pd.DataFrame(depth_rows)
