"""
simulator.py
------------
Generates 30 days of hourly pool state for every venue when live data isn't
available. It does NOT invent slippage numbers directly - it builds realistic
pool *state* (a v3 liquidity profile / Curve reserves + a mid price for each
hour), and depth.py then runs the real swap maths on that state. So the depth,
fragmentation and routing results are computed the same way they would be on
live data; only the inputs are synthetic.

What's modelled per hour:
  * a correlated random-walk price path for ETH and BTC (seeded).
  * a time-of-day liquidity multiplier per venue (peak ~16:00 UTC, trough
    ~04:00 UTC, small secondary dip ~21:00 UTC when desks close) - shape taken
    from published intraday depth studies.
  * a slow 30-day drift + per-venue lognormal noise.
  * Curve and the smaller Uni tier thin out a bit harder in the Asia window,
    which is what makes the dominant venue flip and fragmentation move.

Calibration inputs (VENUE_TVL_USD, CONCENTRATION, CURVE_AMP) are anchored to
public pool sizes, not live reads - see README for the honesty note.
"""
import numpy as np
import config as C

CURVE_AMP = 14.0   # crude stand-in for Curve's concentrated (amplified) invariant.
                   # scales the constant-product reserves so Curve depth is in a
                   # realistic range. calibrated to public quote depth, NOT the
                   # on-chain A/gamma. live mode uses the real get_dy() instead.

# concentric band structure for the v3 profile: (cumulative half-width, share)
# share of active TVL placed inside each ring. first ring holds `concentration`.
def _bands(concentration):
    rest = 1.0 - concentration
    return [
        (0.004, concentration),      # tight band ±0.4%
        (0.02,  rest * 0.45),        # ±2%
        (0.08,  rest * 0.35),        # ±8%
        (0.25,  rest * 0.20),        # ±25% (deep tail)
    ]


def build_v3_profile(active_tvl_usd, price, venue):
    """Turn an active-TVL figure into a v3 liquidity profile (list of segments)."""
    conc = C.CONCENTRATION.get(venue, 0.5)
    sqrtP = np.sqrt(price)
    segs = []
    prev_hw = 0.0
    for hw, share in _bands(conc):
        ring_val = active_tvl_usd * share
        width = hw - prev_hw
        # L for the ring so the USD held across the ring matches ring_val
        L = ring_val / (sqrtP * width) if width > 0 else 0.0
        if prev_hw == 0.0:
            segs.append({"p_lo": price * (1 - hw), "p_hi": price * (1 + hw), "L": L})
        else:
            segs.append({"p_lo": price * (1 + prev_hw), "p_hi": price * (1 + hw), "L": L})
            segs.append({"p_lo": price * (1 - hw), "p_hi": price * (1 - prev_hw), "L": L})
        prev_hw = hw
    return segs


def build_curve_reserves(active_tvl_usd, price):
    """Two-leg (base, usdc) reserves with the amplification stand-in applied."""
    eff = active_tvl_usd * CURVE_AMP
    usdc_reserve = eff / 2.0
    base_reserve = (eff / 2.0) / price
    return base_reserve, usdc_reserve


def _hod_multiplier(utc_hour, peak=16, amp=0.22, dip21=0.05):
    """
    Intraday liquidity multiplier peaking at `peak` UTC.
    Uniswap tiers peak in the US afternoon (~16 UTC); Curve carries relatively
    more Asia/EU flow so it peaks earlier (~10 UTC) and is flatter. The phase
    gap is what makes the deepest venue rotate by session.
    """
    m = 1.0 + amp * np.cos(2 * np.pi * (utc_hour - peak) / 24.0)
    m -= dip21 * np.exp(-((utc_hour - 21) ** 2) / 4.0)   # US desks closing dip
    return m


# per-venue intraday shape: (peak hour UTC, amplitude, 21h-dip size)
HOD_PROFILE = {
    "UniV3-0.05%":     (16, 0.22, 0.05),
    "UniV3-0.30%":     (16, 0.22, 0.05),
    "Curve-TriCrypto": (10, 0.14, 0.02),
}


def _price_path(hours, seed):
    """Correlated GBM-ish hourly path for ETH and BTC."""
    rng = np.random.default_rng(seed)
    corr = 0.8
    cov = np.array([[1.0, corr], [corr, 1.0]])
    chol = np.linalg.cholesky(cov)
    vol_h = np.array([0.9, 0.7]) / np.sqrt(24 * 365) * np.sqrt(24)  # ~hourly vol
    shocks = rng.standard_normal((hours, 2)) @ chol.T
    logret = shocks * vol_h - 0.5 * vol_h ** 2
    eth = C.SEED_PRICES["WETH"] * np.exp(np.cumsum(logret[:, 0]))
    btc = C.SEED_PRICES["WBTC"] * np.exp(np.cumsum(logret[:, 1]))
    return eth, btc


def simulate():
    """
    Build the full hourly state store.
    Returns dict:
      timestamps  : np.array of unix hours
      prices      : {"ETH/USDC": arr, "WBTC/USDC": arr}
      liq         : {pair: {venue: arr of active-TVL-USD per hour}}
    """
    rng = np.random.default_rng(C.RANDOM_SEED)
    hours = C.HOURS
    t0 = 1_700_000_000  # arbitrary start (unix); only hour-of-day matters
    ts = np.array([t0 + 3600 * i for i in range(hours)])
    utc_hour = (ts // 3600) % 24

    eth, btc = _price_path(hours, C.RANDOM_SEED)
    prices = {"ETH/USDC": eth, "WBTC/USDC": btc}

    # slow 30-day drift shared across venues (liquidity ebbs and flows)
    drift = 1.0 + 0.15 * np.sin(2 * np.pi * np.arange(hours) / (hours / 1.6))

    liq = {}
    for pair in ["ETH/USDC", "WBTC/USDC"]:
        liq[pair] = {}
        for venue, base_tvl in C.VENUE_TVL_USD[pair].items():
            peak, amp, dip = HOD_PROFILE.get(venue, (16, 0.22, 0.05))
            hod = np.array([_hod_multiplier(h, peak, amp, dip) for h in utc_hour])
            # smaller venues thin out harder when liquidity is scarce (Asia hours):
            # amplify the trough for anything that isn't the flagship tier.
            is_small = base_tvl < 0.5 * max(C.VENUE_TVL_USD[pair].values())
            if is_small:
                asia = np.exp(-(((utc_hour - 3) % 24) ** 2) / 18.0)  # peak near 03 UTC
                hod = hod * (1.0 - 0.15 * asia)
            noise = rng.lognormal(mean=0.0, sigma=0.06, size=hours)
            liq[pair][venue] = base_tvl * hod * drift * noise

    return {"timestamps": ts, "utc_hour": utc_hour, "prices": prices, "liq": liq}
