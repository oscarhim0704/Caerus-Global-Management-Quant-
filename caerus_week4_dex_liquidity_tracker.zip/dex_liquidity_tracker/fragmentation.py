"""
fragmentation.py
----------------
Measures, per pair and per hour, how liquidity is split across the venues.

A note on wording, because the brief mixes two opposite ideas:
  - "fragmentation" = liquidity spread thinly across many venues -> BAD for a
     taker, because no single venue can fill you cheaply and you must split.
  - the brief suggests the "Gini coefficient of pool depth" - but Gini (and
     HHI) actually measure CONCENTRATION. High Gini = one venue holds most of
     the depth = LESS fragmented, not more.
So I report both, and I'm explicit about which is which:
  * concentration : Gini, HHI, dominant-venue share   (high = concentrated)
  * dispersion    : normalised entropy, effective #venues (1/HHI)  (high = fragmented)
The execution-cost question ("how bad is routing") is really about dispersion,
so that's what I lean on for the routing discussion, while still reporting the
Gini the brief asked for.
"""
import numpy as np
import pandas as pd


def gini(x):
    """Standard Gini on non-negative values."""
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    if n == 0 or x.sum() == 0:
        return np.nan
    cum = np.cumsum(x)
    return (n + 1 - 2 * np.sum(cum) / cum[-1]) / n


def hhi(shares):
    return float(np.sum(shares ** 2))


def norm_entropy(shares):
    s = shares[shares > 0]
    n = len(shares)
    if n <= 1:
        return 0.0
    return float(-np.sum(s * np.log(s)) / np.log(n))


def build(depth_df):
    """
    Input: depth_df with depth_10bps_usd per (timestamp, pair, venue).
    Output: frag_df, one row per (timestamp, pair) with the metrics + which
            venue is most liquid.
    """
    rows = []
    for (ts, pair), g in depth_df.groupby(["timestamp", "pair"]):
        d = g.set_index("venue")["depth_10bps_usd"]
        total = d.sum()
        shares = (d / total).values if total > 0 else np.zeros(len(d))
        top_venue = d.idxmax()
        rows.append({
            "timestamp": ts,
            "utc_hour": int(g["utc_hour"].iloc[0]),
            "pair": pair,
            "gini_depth": gini(d.values),
            "hhi": hhi(shares),
            "dominant_share": float(shares.max()) if total > 0 else np.nan,
            "eff_num_venues": (1.0 / hhi(shares)) if total > 0 else np.nan,
            "norm_entropy": norm_entropy(shares),
            "top_venue": top_venue,
            "total_depth_10bps_usd": float(total),
        })
    frag = pd.DataFrame(rows).sort_values(["pair", "timestamp"]).reset_index(drop=True)
    return frag


def venue_flip_stats(frag_df):
    """How often the most-liquid venue changes, per pair."""
    out = []
    for pair, g in frag_df.groupby("pair"):
        g = g.sort_values("timestamp")
        top = g["top_venue"].values
        flips = int(np.sum(top[1:] != top[:-1]))
        n_trans = len(top) - 1
        # longest run holding the top spot
        runs, cur = [], 1
        for i in range(1, len(top)):
            if top[i] == top[i - 1]:
                cur += 1
            else:
                runs.append(cur); cur = 1
        runs.append(cur)
        out.append({
            "pair": pair,
            "flip_rate": flips / n_trans if n_trans else np.nan,
            "num_flips": flips,
            "hours": len(top),
            "longest_dominance_run_hrs": int(max(runs)),
            "venue_share_of_hours": g["top_venue"].value_counts(normalize=True).round(3).to_dict(),
        })
    return pd.DataFrame(out)
