"""
amm_math.py
-----------
The actual swap maths, shared by the live path and the simulator.

Two models:

1) Uniswap v3  -> swap_v3_profile()
   I represent a v3 pool as a "liquidity profile": a list of price segments,
   each with a constant liquidity L that is active while the price is inside
   that segment. That is exactly what the tick table gives you (L changes by
   liquidityNet every time you cross an initialised tick). Walking a trade
   through the segments and summing what each one can supply reproduces the
   real concentrated-liquidity price impact.

   To keep it readable I work in "human" price P = USD per base unit
   (USDC per ETH / per BTC) and orient every pool as token0 = base, token1 = USDC.
   sqrtP = sqrt(P). Amounts inside a segment with liquidity L between
   sqrtP_a and sqrtP_b (a < b):
        base  (token0) = L * (1/sqrtP_a - 1/sqrtP_b)
        usdc  (token1) = L * (sqrtP_b - sqrtP_a)
   Buying base with USDC pushes P up; selling base pushes P down.
   (live_data.py handles the real token ordering + decimals before calling this.)

2) Curve TriCryptoUSDC -> swap_curve_cp()
   I approximate the two relevant legs of the tricrypto pool as a constant
   product x*y=k on (base, usdc) reserves. This is a SIMPLIFICATION: the real
   CryptoSwap invariant concentrates liquidity around the pool's internal price
   and is therefore DEEPER than x*y=k. So Curve depth here is a conservative
   (worst-case) estimate - real Curve would usually look a bit better. In live
   mode we don't approximate, we just call the pool's own get_dy().
"""
import math


# ----------------------------------------------------------------------
# Uniswap v3
# ----------------------------------------------------------------------
def swap_v3_profile(segments, price, side, amount_in, fee):
    """
    Walk a trade through a v3 liquidity profile.

    segments : list of dicts {"p_lo","p_hi","L"} sorted ascending by price.
    price    : current mid price (USD per base).
    side     : "buy"  -> spend USDC, receive base (price moves up)
               "sell" -> spend base, receive USDC (price moves down)
    amount_in: USDC amount if buy, base amount if sell.
    fee      : pool fee fraction, taken off the input first (v3 charges the in-token).

    returns (amount_out, avg_exec_price) where avg_exec_price is USDC/base.
    """
    amt = amount_in * (1.0 - fee)          # v3 fee is on the way in
    sp = math.sqrt(price)
    out = 0.0

    if side == "buy":
        # move up through segments at or above current price
        segs = [s for s in segments if s["p_hi"] > price]
        segs.sort(key=lambda s: s["p_lo"])
        usdc_left = amt
        for s in segs:
            L = s["L"]
            sp_lo = max(sp, math.sqrt(s["p_lo"]))
            sp_hi = math.sqrt(s["p_hi"])
            if sp_hi <= sp_lo:
                continue
            usdc_cap = L * (sp_hi - sp_lo)          # USDC this segment can absorb
            if usdc_left <= usdc_cap:
                sp_new = sp_lo + usdc_left / L
                out += L * (1.0 / sp_lo - 1.0 / sp_new)
                usdc_left = 0.0
                break
            else:
                out += L * (1.0 / sp_lo - 1.0 / sp_hi)
                usdc_left -= usdc_cap
        if usdc_left > 1e-6 or out <= 0:
            # ran out of book - not enough depth to fill. mark as failed fill.
            return None, None
        avg_price = amount_in / out            # USDC paid (incl fee) per base got
        return out, avg_price

    else:  # sell
        segs = [s for s in segments if s["p_lo"] < price]
        segs.sort(key=lambda s: s["p_hi"], reverse=True)
        base_left = amt
        for s in segs:
            L = s["L"]
            sp_hi = min(sp, math.sqrt(s["p_hi"]))
            sp_lo = math.sqrt(s["p_lo"])
            if sp_hi <= sp_lo:
                continue
            base_cap = L * (1.0 / sp_lo - 1.0 / sp_hi)   # base this segment absorbs
            if base_left <= base_cap:
                # solve for new sqrt price given base added
                sp_new = 1.0 / (1.0 / sp_hi + base_left / L)
                out += L * (sp_hi - sp_new)
                base_left = 0.0
                break
            else:
                out += L * (sp_hi - sp_lo)
                base_left -= base_cap
        if base_left > 1e-9 or out <= 0:
            return None, None
        avg_price = out / amount_in            # USDC got per base sold (incl fee)
        return out, avg_price


# ----------------------------------------------------------------------
# Curve (constant-product approximation of the two relevant legs)
# ----------------------------------------------------------------------
def swap_curve_cp(base_reserve, usdc_reserve, side, amount_in, fee):
    """
    Constant-product swap on (base, usdc) reserves. Conservative vs real Curve.
    returns (amount_out, avg_exec_price).
    """
    k = base_reserve * usdc_reserve
    amt = amount_in * (1.0 - fee)
    if side == "buy":                 # USDC in, base out
        new_usdc = usdc_reserve + amt
        new_base = k / new_usdc
        out = base_reserve - new_base
        if out <= 0:
            return None, None
        return out, amount_in / out
    else:                             # base in, usdc out
        new_base = base_reserve + amt
        new_usdc = k / new_base
        out = usdc_reserve - new_usdc
        if out <= 0:
            return None, None
        return out, out / amount_in


def slippage_bps(avg_price, mid_price, side):
    """Signed cost in bps: positive = worse than mid for the taker."""
    if avg_price is None:
        return None
    if side == "buy":
        return (avg_price - mid_price) / mid_price * 10_000.0
    else:
        return (mid_price - avg_price) / mid_price * 10_000.0
