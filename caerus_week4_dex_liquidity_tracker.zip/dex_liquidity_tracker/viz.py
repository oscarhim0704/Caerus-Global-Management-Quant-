"""
viz.py
------
All the charts, built from the CSVs in outputs/ so plotting is decoupled from
the pipeline. Import the functions in the notebook / dashboard, or run
`python viz.py` to dump every figure as a PNG into outputs/figs/.
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import config as C

OUT = C.OUTPUT_DIR
FIGS = os.path.join(OUT, "figs")

# one colour per venue, reused everywhere
VENUE_COLORS = {
    "UniV3-0.05%": "#e8663d",
    "UniV3-0.30%": "#f2a900",
    "Curve-TriCrypto": "#3b7dd8",
}
plt.rcParams.update({
    "figure.dpi": 110, "font.size": 10, "axes.grid": True,
    "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False,
})


def _load():
    d = {}
    for name in ["depth_10bps", "fragmentation", "routing",
                 "slippage_at_size", "hour_of_day", "by_session", "venue_flips"]:
        d[name] = pd.read_csv(f"{OUT}/{name}.csv")
    for k in ["depth_10bps", "fragmentation", "routing", "slippage_at_size"]:
        d[k]["dt"] = pd.to_datetime(d[k]["timestamp"], unit="s")
    return d


# ---------------------------------------------------------------- 1. depth ts
def fig_depth_timeseries(d):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), sharey=False)
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        g = d["depth_10bps"][d["depth_10bps"].pair == pair]
        for venue, gv in g.groupby("venue"):
            gv = gv.sort_values("dt")
            ax.plot(gv["dt"], gv["depth_10bps_usd"] / 1e6, lw=1.0,
                    color=VENUE_COLORS.get(venue), label=venue)
        ax.set_title(f"{pair}  -  depth within 10bps impact")
        ax.set_ylabel("USD (millions)")
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 2. share area
def fig_depth_share(d):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2))
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        g = d["depth_10bps"][d["depth_10bps"].pair == pair]
        piv = g.pivot_table(index="dt", columns="venue",
                            values="depth_10bps_usd", aggfunc="mean")
        share = piv.div(piv.sum(axis=1), axis=0)
        cols = [c for c in VENUE_COLORS if c in share.columns]
        ax.stackplot(share.index, [share[c] for c in cols],
                     colors=[VENUE_COLORS[c] for c in cols], labels=cols, alpha=0.9)
        ax.set_title(f"{pair}  -  share of total depth")
        ax.set_ylim(0, 1); ax.set_ylabel("share")
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
        ax.legend(fontsize=8, frameon=False, loc="lower left")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 3. gini/hhi
def fig_fragmentation(d):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2))
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        g = d["fragmentation"][d["fragmentation"].pair == pair].sort_values("dt")
        ax.plot(g["dt"], g["gini_depth"], lw=1.0, color="#333", label="Gini (concentration)")
        ax.plot(g["dt"], g["hhi"], lw=1.0, color="#c0392b", label="HHI")
        ax.plot(g["dt"], g["norm_entropy"], lw=1.0, color="#2e8b57",
                label="norm. entropy (dispersion)")
        ax.set_title(f"{pair}  -  fragmentation metrics")
        ax.set_ylim(0, 1)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 4. cost curve
def fig_cost_curve(d):
    g = d["slippage_at_size"].groupby(["pair", "venue", "size_usd"])["slippage_bps"].median().reset_index()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), sharey=True)
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        gp = g[g.pair == pair]
        for venue, gv in gp.groupby("venue"):
            gv = gv.sort_values("size_usd")
            ax.plot(gv["size_usd"] / 1e3, gv["slippage_bps"], marker="o",
                    color=VENUE_COLORS.get(venue), label=venue)
        ax.set_title(f"{pair}  -  all-in cost vs trade size")
        ax.set_xlabel("trade size ($k)"); ax.set_ylabel("cost (bps, fee+impact)")
        ax.set_xscale("log"); ax.set_xticks([10, 50, 250])
        ax.get_xaxis().set_major_formatter(plt.ScalarFormatter())
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 5. routing
def fig_routing(d):
    r = d["routing"].groupby(["pair", "size_usd"]).agg(
        naive_deepest=("naive_deepest_bps", "mean"),
        best_single=("best_single_bps", "mean"),
        optimal=("optimal_bps", "mean")).reset_index()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), sharey=True)
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        gp = r[r.pair == pair].sort_values("size_usd")
        x = np.arange(len(gp)); w = 0.26
        ax.bar(x - w, gp["naive_deepest"], w, label="naive: deepest pool", color="#b0b0b0")
        ax.bar(x,     gp["best_single"],   w, label="naive: best single", color="#f2a900")
        ax.bar(x + w, gp["optimal"],       w, label="optimal split", color="#e8663d")
        ax.set_xticks(x); ax.set_xticklabels([f"${int(s/1000)}k" for s in gp["size_usd"]])
        ax.set_title(f"{pair}  -  execution cost by strategy")
        ax.set_ylabel("cost (bps)")
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 6. hour of day
def fig_hour_of_day(d):
    h = d["hour_of_day"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2))
    # left: total depth by hour; right: dominant share by hour
    for pair in ["ETH/USDC", "WBTC/USDC"]:
        gp = h[h.pair == pair].sort_values("utc_hour")
        axes[0].plot(gp["utc_hour"], gp["total_depth"] / 1e6, marker="o", label=pair)
        axes[1].plot(gp["utc_hour"], gp["dominant_share"], marker="o", label=pair)
    for ax in axes:
        ax.axvspan(0, 8, color="#3b7dd8", alpha=0.07)   # Asia window
        ax.axvspan(13, 22, color="#e8663d", alpha=0.07) # US window
        ax.set_xlabel("UTC hour"); ax.set_xticks(range(0, 24, 3))
        ax.legend(fontsize=8, frameon=False)
    axes[0].set_title("total depth (10bps) by UTC hour"); axes[0].set_ylabel("USD (m)")
    axes[1].set_title("dominant-venue share by UTC hour"); axes[1].set_ylabel("share")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- 7. session / leadership
def fig_leadership(d):
    frag = d["fragmentation"].copy()
    def session(hh):
        return ("Asia" if hh < 8 else "EU" if hh < 13 else "US" if hh < 22 else "Off")
    frag["session"] = frag["utc_hour"].map(session)
    order = ["Asia", "EU", "US", "Off"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), sharey=True)
    for ax, pair in zip(axes, ["ETH/USDC", "WBTC/USDC"]):
        gp = frag[frag.pair == pair]
        tab = (gp.groupby("session")["top_venue"].value_counts(normalize=True)
               .unstack().reindex(order).fillna(0))
        bottom = np.zeros(len(tab))
        for venue in [c for c in VENUE_COLORS if c in tab.columns]:
            ax.bar(tab.index, tab[venue], bottom=bottom,
                   color=VENUE_COLORS[venue], label=venue)
            bottom += tab[venue].values
        ax.set_title(f"{pair}  -  most-liquid venue by session")
        ax.set_ylabel("share of hours"); ax.set_ylim(0, 1)
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


def build_all():
    os.makedirs(FIGS, exist_ok=True)
    d = _load()
    figs = {
        "depth_timeseries": fig_depth_timeseries(d),
        "depth_share": fig_depth_share(d),
        "fragmentation": fig_fragmentation(d),
        "cost_curve": fig_cost_curve(d),
        "routing": fig_routing(d),
        "hour_of_day": fig_hour_of_day(d),
        "leadership": fig_leadership(d),
    }
    for name, fig in figs.items():
        fig.savefig(f"{FIGS}/{name}.png", bbox_inches="tight")
        plt.close(fig)
    print(f"saved {len(figs)} figures to {FIGS}/")


if __name__ == "__main__":
    build_all()
